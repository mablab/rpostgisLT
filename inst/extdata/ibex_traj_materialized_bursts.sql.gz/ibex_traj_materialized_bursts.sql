--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.8
-- Dumped by pg_dump version 9.6.4

-- Started on 2017-08-28 17:53:01 CEST

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 24 (class 2615 OID 629565)
-- Name: ibex_traj_materialized_bursts; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "ibex_traj_materialized_bursts";


SET search_path = "ibex_traj_materialized_bursts", pg_catalog;

--
-- TOC entry 1415 (class 1255 OID 629647)
-- Name: insert_pgtraj(integer); Type: FUNCTION; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE FUNCTION "insert_pgtraj"(integer) RETURNS boolean
    LANGUAGE "plpgsql"
    AS $_$
DECLARE pg record;
BEGIN
-- insert pgtrajs
INSERT INTO pgtraj (pgtraj_name, proj4string, time_zone, note)
		SELECT DISTINCT pgtraj_name, proj4string, time_zone, note
		FROM zgaqtsn_temp
		ORDER BY pgtraj_name;
IF $1 = 2 THEN
-- loop bursts
	FOR pg IN 
	SELECT DISTINCT pgtraj_name, animal_name, burst_name FROM zgaqtsn_temp ORDER BY pgtraj_name, burst_name
	LOOP
		ALTER TABLE relocation ADD COLUMN mark integer;
		ALTER TABLE step ADD COLUMN mark integer;
		--burst
		INSERT INTO animal_burst (burst_name, animal_name, pgtraj_id)
			SELECT pg.burst_name, pg.animal_name, pgtraj.id
			FROM pgtraj
			WHERE pg.pgtraj_name = pgtraj.pgtraj_name;
		-- relocations
		INSERT INTO relocation (geom, relocation_time, orig_id, mark) --added orig_id for infoloc support
			SELECT geom, relocation_time ,id, 1	--added orig_id for infoloc support
			FROM zgaqtsn_temp
			WHERE pgtraj_name = pg.pgtraj_name
			AND animal_name = pg.animal_name
			AND burst_name = pg.burst_name
			ORDER BY relocation_time;
		-- steps	
		WITH relos AS (
			SELECT
				a.id AS relocation_id_1,
				a.relocation_time AS rt,
				b.id AS relocation_id_2,
				b.relocation_time - a.relocation_time AS dt,
				a.mark
			FROM (SELECT * FROM relocation WHERE mark = 1) a 
			LEFT OUTER JOIN LATERAL 
				(SELECT c.id, c.relocation_time
				   FROM relocation c
				   WHERE mark = 1
				   AND a.relocation_time < c.relocation_time
				   ORDER BY c.relocation_time ASC
				   LIMIT 1
				 ) AS b 
			ON TRUE
			)
		INSERT INTO step (relocation_id_1, relocation_id_2, dt, mark)
			SELECT relocation_id_1, relocation_id_2, dt, 1
			FROM relos
			ORDER BY rt;
		-- step-burst rel
		INSERT INTO s_b_rel (step_id, animal_burst_id)
			SELECT a.id, a.burst_id
			FROM (SELECT step.id as id, pg.burst_name, pgtraj.id as pg_id, animal_burst.id as burst_id 
				 FROM step, animal_burst, pgtraj
				 WHERE step.mark = 1
				 AND pgtraj.id = animal_burst.pgtraj_id
				 AND pg.pgtraj_name = pgtraj.pgtraj_name
				 AND pg.burst_name = animal_burst.burst_name) a;
		-- drop mark columns
		ALTER TABLE relocation DROP COLUMN mark;
		ALTER TABLE step DROP COLUMN mark;
	END LOOP;
ELSE
-- loop bursts for type 1 (no time)
	FOR pg IN 
	SELECT DISTINCT pgtraj_name, animal_name, burst_name FROM zgaqtsn_temp ORDER BY pgtraj_name, burst_name
	LOOP
		ALTER TABLE relocation ADD COLUMN mark integer;
		ALTER TABLE step ADD COLUMN mark integer;
		--burst
		INSERT INTO animal_burst (burst_name, animal_name, pgtraj_id)
			SELECT pg.burst_name, pg.animal_name, pgtraj.id
			FROM pgtraj
			WHERE pg.pgtraj_name = pgtraj.pgtraj_name;
		-- relocations
		INSERT INTO relocation (geom, orig_id, mark) --added orig_id for infoloc support
			SELECT geom ,id, 1	--added orig_id for infoloc support
			FROM zgaqtsn_temp
			WHERE pgtraj_name = pg.pgtraj_name
			AND animal_name = pg.animal_name
			AND burst_name = pg.burst_name
			ORDER BY id;
		-- steps	
		WITH relos AS (
			SELECT
				a.id AS relocation_id_1,
				b.id AS relocation_id_2,
				a.mark
			FROM (SELECT * FROM relocation WHERE mark = 1) a 
			LEFT OUTER JOIN LATERAL 
				(SELECT c.id
				   FROM relocation c
				   WHERE mark = 1
				   AND a.id < c.id
				   ORDER BY c.id ASC
				   LIMIT 1
				 ) AS b 
			ON TRUE
			)
		INSERT INTO step (relocation_id_1, relocation_id_2, mark)
			SELECT relocation_id_1, relocation_id_2, 1
			FROM relos
			ORDER BY relocation_id_1;
		-- step-burst rel
		INSERT INTO s_b_rel (step_id, animal_burst_id)
			SELECT a.id, a.burst_id
			FROM (SELECT step.id as id, pg.burst_name, pgtraj.id as pg_id, animal_burst.id as burst_id 
				 FROM step, animal_burst, pgtraj
				 WHERE step.mark = 1
				 AND pgtraj.id = animal_burst.pgtraj_id
				 AND pg.pgtraj_name = pgtraj.pgtraj_name
				 AND pg.burst_name = animal_burst.burst_name) a;
		-- drop mark columns
		ALTER TABLE relocation DROP COLUMN mark;
		ALTER TABLE step DROP COLUMN mark;
	END LOOP;
END IF;
RETURN TRUE;
END;
$_$;


SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 229 (class 1259 OID 629582)
-- Name: animal_burst; Type: TABLE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE TABLE "animal_burst" (
    "id" integer NOT NULL,
    "burst_name" "text" NOT NULL,
    "animal_name" "text" NOT NULL,
    "pgtraj_id" integer NOT NULL,
    "info_cols" "text"[]
);


--
-- TOC entry 3675 (class 0 OID 0)
-- Dependencies: 229
-- Name: TABLE "animal_burst"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON TABLE "animal_burst" IS 'Contains animal and burst information and their relation to pgtrajs.';


--
-- TOC entry 3676 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN "animal_burst"."id"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "animal_burst"."id" IS 'Auto-generated numeric ID.';


--
-- TOC entry 3677 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN "animal_burst"."burst_name"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "animal_burst"."burst_name" IS 'Name of burst.';


--
-- TOC entry 3678 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN "animal_burst"."animal_name"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "animal_burst"."animal_name" IS 'Name of animal.';


--
-- TOC entry 3679 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN "animal_burst"."pgtraj_id"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "animal_burst"."pgtraj_id" IS 'Foreign key to pgtraj records.';


--
-- TOC entry 3680 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN "animal_burst"."info_cols"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "animal_burst"."info_cols" IS 'Array holding R data type definitions for infolocs columns. Do not edit.';


--
-- TOC entry 227 (class 1259 OID 629568)
-- Name: pgtraj; Type: TABLE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE TABLE "pgtraj" (
    "id" integer NOT NULL,
    "pgtraj_name" "text" NOT NULL,
    "proj4string" "text",
    "time_zone" "text",
    "note" "text",
    "insert_timestamp" timestamp with time zone DEFAULT "now"()
);


--
-- TOC entry 3681 (class 0 OID 0)
-- Dependencies: 227
-- Name: TABLE "pgtraj"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON TABLE "pgtraj" IS 'Groups of trajectories, with unique names. Groups can be defined on any criteria, e.g. steps belonging to one ltraj object can form a group.';


--
-- TOC entry 3682 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN "pgtraj"."id"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "pgtraj"."id" IS 'Auto-generated numeric ID.';


--
-- TOC entry 3683 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN "pgtraj"."pgtraj_name"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "pgtraj"."pgtraj_name" IS 'Name or identifier of trajectory group, not null.';


--
-- TOC entry 3684 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN "pgtraj"."proj4string"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "pgtraj"."proj4string" IS 'A PROJ.4 projection string of the ltraj, imported from R.';


--
-- TOC entry 3685 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN "pgtraj"."time_zone"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "pgtraj"."time_zone" IS 'Time zone of the imported trajectory.';


--
-- TOC entry 3686 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN "pgtraj"."note"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "pgtraj"."note" IS 'User comment.';


--
-- TOC entry 3687 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN "pgtraj"."insert_timestamp"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "pgtraj"."insert_timestamp" IS 'Time when pgtraj was created.';


--
-- TOC entry 231 (class 1259 OID 629600)
-- Name: relocation; Type: TABLE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE TABLE "relocation" (
    "id" integer NOT NULL,
    "geom" "public"."geometry",
    "relocation_time" timestamp with time zone,
    "orig_id" integer
);


--
-- TOC entry 3688 (class 0 OID 0)
-- Dependencies: 231
-- Name: TABLE "relocation"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON TABLE "relocation" IS 'Relocation geometry and time stamp.';


--
-- TOC entry 3689 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN "relocation"."id"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "relocation"."id" IS 'Auto-generated numeric ID.';


--
-- TOC entry 3690 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN "relocation"."geom"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "relocation"."geom" IS 'Geometry of the relocation.';


--
-- TOC entry 3691 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN "relocation"."relocation_time"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "relocation"."relocation_time" IS 'Time stamp of the relocation.';


--
-- TOC entry 3692 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN "relocation"."orig_id"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "relocation"."orig_id" IS 'ID number from the original relocations table in the database.';


--
-- TOC entry 234 (class 1259 OID 629630)
-- Name: s_b_rel; Type: TABLE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE TABLE "s_b_rel" (
    "step_id" integer NOT NULL,
    "animal_burst_id" integer NOT NULL
);


--
-- TOC entry 3693 (class 0 OID 0)
-- Dependencies: 234
-- Name: TABLE "s_b_rel"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON TABLE "s_b_rel" IS 'Relates step and burst.';


--
-- TOC entry 233 (class 1259 OID 629611)
-- Name: step; Type: TABLE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE TABLE "step" (
    "id" integer NOT NULL,
    "relocation_id_1" integer,
    "relocation_id_2" integer,
    "dt" interval,
    "r_rowname" "text",
    "r2n" double precision,
    "rel_angle" double precision
);


--
-- TOC entry 3694 (class 0 OID 0)
-- Dependencies: 233
-- Name: TABLE "step"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON TABLE "step" IS 'Steps derived from relocations.';


--
-- TOC entry 3695 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN "step"."id"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "step"."id" IS 'Auto-generated numeric ID.';


--
-- TOC entry 3696 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN "step"."relocation_id_1"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "step"."relocation_id_1" IS 'The first of the two successive relocations that form a step.';


--
-- TOC entry 3697 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN "step"."relocation_id_2"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "step"."relocation_id_2" IS 'The second of the two successive relocations that form a step.';


--
-- TOC entry 3698 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN "step"."dt"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "step"."dt" IS 'Duration of the step.';


--
-- TOC entry 3699 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN "step"."r_rowname"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "step"."r_rowname" IS 'Row name in the ltraj. This value is used for backward referencing between pgtraj and ltraj.';


--
-- TOC entry 3700 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN "step"."r2n"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "step"."r2n" IS 'R2n parameter copied from the ltraj on import from R.';


--
-- TOC entry 3701 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN "step"."rel_angle"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN "step"."rel_angle" IS 'Rel.angle parameter copied from the ltraj on import from R.';


--
-- TOC entry 236 (class 1259 OID 629653)
-- Name: all_burst_summary; Type: VIEW; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE VIEW "all_burst_summary" AS
 SELECT "p"."id" AS "pgtraj_id",
    "p"."pgtraj_name",
    "ab"."animal_name",
    "ab"."burst_name",
    "count"("r"."id") AS "num_relocations",
    ("count"("r"."id") - "count"("r"."geom")) AS "num_na",
    "min"("r"."relocation_time") AS "date_begin",
    "max"("r"."relocation_time") AS "date_end"
   FROM "pgtraj" "p",
    "animal_burst" "ab",
    "relocation" "r",
    "s_b_rel" "sb",
    "step" "s"
  WHERE (("p"."id" = "ab"."pgtraj_id") AND ("ab"."id" = "sb"."animal_burst_id") AND ("sb"."step_id" = "s"."id") AND ("s"."relocation_id_1" = "r"."id"))
  GROUP BY "p"."id", "p"."pgtraj_name", "ab"."id", "ab"."animal_name", "ab"."burst_name"
  ORDER BY "p"."id", "ab"."id";


--
-- TOC entry 240 (class 1259 OID 629692)
-- Name: all_burst_summary_shiny; Type: MATERIALIZED VIEW; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE MATERIALIZED VIEW "all_burst_summary_shiny" AS
 SELECT "p"."id" AS "pgtraj_id",
    "p"."pgtraj_name",
    "ab"."animal_name",
    "ab"."burst_name",
    "count"("r"."id") AS "num_relocations",
    ("count"("r"."id") - "count"("r"."geom")) AS "num_na",
    "min"("r"."relocation_time") AS "date_begin",
    "max"("r"."relocation_time") AS "date_end",
    ("public"."st_transform"("public"."st_makeline"("r"."geom"), 4326))::"public"."geometry"(LineString,4326) AS "burst_geom"
   FROM "pgtraj" "p",
    "animal_burst" "ab",
    "relocation" "r",
    "s_b_rel" "sb",
    "step" "s"
  WHERE (("p"."id" = "ab"."pgtraj_id") AND ("ab"."id" = "sb"."animal_burst_id") AND ("sb"."step_id" = "s"."id") AND ("s"."relocation_id_1" = "r"."id"))
  GROUP BY "p"."id", "p"."pgtraj_name", "ab"."id", "ab"."animal_name", "ab"."burst_name"
  ORDER BY "p"."id", "ab"."id"
  WITH NO DATA;


--
-- TOC entry 235 (class 1259 OID 629648)
-- Name: all_pgtraj_summary; Type: VIEW; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE VIEW "all_pgtraj_summary" AS
 WITH "p" AS (
         SELECT "p_1"."id",
            "p_1"."pgtraj_name",
            "p_1"."proj4string",
            "p_1"."time_zone",
            "p_1"."note",
            "p_1"."insert_timestamp",
            "a"."table_name"
           FROM ("pgtraj" "p_1"
             LEFT JOIN ( SELECT "tables"."table_name"
                   FROM "information_schema"."tables"
                  WHERE ((("tables"."table_schema")::"text" = 'ibex_traj_materialized_bursts'::"text") AND (("tables"."table_name")::"text" ~~ 'infolocs_%'::"text"))) "a" ON (("p_1"."pgtraj_name" = "substring"(("a"."table_name")::"text", 10))))
        )
 SELECT "p"."id" AS "pgtraj_id",
    "p"."pgtraj_name",
    "p"."insert_timestamp" AS "last_update",
    "count"(DISTINCT "ab"."burst_name") AS "num_bursts",
    "count"("r"."id") AS "num_relocations",
    "min"("r"."relocation_time") AS "earliest_date",
    "max"("r"."relocation_time") AS "latest_date",
    ("p"."table_name")::"text" AS "infolocs_table"
   FROM "p",
    "animal_burst" "ab",
    "relocation" "r",
    "s_b_rel" "sb",
    "step" "s"
  WHERE (("p"."id" = "ab"."pgtraj_id") AND ("ab"."id" = "sb"."animal_burst_id") AND ("sb"."step_id" = "s"."id") AND ("s"."relocation_id_1" = "r"."id"))
  GROUP BY "p"."id", "p"."pgtraj_name", "p"."insert_timestamp", "p"."table_name"
  ORDER BY "p"."id";


--
-- TOC entry 228 (class 1259 OID 629580)
-- Name: animal_burst_id_seq; Type: SEQUENCE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE SEQUENCE "animal_burst_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3702 (class 0 OID 0)
-- Dependencies: 228
-- Name: animal_burst_id_seq; Type: SEQUENCE OWNED BY; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER SEQUENCE "animal_burst_id_seq" OWNED BY "animal_burst"."id";


--
-- TOC entry 239 (class 1259 OID 629679)
-- Name: infolocs_ibex_int_space; Type: TABLE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE TABLE "infolocs_ibex_int_space" (
    "pkey" "text",
    "step_id" integer NOT NULL
);


--
-- TOC entry 3703 (class 0 OID 0)
-- Dependencies: 239
-- Name: TABLE "infolocs_ibex_int_space"; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON TABLE "infolocs_ibex_int_space" IS 'Infolocs (additional information on locations/steps) for the pgtraj "ibex_int_space".';


--
-- TOC entry 237 (class 1259 OID 629669)
-- Name: parameters_ibex_int_space; Type: VIEW; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE VIEW "parameters_ibex_int_space" AS
 WITH "step_geom" AS (
         SELECT "s"."id" AS "step_id",
            "public"."st_makeline"("r1"."geom", "r2"."geom") AS "step_geom",
            "r1"."relocation_time",
            "s"."dt",
            "s"."r_rowname",
            "r1"."geom" AS "relocation1_geom",
            "r2"."geom" AS "relocation2_geom",
            "s"."r2n",
            "s"."rel_angle",
            "ab"."burst_name",
            "ab"."id" AS "burst_order",
            "ab"."animal_name",
            "p"."pgtraj_name",
            "ab"."id" AS "ab_id"
           FROM ((((("step" "s"
             JOIN "relocation" "r1" ON (("s"."relocation_id_1" = "r1"."id")))
             LEFT JOIN "relocation" "r2" ON (("s"."relocation_id_2" = "r2"."id")))
             JOIN "s_b_rel" "rel" ON (("rel"."step_id" = "s"."id")))
             JOIN "animal_burst" "ab" ON (("ab"."id" = "rel"."animal_burst_id")))
             JOIN "pgtraj" "p" ON (("p"."id" = "ab"."pgtraj_id")))
          WHERE ("p"."pgtraj_name" = 'ibex_int_space'::"text")
        )
 SELECT "t"."step_id",
    "t"."r_rowname",
    "public"."st_x"("t"."relocation1_geom") AS "x",
    "public"."st_y"("t"."relocation1_geom") AS "y",
    "t"."relocation_time" AS "date",
    "t"."dx",
    "t"."dy",
    "t"."dist",
    "date_part"('epoch'::"text", "t"."dt") AS "dt",
    "t"."r2n",
        CASE
            WHEN ("t"."dist" < (0.0000001)::double precision) THEN NULL::double precision
            WHEN ("t"."dist" >= (0.0000001)::double precision) THEN "atan2"("t"."dy", "t"."dx")
            ELSE NULL::double precision
        END AS "abs_angle",
    "t"."rel_angle",
    "t"."animal_name",
    "t"."burst_name" AS "burst",
    "t"."pgtraj_name" AS "pgtraj"
   FROM ( SELECT "step_geom"."step_id",
            "step_geom"."relocation_time",
            "step_geom"."dt",
            "step_geom"."r_rowname",
            "step_geom"."relocation1_geom",
            "step_geom"."relocation2_geom",
            "step_geom"."burst_name",
            "step_geom"."burst_order",
            "step_geom"."animal_name",
            "step_geom"."pgtraj_name",
            "public"."st_length"("step_geom"."step_geom") AS "dist",
            ("public"."st_x"("step_geom"."relocation2_geom") - "public"."st_x"("step_geom"."relocation1_geom")) AS "dx",
            ("public"."st_y"("step_geom"."relocation2_geom") - "public"."st_y"("step_geom"."relocation1_geom")) AS "dy",
            "step_geom"."r2n",
            "step_geom"."rel_angle"
           FROM "step_geom") "t"
  ORDER BY "t"."burst_order", "t"."step_id";


--
-- TOC entry 226 (class 1259 OID 629566)
-- Name: pgtraj_id_seq; Type: SEQUENCE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE SEQUENCE "pgtraj_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3704 (class 0 OID 0)
-- Dependencies: 226
-- Name: pgtraj_id_seq; Type: SEQUENCE OWNED BY; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER SEQUENCE "pgtraj_id_seq" OWNED BY "pgtraj"."id";


--
-- TOC entry 230 (class 1259 OID 629598)
-- Name: relocation_id_seq; Type: SEQUENCE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE SEQUENCE "relocation_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3705 (class 0 OID 0)
-- Dependencies: 230
-- Name: relocation_id_seq; Type: SEQUENCE OWNED BY; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER SEQUENCE "relocation_id_seq" OWNED BY "relocation"."id";


--
-- TOC entry 238 (class 1259 OID 629674)
-- Name: step_geometry_ibex_int_space; Type: VIEW; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE VIEW "step_geometry_ibex_int_space" AS
 SELECT "s"."id" AS "step_id",
    ("public"."st_makeline"("r1"."geom", "r2"."geom"))::"public"."geometry"(LineString,3395) AS "step_geom",
    "r1"."relocation_time",
    "s"."dt",
    "s"."r_rowname",
    "ab"."burst_name",
    "ab"."animal_name",
    "p"."pgtraj_name",
    "ab"."id" AS "ab_id"
   FROM ((((("step" "s"
     JOIN "relocation" "r1" ON (("s"."relocation_id_1" = "r1"."id")))
     JOIN "relocation" "r2" ON (("s"."relocation_id_2" = "r2"."id")))
     JOIN "s_b_rel" "rel" ON (("rel"."step_id" = "s"."id")))
     JOIN "animal_burst" "ab" ON (("ab"."id" = "rel"."animal_burst_id")))
     JOIN "pgtraj" "p" ON (("p"."id" = "ab"."pgtraj_id")))
  WHERE ("p"."pgtraj_name" = 'ibex_int_space'::"text")
  ORDER BY "ab"."id", "s"."id";


--
-- TOC entry 241 (class 1259 OID 629701)
-- Name: step_geometry_shiny_ibex_int_space; Type: MATERIALIZED VIEW; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE MATERIALIZED VIEW "step_geometry_shiny_ibex_int_space" AS
 SELECT "p"."step_id",
    ("public"."st_transform"("public"."st_makeline"("r1"."geom", "r2"."geom"), 4326))::"public"."geometry"(LineString,4326) AS "step_geom",
    "r1"."relocation_time" AS "date",
    "p"."dx",
    "p"."dy",
    "p"."dist",
    "p"."dt",
    "p"."abs_angle",
    "p"."rel_angle",
    "i"."pkey",
    "p"."animal_name",
    "p"."burst" AS "burst_name",
    "p"."pgtraj" AS "pgtraj_name"
   FROM (((("parameters_ibex_int_space" "p"
     JOIN "step" "s" ON (("p"."step_id" = "s"."id")))
     JOIN "relocation" "r1" ON (("s"."relocation_id_1" = "r1"."id")))
     JOIN "relocation" "r2" ON (("s"."relocation_id_2" = "r2"."id")))
     JOIN "infolocs_ibex_int_space" "i" ON (("p"."step_id" = "i"."step_id")))
  WHERE ("public"."st_makeline"("r1"."geom", "r2"."geom") IS NOT NULL)
  WITH NO DATA;


--
-- TOC entry 232 (class 1259 OID 629609)
-- Name: step_id_seq; Type: SEQUENCE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE SEQUENCE "step_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3706 (class 0 OID 0)
-- Dependencies: 232
-- Name: step_id_seq; Type: SEQUENCE OWNED BY; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER SEQUENCE "step_id_seq" OWNED BY "step"."id";


--
-- TOC entry 3502 (class 2604 OID 629585)
-- Name: animal_burst id; Type: DEFAULT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "animal_burst" ALTER COLUMN "id" SET DEFAULT "nextval"('"animal_burst_id_seq"'::"regclass");


--
-- TOC entry 3500 (class 2604 OID 629571)
-- Name: pgtraj id; Type: DEFAULT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "pgtraj" ALTER COLUMN "id" SET DEFAULT "nextval"('"pgtraj_id_seq"'::"regclass");


--
-- TOC entry 3503 (class 2604 OID 629603)
-- Name: relocation id; Type: DEFAULT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "relocation" ALTER COLUMN "id" SET DEFAULT "nextval"('"relocation_id_seq"'::"regclass");


--
-- TOC entry 3504 (class 2604 OID 629614)
-- Name: step id; Type: DEFAULT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "step" ALTER COLUMN "id" SET DEFAULT "nextval"('"step_id_seq"'::"regclass");


--
-- TOC entry 3662 (class 0 OID 629582)
-- Dependencies: 229
-- Data for Name: animal_burst; Type: TABLE DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

COPY "animal_burst" ("id", "burst_name", "animal_name", "pgtraj_id", "info_cols") FROM stdin;
1	A153.R400	A153	1	{{pkey},{factor},{"/*/A153.2003-06-01 00:00:00/*/A153.2003-06-01 06:59:59/*/A153.2003-06-01 09:49:30/*/A153.2003-06-02 04:39:54/*/A153.2003-06-02 05:29:26/*/A153.2003-06-02 06:18:58/*/A153.2003-06-02 07:08:31/*/A153.2003-06-02 07:58:03/*/A153.2003-06-02 08:42:08/*/A153.2003-06-02 09:25:39/*/A153.2003-06-02 10:09:09/*/A153.2003-06-02 10:52:40/*/A153.2003-06-02 11:36:10/*/A153.2003-06-02 12:45:24/*/A153.2003-06-02 14:25:42/*/A153.2003-06-02 17:23:06/*/A153.2003-06-03 09:30:33/*/A153.2003-06-03 11:07:00/*/A153.2003-06-03 12:26:53/*/A153.2003-06-03 13:24:37/*/A153.2003-06-03 14:22:20/*/A153.2003-06-03 15:20:03/*/A153.2003-06-03 16:41:56/*/A153.2003-06-03 18:10:50/*/A153.2003-06-03 19:39:45/*/A153.2003-06-04 07:24:29/*/A153.2003-06-04 13:15:29/*/A153.2003-06-04 18:37:18/*/A153.2003-06-05 00:21:51/*/A153.2003-06-05 00:50:17/*/A153.2003-06-05 01:18:42/*/A153.2003-06-05 01:47:08/*/A153.2003-06-05 02:15:33/*/A153.2003-06-05 02:43:58/*/A153.2003-06-05 03:12:24/*/A153.2003-06-05 03:40:49/*/A153.2003-06-05 04:40:03/*/A153.2003-06-05 05:03:58/*/A153.2003-06-05 05:27:54/*/A153.2003-06-05 05:51:49/*/A153.2003-06-05 06:15:44/*/A153.2003-06-05 06:39:40/*/A153.2003-06-05 07:03:35/*/A153.2003-06-05 07:27:31/*/A153.2003-06-05 07:51:26/*/A153.2003-06-05 09:51:46/*/A153.2003-06-05 14:38:14/*/A153.2003-06-05 16:58:12/*/A153.2003-06-05 18:17:33/*/A153.2003-06-05 19:36:54/*/A153.2003-06-05 20:52:28/*/A153.2003-06-05 21:44:38/*/A153.2003-06-05 22:36:47/*/A153.2003-06-05 23:28:56/*/A153.2003-06-06 00:51:21/*/A153.2003-06-06 01:25:18/*/A153.2003-06-06 01:59:14/*/A153.2003-06-06 02:33:11/*/A153.2003-06-06 03:07:07/*/A153.2003-06-06 03:41:04/*/A153.2003-06-06 04:49:04/*/A153.2003-06-06 05:21:01/*/A153.2003-06-06 05:52:57/*/A153.2003-06-06 06:24:53/*/A153.2003-06-06 06:56:49/*/A153.2003-06-06 07:28:46/*/A153.2003-06-06 14:36:42/*/A153.2003-06-07 00:07:21/*/A153.2003-06-07 00:51:04/*/A153.2003-06-07 01:34:47/*/A153.2003-06-07 02:18:29/*/A153.2003-06-07 03:02:12/*/A153.2003-06-07 03:45:55/*/A153.2003-06-07 04:43:59/*/A153.2003-06-07 05:17:18/*/A153.2003-06-07 05:50:37/*/A153.2003-06-07 06:23:57/*/A153.2003-06-07 06:57:16/*/A153.2003-06-07 07:30:36/*/A153.2003-06-07 08:55:02/*/A153.2003-06-07 13:15:33/*/A153.2003-06-07 15:44:27/*/A153.2003-06-07 16:49:41/*/A153.2003-06-07 17:37:23/*/A153.2003-06-07 18:25:05/*/A153.2003-06-07 19:12:47/*/A153.2003-06-07 22:13:13/*/A153.2003-06-07 23:21:17/*/A153.2003-06-08 01:08:26/*/A153.2003-06-08 03:07:37/*/A153.2003-06-08 05:47:35/*/A153.2003-06-08 07:17:21/*/A153.2003-06-08 12:28:19/*/A153.2003-06-08 14:34:41/*/A153.2003-06-08 18:32:02/*/A153.2003-06-08 20:04:33/*/A153.2003-06-08 22:00:15/*/A153.2003-06-08 23:55:57/*/A153.2003-06-09 01:32:14/*/A153.2003-06-09 03:01:32/*/A153.2003-06-09 05:05:43/*/A153.2003-06-09 06:03:18/*/A153.2003-06-09 07:00:54/*/A153.2003-06-09 07:58:29/*/A153.2003-06-09 09:52:21/*/A153.2003-06-09 11:41:57/*/A153.2003-06-09 13:47:08/*/A153.2003-06-09 15:19:16/*/A153.2003-06-09 17:52:30/*/A153.2003-06-09 19:39:26/*/A153.2003-06-09 21:46:33/*/A153.2003-06-09 23:37:27/*/A153.2003-06-10 01:28:21/*/A153.2003-06-10 03:19:15/*/A153.2003-06-10 04:39:28/*/A153.2003-06-10 05:10:13/*/A153.2003-06-10 05:40:57/*/A153.2003-06-10 06:11:42/*/A153.2003-06-10 06:42:27/*/A153.2003-06-10 07:13:11/*/A153.2003-06-10 07:43:56/*/A153.2003-06-10 11:09:40/*/A153.2003-06-10 12:57:51/*/A153.2003-06-10 14:18:19/*/A153.2003-06-10 15:38:47/*/A153.2003-06-10 17:15:40/*/A153.2003-06-10 18:17:07/*/A153.2003-06-10 19:18:33/*/A153.2003-06-10 20:33:36/*/A153.2003-06-10 21:32:20/*/A153.2003-06-10 22:31:03/*/A153.2003-06-10 23:29:47/*/A153.2003-06-11 00:43:04/*/A153.2003-06-11 01:17:54/*/A153.2003-06-11 01:52:43/*/A153.2003-06-11 02:27:33/*/A153.2003-06-11 03:02:23/*/A153.2003-06-11 03:37:13/*/A153.2003-06-11 05:10:51/*/A153.2003-06-11 05:56:35/*/A153.2003-06-11 06:42:20/*/A153.2003-06-11 07:28:04/*/A153.2003-06-11 13:03:57/*/A153.2003-06-12 02:26:17/*/A153.2003-06-12 06:04:42/*/A153.2003-06-12 07:26:45/*/A153.2003-06-12 08:44:56/*/A153.2003-06-12 09:26:08/*/A153.2003-06-12 10:07:20/*/A153.2003-06-12 10:48:32/*/A153.2003-06-12 11:29:44/*/A153.2003-06-12 14:41:08/*/A153.2003-06-12 16:14:59/*/A153.2003-06-12 17:48:50/*/A153.2003-06-12 19:22:42/*/A153.2003-06-12 23:55:13/*/A153.2003-06-13 02:58:32/*/A153.2003-06-13 09:42:42/*/A153.2003-06-13 11:03:00/*/A153.2003-06-13 17:14:45/*/A153.2003-06-13 20:49:32/*/A153.2003-06-14 08:44:51/*/A153.2003-06-14 14:25:39/*/A153.2003-06-14 18:33:09/*/"}}
2	A160.R400	A160	1	{{pkey},{factor},{"/*/A160.2003-06-01 08:00:00/*/A160.2003-06-01 11:05:30/*/A160.2003-06-01 12:45:10/*/A160.2003-06-01 13:47:46/*/A160.2003-06-01 14:50:21/*/A160.2003-06-01 15:52:56/*/A160.2003-06-01 18:55:27/*/A160.2003-06-01 20:51:48/*/A160.2003-06-01 21:34:12/*/A160.2003-06-01 22:16:35/*/A160.2003-06-01 22:58:58/*/A160.2003-06-01 23:41:21/*/A160.2003-06-02 01:43:28/*/A160.2003-06-02 02:59:44/*/A160.2003-06-02 04:20:12/*/A160.2003-06-02 05:13:08/*/A160.2003-06-02 06:06:03/*/A160.2003-06-02 06:58:59/*/A160.2003-06-02 07:51:55/*/A160.2003-06-02 09:54:28/*/A160.2003-06-02 11:33:54/*/A160.2003-06-02 13:13:20/*/A160.2003-06-02 14:52:45/*/A160.2003-06-02 17:18:57/*/A160.2003-06-02 18:06:11/*/A160.2003-06-02 18:53:25/*/A160.2003-06-02 19:40:39/*/A160.2003-06-03 09:27:21/*/A160.2003-06-03 11:24:14/*/A160.2003-06-03 13:21:06/*/A160.2003-06-03 15:17:59/*/A160.2003-06-03 17:19:08/*/A160.2003-06-03 18:17:22/*/A160.2003-06-03 19:15:35/*/A160.2003-06-04 08:24:16/*/A160.2003-06-04 11:34:13/*/A160.2003-06-05 01:05:45/*/A160.2003-06-05 02:13:14/*/A160.2003-06-05 03:20:43/*/A160.2003-06-05 05:33:24/*/A160.2003-06-05 06:35:18/*/A160.2003-06-05 07:37:12/*/A160.2003-06-05 09:29:24/*/A160.2003-06-05 10:38:47/*/A160.2003-06-05 11:48:11/*/A160.2003-06-05 12:57:34/*/A160.2003-06-05 14:06:57/*/A160.2003-06-05 15:16:20/*/A160.2003-06-05 17:17:55/*/A160.2003-06-05 18:06:57/*/A160.2003-06-05 18:55:59/*/A160.2003-06-05 19:45:00/*/A160.2003-06-06 14:21:53/*/A160.2003-06-06 17:49:03/*/A160.2003-06-06 21:16:12/*/A160.2003-06-07 07:19:14/*/A160.2003-06-08 05:22:23/*/A160.2003-06-08 08:42:50/*/A160.2003-06-08 09:57:36/*/A160.2003-06-08 11:12:22/*/A160.2003-06-08 22:14:07/*/A160.2003-06-09 04:29:29/*/A160.2003-06-09 09:00:10/*/A160.2003-06-09 10:25:54/*/A160.2003-06-09 11:51:38/*/A160.2003-06-09 13:17:22/*/A160.2003-06-09 14:43:06/*/A160.2003-06-09 18:02:29/*/A160.2003-06-09 19:09:01/*/A160.2003-06-09 20:15:33/*/A160.2003-06-09 21:22:05/*/A160.2003-06-09 22:28:37/*/A160.2003-06-09 23:35:09/*/A160.2003-06-10 00:35:51/*/A160.2003-06-10 01:01:59/*/A160.2003-06-10 01:28:06/*/A160.2003-06-10 01:54:14/*/A160.2003-06-10 02:20:22/*/A160.2003-06-10 02:46:30/*/A160.2003-06-10 03:12:37/*/A160.2003-06-10 03:38:45/*/A160.2003-06-10 04:53:16/*/A160.2003-06-10 05:23:14/*/A160.2003-06-10 05:53:11/*/A160.2003-06-10 06:23:09/*/A160.2003-06-10 06:53:06/*/A160.2003-06-10 07:23:04/*/A160.2003-06-10 07:53:01/*/A160.2003-06-10 13:00:26/*/A160.2003-06-10 18:04:48/*/A160.2003-06-10 20:03:13/*/A160.2003-06-10 22:01:37/*/A160.2003-06-11 01:51:16/*/A160.2003-06-11 03:01:59/*/A160.2003-06-11 04:23:52/*/A160.2003-06-11 05:47:14/*/A160.2003-06-11 07:10:35/*/A160.2003-06-11 08:36:10/*/A160.2003-06-11 09:20:30/*/A160.2003-06-11 10:04:50/*/A160.2003-06-11 10:49:10/*/A160.2003-06-11 11:33:30/*/A160.2003-06-11 13:57:07/*/A160.2003-06-11 15:11:00/*/A160.2003-06-11 17:37:18/*/A160.2003-06-11 21:31:06/*/A160.2003-06-12 02:55:38/*/A160.2003-06-12 07:34:58/*/A160.2003-06-12 09:07:31/*/A160.2003-06-12 10:24:50/*/A160.2003-06-12 11:42:09/*/A160.2003-06-13 08:57:38/*/A160.2003-06-13 09:54:59/*/A160.2003-06-13 10:52:20/*/A160.2003-06-13 11:49:41/*/A160.2003-06-13 13:29:34/*/A160.2003-06-13 14:46:44/*/A160.2003-06-13 16:32:58/*/A160.2003-06-13 17:04:55/*/A160.2003-06-13 17:36:52/*/A160.2003-06-13 18:08:48/*/A160.2003-06-13 18:40:45/*/A160.2003-06-13 19:12:42/*/A160.2003-06-13 19:44:39/*/A160.2003-06-13 20:51:57/*/A160.2003-06-13 21:27:16/*/A160.2003-06-13 22:02:36/*/A160.2003-06-13 22:37:55/*/A160.2003-06-13 23:13:15/*/A160.2003-06-13 23:48:35/*/"}}
3	A286.R400	A286	1	{{pkey},{factor},{"/*/A286.2003-06-01 00:00:00/*/A286.2003-06-01 05:58:50/*/A286.2003-06-01 11:59:16/*/A286.2003-06-01 14:30:10/*/A286.2003-06-01 19:54:27/*/A286.2003-06-02 11:00:51/*/A286.2003-06-02 15:39:30/*/A286.2003-06-02 19:18:40/*/A286.2003-06-03 11:53:24/*/A286.2003-06-04 05:50:50/*/A286.2003-06-04 09:29:07/*/A286.2003-06-04 11:13:04/*/A286.2003-06-04 12:24:46/*/A286.2003-06-04 13:05:28/*/A286.2003-06-04 13:46:10/*/A286.2003-06-04 14:26:52/*/A286.2003-06-04 15:07:34/*/A286.2003-06-04 15:48:16/*/A286.2003-06-05 00:37:57/*/A286.2003-06-05 05:46:28/*/A286.2003-06-05 11:02:10/*/A286.2003-06-05 21:00:28/*/A286.2003-06-07 16:54:11/*/A286.2003-06-07 18:06:21/*/A286.2003-06-07 19:18:31/*/A286.2003-06-07 22:07:10/*/A286.2003-06-08 04:41:18/*/A286.2003-06-08 05:42:39/*/A286.2003-06-08 06:43:59/*/A286.2003-06-08 07:45:20/*/A286.2003-06-08 09:43:31/*/A286.2003-06-08 11:58:50/*/A286.2003-06-08 14:14:10/*/A286.2003-06-08 22:59:19/*/A286.2003-06-11 06:51:15/*/A286.2003-06-11 10:23:58/*/A286.2003-06-12 22:14:11/*/A286.2003-06-13 13:00:03/*/A286.2003-06-13 16:26:17/*/A286.2003-06-13 18:20:19/*/A286.2003-06-13 23:25:47/*/"}}
4	A289.R400	A289	1	{{pkey},{factor},{"/*/A289.2003-06-01 00:00:00/*/A289.2003-06-01 08:28:51/*/A289.2003-06-01 10:23:27/*/A289.2003-06-01 14:16:10/*/A289.2003-06-01 15:42:46/*/A289.2003-06-02 07:10:52/*/A289.2003-06-02 17:24:50/*/A289.2003-06-02 19:37:59/*/A289.2003-06-03 04:20:36/*/A289.2003-06-03 07:41:47/*/A289.2003-06-03 10:06:42/*/A289.2003-06-03 12:25:19/*/A289.2003-06-03 14:43:55/*/A289.2003-06-03 19:57:02/*/A289.2003-06-04 01:39:28/*/A289.2003-06-04 07:15:24/*/A289.2003-06-04 16:29:42/*/A289.2003-06-04 16:52:39/*/A289.2003-06-04 17:15:37/*/A289.2003-06-04 17:38:34/*/A289.2003-06-04 18:01:31/*/A289.2003-06-04 18:24:28/*/A289.2003-06-04 18:47:25/*/A289.2003-06-04 19:10:23/*/A289.2003-06-04 19:33:20/*/A289.2003-06-04 19:56:17/*/A289.2003-06-04 20:27:14/*/A289.2003-06-04 20:50:41/*/A289.2003-06-04 21:14:08/*/A289.2003-06-04 21:37:35/*/A289.2003-06-04 22:01:03/*/A289.2003-06-04 22:24:30/*/A289.2003-06-04 22:47:57/*/A289.2003-06-04 23:11:24/*/A289.2003-06-04 23:34:51/*/A289.2003-06-04 23:58:18/*/A289.2003-06-06 00:10:24/*/A289.2003-06-07 07:42:45/*/A289.2003-06-07 09:11:08/*/A289.2003-06-07 10:24:54/*/A289.2003-06-07 11:38:41/*/A289.2003-06-07 13:02:11/*/A289.2003-06-07 14:17:03/*/A289.2003-06-07 15:31:54/*/A289.2003-06-08 06:08:56/*/A289.2003-06-08 07:53:21/*/A289.2003-06-08 09:37:46/*/A289.2003-06-08 11:22:11/*/A289.2003-06-08 18:13:49/*/A289.2003-06-09 19:31:16/*/A289.2003-06-10 17:16:05/*/A289.2003-06-10 18:25:10/*/A289.2003-06-10 19:34:16/*/A289.2003-06-10 20:43:21/*/A289.2003-06-10 21:52:26/*/A289.2003-06-10 23:01:31/*/A289.2003-06-11 15:34:45/*/A289.2003-06-11 18:52:00/*/A289.2003-06-11 22:09:16/*/A289.2003-06-13 08:21:30/*/A289.2003-06-13 10:01:26/*/A289.2003-06-13 11:41:21/*/A289.2003-06-13 20:06:08/*/A289.2003-06-14 15:54:48/*/"}}
\.


--
-- TOC entry 3707 (class 0 OID 0)
-- Dependencies: 228
-- Name: animal_burst_id_seq; Type: SEQUENCE SET; Schema: ibex_traj_materialized_bursts; Owner: -
--

SELECT pg_catalog.setval('"animal_burst_id_seq"', 4, true);


--
-- TOC entry 3668 (class 0 OID 629679)
-- Dependencies: 239
-- Data for Name: infolocs_ibex_int_space; Type: TABLE DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

COPY "infolocs_ibex_int_space" ("pkey", "step_id") FROM stdin;
A153.2003-06-01 00:00:00	1
A153.2003-06-01 06:59:59	2
A153.2003-06-01 09:49:30	3
A153.2003-06-02 04:39:54	4
A153.2003-06-02 05:29:26	5
A153.2003-06-02 06:18:58	6
A153.2003-06-02 07:08:31	7
A153.2003-06-02 07:58:03	8
A153.2003-06-02 08:42:08	9
A153.2003-06-02 09:25:39	10
A153.2003-06-02 10:09:09	11
A153.2003-06-02 10:52:40	12
A153.2003-06-02 11:36:10	13
A153.2003-06-02 12:45:24	14
A153.2003-06-02 14:25:42	15
A153.2003-06-02 17:23:06	16
A153.2003-06-03 09:30:33	17
A153.2003-06-03 11:07:00	18
A153.2003-06-03 12:26:53	19
A153.2003-06-03 13:24:37	20
A153.2003-06-03 14:22:20	21
A153.2003-06-03 15:20:03	22
A153.2003-06-03 16:41:56	23
A153.2003-06-03 18:10:50	24
A153.2003-06-03 19:39:45	25
A153.2003-06-04 07:24:29	26
A153.2003-06-04 13:15:29	27
A153.2003-06-04 18:37:18	28
A153.2003-06-05 00:21:51	29
A153.2003-06-05 00:50:17	30
A153.2003-06-05 01:18:42	31
A153.2003-06-05 01:47:08	32
A153.2003-06-05 02:15:33	33
A153.2003-06-05 02:43:58	34
A153.2003-06-05 03:12:24	35
A153.2003-06-05 03:40:49	36
A153.2003-06-05 04:40:03	37
A153.2003-06-05 05:03:58	38
A153.2003-06-05 05:27:54	39
A153.2003-06-05 05:51:49	40
A153.2003-06-05 06:15:44	41
A153.2003-06-05 06:39:40	42
A153.2003-06-05 07:03:35	43
A153.2003-06-05 07:27:31	44
A153.2003-06-05 07:51:26	45
A153.2003-06-05 09:51:46	46
A153.2003-06-05 14:38:14	47
A153.2003-06-05 16:58:12	48
A153.2003-06-05 18:17:33	49
A153.2003-06-05 19:36:54	50
A153.2003-06-05 20:52:28	51
A153.2003-06-05 21:44:38	52
A153.2003-06-05 22:36:47	53
A153.2003-06-05 23:28:56	54
A153.2003-06-06 00:51:21	55
A153.2003-06-06 01:25:18	56
A153.2003-06-06 01:59:14	57
A153.2003-06-06 02:33:11	58
A153.2003-06-06 03:07:07	59
A153.2003-06-06 03:41:04	60
A153.2003-06-06 04:49:04	61
A153.2003-06-06 05:21:01	62
A153.2003-06-06 05:52:57	63
A153.2003-06-06 06:24:53	64
A153.2003-06-06 06:56:49	65
A153.2003-06-06 07:28:46	66
A153.2003-06-06 14:36:42	67
A153.2003-06-07 00:07:21	68
A153.2003-06-07 00:51:04	69
A153.2003-06-07 01:34:47	70
A153.2003-06-07 02:18:29	71
A153.2003-06-07 03:02:12	72
A153.2003-06-07 03:45:55	73
A153.2003-06-07 04:43:59	74
A153.2003-06-07 05:17:18	75
A153.2003-06-07 05:50:37	76
A153.2003-06-07 06:23:57	77
A153.2003-06-07 06:57:16	78
A153.2003-06-07 07:30:36	79
A153.2003-06-07 08:55:02	80
A153.2003-06-07 13:15:33	81
A153.2003-06-07 15:44:27	82
A153.2003-06-07 16:49:41	83
A153.2003-06-07 17:37:23	84
A153.2003-06-07 18:25:05	85
A153.2003-06-07 19:12:47	86
A153.2003-06-07 22:13:13	87
A153.2003-06-07 23:21:17	88
A153.2003-06-08 01:08:26	89
A153.2003-06-08 03:07:37	90
A153.2003-06-08 05:47:35	91
A153.2003-06-08 07:17:21	92
A153.2003-06-08 12:28:19	93
A153.2003-06-08 14:34:41	94
A153.2003-06-08 18:32:02	95
A153.2003-06-08 20:04:33	96
A153.2003-06-08 22:00:15	97
A153.2003-06-08 23:55:57	98
A153.2003-06-09 01:32:14	99
A153.2003-06-09 03:01:32	100
A153.2003-06-09 05:05:43	101
A153.2003-06-09 06:03:18	102
A153.2003-06-09 07:00:54	103
A153.2003-06-09 07:58:29	104
A153.2003-06-09 09:52:21	105
A153.2003-06-09 11:41:57	106
A153.2003-06-09 13:47:08	107
A153.2003-06-09 15:19:16	108
A153.2003-06-09 17:52:30	109
A153.2003-06-09 19:39:26	110
A153.2003-06-09 21:46:33	111
A153.2003-06-09 23:37:27	112
A153.2003-06-10 01:28:21	113
A153.2003-06-10 03:19:15	114
A153.2003-06-10 04:39:28	115
A153.2003-06-10 05:10:13	116
A153.2003-06-10 05:40:57	117
A153.2003-06-10 06:11:42	118
A153.2003-06-10 06:42:27	119
A153.2003-06-10 07:13:11	120
A153.2003-06-10 07:43:56	121
A153.2003-06-10 11:09:40	122
A153.2003-06-10 12:57:51	123
A153.2003-06-10 14:18:19	124
A153.2003-06-10 15:38:47	125
A153.2003-06-10 17:15:40	126
A153.2003-06-10 18:17:07	127
A153.2003-06-10 19:18:33	128
A153.2003-06-10 20:33:36	129
A153.2003-06-10 21:32:20	130
A153.2003-06-10 22:31:03	131
A153.2003-06-10 23:29:47	132
A153.2003-06-11 00:43:04	133
A153.2003-06-11 01:17:54	134
A153.2003-06-11 01:52:43	135
A153.2003-06-11 02:27:33	136
A153.2003-06-11 03:02:23	137
A153.2003-06-11 03:37:13	138
A153.2003-06-11 05:10:51	139
A153.2003-06-11 05:56:35	140
A153.2003-06-11 06:42:20	141
A153.2003-06-11 07:28:04	142
A153.2003-06-11 13:03:57	143
A153.2003-06-12 02:26:17	144
A153.2003-06-12 06:04:42	145
A153.2003-06-12 07:26:45	146
A153.2003-06-12 08:44:56	147
A153.2003-06-12 09:26:08	148
A153.2003-06-12 10:07:20	149
A153.2003-06-12 10:48:32	150
A153.2003-06-12 11:29:44	151
A153.2003-06-12 14:41:08	152
A153.2003-06-12 16:14:59	153
A153.2003-06-12 17:48:50	154
A153.2003-06-12 19:22:42	155
A153.2003-06-12 23:55:13	156
A153.2003-06-13 02:58:32	157
A153.2003-06-13 09:42:42	158
A153.2003-06-13 11:03:00	159
A153.2003-06-13 17:14:45	160
A153.2003-06-13 20:49:32	161
A153.2003-06-14 08:44:51	162
A153.2003-06-14 14:25:39	163
A153.2003-06-14 18:33:09	164
A160.2003-06-01 08:00:00	165
A160.2003-06-01 11:05:30	166
A160.2003-06-01 12:45:10	167
A160.2003-06-01 13:47:46	168
A160.2003-06-01 14:50:21	169
A160.2003-06-01 15:52:56	170
A160.2003-06-01 18:55:27	171
A160.2003-06-01 20:51:48	172
A160.2003-06-01 21:34:12	173
A160.2003-06-01 22:16:35	174
A160.2003-06-01 22:58:58	175
A160.2003-06-01 23:41:21	176
A160.2003-06-02 01:43:28	177
A160.2003-06-02 02:59:44	178
A160.2003-06-02 04:20:12	179
A160.2003-06-02 05:13:08	180
A160.2003-06-02 06:06:03	181
A160.2003-06-02 06:58:59	182
A160.2003-06-02 07:51:55	183
A160.2003-06-02 09:54:28	184
A160.2003-06-02 11:33:54	185
A160.2003-06-02 13:13:20	186
A160.2003-06-02 14:52:45	187
A160.2003-06-02 17:18:57	188
A160.2003-06-02 18:06:11	189
A160.2003-06-02 18:53:25	190
A160.2003-06-02 19:40:39	191
A160.2003-06-03 09:27:21	192
A160.2003-06-03 11:24:14	193
A160.2003-06-03 13:21:06	194
A160.2003-06-03 15:17:59	195
A160.2003-06-03 17:19:08	196
A160.2003-06-03 18:17:22	197
A160.2003-06-03 19:15:35	198
A160.2003-06-04 08:24:16	199
A160.2003-06-04 11:34:13	200
A160.2003-06-05 01:05:45	201
A160.2003-06-05 02:13:14	202
A160.2003-06-05 03:20:43	203
A160.2003-06-05 05:33:24	204
A160.2003-06-05 06:35:18	205
A160.2003-06-05 07:37:12	206
A160.2003-06-05 09:29:24	207
A160.2003-06-05 10:38:47	208
A160.2003-06-05 11:48:11	209
A160.2003-06-05 12:57:34	210
A160.2003-06-05 14:06:57	211
A160.2003-06-05 15:16:20	212
A160.2003-06-05 17:17:55	213
A160.2003-06-05 18:06:57	214
A160.2003-06-05 18:55:59	215
A160.2003-06-05 19:45:00	216
A160.2003-06-06 14:21:53	217
A160.2003-06-06 17:49:03	218
A160.2003-06-06 21:16:12	219
A160.2003-06-07 07:19:14	220
A160.2003-06-08 05:22:23	221
A160.2003-06-08 08:42:50	222
A160.2003-06-08 09:57:36	223
A160.2003-06-08 11:12:22	224
A160.2003-06-08 22:14:07	225
A160.2003-06-09 04:29:29	226
A160.2003-06-09 09:00:10	227
A160.2003-06-09 10:25:54	228
A160.2003-06-09 11:51:38	229
A160.2003-06-09 13:17:22	230
A160.2003-06-09 14:43:06	231
A160.2003-06-09 18:02:29	232
A160.2003-06-09 19:09:01	233
A160.2003-06-09 20:15:33	234
A160.2003-06-09 21:22:05	235
A160.2003-06-09 22:28:37	236
A160.2003-06-09 23:35:09	237
A160.2003-06-10 00:35:51	238
A160.2003-06-10 01:01:59	239
A160.2003-06-10 01:28:06	240
A160.2003-06-10 01:54:14	241
A160.2003-06-10 02:20:22	242
A160.2003-06-10 02:46:30	243
A160.2003-06-10 03:12:37	244
A160.2003-06-10 03:38:45	245
A160.2003-06-10 04:53:16	246
A160.2003-06-10 05:23:14	247
A160.2003-06-10 05:53:11	248
A160.2003-06-10 06:23:09	249
A160.2003-06-10 06:53:06	250
A160.2003-06-10 07:23:04	251
A160.2003-06-10 07:53:01	252
A160.2003-06-10 13:00:26	253
A160.2003-06-10 18:04:48	254
A160.2003-06-10 20:03:13	255
A160.2003-06-10 22:01:37	256
A160.2003-06-11 01:51:16	257
A160.2003-06-11 03:01:59	258
A160.2003-06-11 04:23:52	259
A160.2003-06-11 05:47:14	260
A160.2003-06-11 07:10:35	261
A160.2003-06-11 08:36:10	262
A160.2003-06-11 09:20:30	263
A160.2003-06-11 10:04:50	264
A160.2003-06-11 10:49:10	265
A160.2003-06-11 11:33:30	266
A160.2003-06-11 13:57:07	267
A160.2003-06-11 15:11:00	268
A160.2003-06-11 17:37:18	269
A160.2003-06-11 21:31:06	270
A160.2003-06-12 02:55:38	271
A160.2003-06-12 07:34:58	272
A160.2003-06-12 09:07:31	273
A160.2003-06-12 10:24:50	274
A160.2003-06-12 11:42:09	275
A160.2003-06-13 08:57:38	276
A160.2003-06-13 09:54:59	277
A160.2003-06-13 10:52:20	278
A160.2003-06-13 11:49:41	279
A160.2003-06-13 13:29:34	280
A160.2003-06-13 14:46:44	281
A160.2003-06-13 16:32:58	282
A160.2003-06-13 17:04:55	283
A160.2003-06-13 17:36:52	284
A160.2003-06-13 18:08:48	285
A160.2003-06-13 18:40:45	286
A160.2003-06-13 19:12:42	287
A160.2003-06-13 19:44:39	288
A160.2003-06-13 20:51:57	289
A160.2003-06-13 21:27:16	290
A160.2003-06-13 22:02:36	291
A160.2003-06-13 22:37:55	292
A160.2003-06-13 23:13:15	293
A160.2003-06-13 23:48:35	294
A286.2003-06-01 00:00:00	295
A286.2003-06-01 05:58:50	296
A286.2003-06-01 11:59:16	297
A286.2003-06-01 14:30:10	298
A286.2003-06-01 19:54:27	299
A286.2003-06-02 11:00:51	300
A286.2003-06-02 15:39:30	301
A286.2003-06-02 19:18:40	302
A286.2003-06-03 11:53:24	303
A286.2003-06-04 05:50:50	304
A286.2003-06-04 09:29:07	305
A286.2003-06-04 11:13:04	306
A286.2003-06-04 12:24:46	307
A286.2003-06-04 13:05:28	308
A286.2003-06-04 13:46:10	309
A286.2003-06-04 14:26:52	310
A286.2003-06-04 15:07:34	311
A286.2003-06-04 15:48:16	312
A286.2003-06-05 00:37:57	313
A286.2003-06-05 05:46:28	314
A286.2003-06-05 11:02:10	315
A286.2003-06-05 21:00:28	316
A286.2003-06-07 16:54:11	317
A286.2003-06-07 18:06:21	318
A286.2003-06-07 19:18:31	319
A286.2003-06-07 22:07:10	320
A286.2003-06-08 04:41:18	321
A286.2003-06-08 05:42:39	322
A286.2003-06-08 06:43:59	323
A286.2003-06-08 07:45:20	324
A286.2003-06-08 09:43:31	325
A286.2003-06-08 11:58:50	326
A286.2003-06-08 14:14:10	327
A286.2003-06-08 22:59:19	328
A286.2003-06-11 06:51:15	329
A286.2003-06-11 10:23:58	330
A286.2003-06-12 22:14:11	331
A286.2003-06-13 13:00:03	332
A286.2003-06-13 16:26:17	333
A286.2003-06-13 18:20:19	334
A286.2003-06-13 23:25:47	335
A289.2003-06-01 00:00:00	336
A289.2003-06-01 08:28:51	337
A289.2003-06-01 10:23:27	338
A289.2003-06-01 14:16:10	339
A289.2003-06-01 15:42:46	340
A289.2003-06-02 07:10:52	341
A289.2003-06-02 17:24:50	342
A289.2003-06-02 19:37:59	343
A289.2003-06-03 04:20:36	344
A289.2003-06-03 07:41:47	345
A289.2003-06-03 10:06:42	346
A289.2003-06-03 12:25:19	347
A289.2003-06-03 14:43:55	348
A289.2003-06-03 19:57:02	349
A289.2003-06-04 01:39:28	350
A289.2003-06-04 07:15:24	351
A289.2003-06-04 16:29:42	352
A289.2003-06-04 16:52:39	353
A289.2003-06-04 17:15:37	354
A289.2003-06-04 17:38:34	355
A289.2003-06-04 18:01:31	356
A289.2003-06-04 18:24:28	357
A289.2003-06-04 18:47:25	358
A289.2003-06-04 19:10:23	359
A289.2003-06-04 19:33:20	360
A289.2003-06-04 19:56:17	361
A289.2003-06-04 20:27:14	362
A289.2003-06-04 20:50:41	363
A289.2003-06-04 21:14:08	364
A289.2003-06-04 21:37:35	365
A289.2003-06-04 22:01:03	366
A289.2003-06-04 22:24:30	367
A289.2003-06-04 22:47:57	368
A289.2003-06-04 23:11:24	369
A289.2003-06-04 23:34:51	370
A289.2003-06-04 23:58:18	371
A289.2003-06-06 00:10:24	372
A289.2003-06-07 07:42:45	373
A289.2003-06-07 09:11:08	374
A289.2003-06-07 10:24:54	375
A289.2003-06-07 11:38:41	376
A289.2003-06-07 13:02:11	377
A289.2003-06-07 14:17:03	378
A289.2003-06-07 15:31:54	379
A289.2003-06-08 06:08:56	380
A289.2003-06-08 07:53:21	381
A289.2003-06-08 09:37:46	382
A289.2003-06-08 11:22:11	383
A289.2003-06-08 18:13:49	384
A289.2003-06-09 19:31:16	385
A289.2003-06-10 17:16:05	386
A289.2003-06-10 18:25:10	387
A289.2003-06-10 19:34:16	388
A289.2003-06-10 20:43:21	389
A289.2003-06-10 21:52:26	390
A289.2003-06-10 23:01:31	391
A289.2003-06-11 15:34:45	392
A289.2003-06-11 18:52:00	393
A289.2003-06-11 22:09:16	394
A289.2003-06-13 08:21:30	395
A289.2003-06-13 10:01:26	396
A289.2003-06-13 11:41:21	397
A289.2003-06-13 20:06:08	398
A289.2003-06-14 15:54:48	399
\.


--
-- TOC entry 3660 (class 0 OID 629568)
-- Dependencies: 227
-- Data for Name: pgtraj; Type: TABLE DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

COPY "pgtraj" ("id", "pgtraj_name", "proj4string", "time_zone", "note", "insert_timestamp") FROM stdin;
1	ibex_int_space	+init=epsg:3395 +proj=merc +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0	Europe/Paris	\N	2017-08-18 18:59:48.028048+02
\.


--
-- TOC entry 3708 (class 0 OID 0)
-- Dependencies: 226
-- Name: pgtraj_id_seq; Type: SEQUENCE SET; Schema: ibex_traj_materialized_bursts; Owner: -
--

SELECT pg_catalog.setval('"pgtraj_id_seq"', 1, true);


--
-- TOC entry 3664 (class 0 OID 629600)
-- Dependencies: 231
-- Data for Name: relocation; Type: TABLE DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

COPY "relocation" ("id", "geom", "relocation_time", "orig_id") FROM stdin;
1	0101000020430D00000000000020612B410000000099FB3E41	2003-06-01 00:00:00+02	\N
2	0101000020430D00000279F47E28612B4138BB38FA28FD3E41	2003-06-01 06:59:59+02	\N
3	0101000020430D00000679F47E28612B4132BB38FA28FD3E41	2003-06-01 06:59:59+02	\N
4	0101000020430D00003CF5D98A70612B412A971E5AB7FE3E41	2003-06-01 09:49:30+02	\N
5	0101000020430D00003BF5D98A70612B4145971E5AB7FE3E41	2003-06-01 09:49:30+02	\N
6	0101000020430D00005317618926632B414FA0801306003F41	2003-06-02 04:39:53+02	\N
7	0101000020430D00005017618926632B414EA0801306003F41	2003-06-02 04:39:54+02	\N
8	0101000020430D000049EC989D10642B4146FAFF9184013F41	2003-06-02 05:29:26+02	\N
9	0101000020430D00004BEC989D10642B4121FAFF9184013F41	2003-06-02 05:29:26+02	\N
10	0101000020430D0000D7B0D0B1FA642B4143397F1003033F41	2003-06-02 06:18:58+02	\N
11	0101000020430D0000D4B0D0B1FA642B4146397F1003033F41	2003-06-02 06:18:58+02	\N
12	0101000020430D0000CC8508C6E4652B413E93FE8E81043F41	2003-06-02 07:08:30+02	\N
13	0101000020430D0000CF8508C6E4652B414393FE8E81043F41	2003-06-02 07:08:31+02	\N
14	0101000020430D0000F03940DACE662B4191B77D0D00063F41	2003-06-02 07:58:03+02	\N
15	0101000020430D0000F13940DACE662B4191B77D0D00063F41	2003-06-02 07:58:03+02	\N
16	0101000020430D00000285BBA34C692B4121075E85F1063F41	2003-06-02 08:42:08+02	\N
17	0101000020430D0000FC84BBA34C692B411C075E85F1063F41	2003-06-02 08:42:08+02	\N
18	0101000020430D000004DB21A9D56B2B417EFFD762DB073F41	2003-06-02 09:25:39+02	\N
19	0101000020430D00000BDB21A9D56B2B4186FFD762DB073F41	2003-06-02 09:25:39+02	\N
20	0101000020430D0000E25188AE5E6E2B41BC035240C5083F41	2003-06-02 10:09:10+02	\N
21	0101000020430D0000DA5188AE5E6E2B41AE035240C5083F41	2003-06-02 10:09:09+02	\N
22	0101000020430D00005BADEEB3E7702B4109FECB1DAF093F41	2003-06-02 10:52:40+02	\N
23	0101000020430D000061ADEEB3E7702B411BFECB1DAF093F41	2003-06-02 10:52:40+02	\N
24	0101000020430D0000392455B970732B41500246FB980A3F41	2003-06-02 11:36:11+02	\N
25	0101000020430D0000392455B970732B41430246FB980A3F41	2003-06-02 11:36:10+02	\N
26	0101000020430D000002C71117F2752B4115FB6B11880B3F41	2003-06-02 12:45:24+02	\N
27	0101000020430D0000FDC61117F2752B4126FB6B11880B3F41	2003-06-02 12:45:24+02	\N
28	0101000020430D0000E5E50AFA69782B41003342627D0C3F41	2003-06-02 14:25:42+02	\N
29	0101000020430D0000EBE50AFA69782B41003342627D0C3F41	2003-06-02 14:25:42+02	\N
30	0101000020430D0000D98E7B30F27A2B41AF0B10CF670D3F41	2003-06-02 17:23:05+02	\N
31	0101000020430D0000D38E7B30F27A2B41BC0B10CF670D3F41	2003-06-02 17:23:06+02	\N
32	0101000020430D0000D3BFBF44ED7B2B4196DA1699E30E3F41	2003-06-03 09:30:33+02	\N
33	0101000020430D0000DABFBF44ED7B2B418DDA1699E30E3F41	2003-06-03 09:30:33+02	\N
34	0101000020430D00000771DBA9977A2B418BB5264C4D103F41	2003-06-03 11:07:00+02	\N
35	0101000020430D0000FF70DBA9977A2B4176B5264C4D103F41	2003-06-03 11:07:00+02	\N
36	0101000020430D0000745DCA0ED3782B415179502097113F41	2003-06-03 12:26:53+02	\N
37	0101000020430D0000765DCA0ED3782B416A79502097113F41	2003-06-03 12:26:53+02	\N
38	0101000020430D000044C05C7E9A762B415602AF85B0123F41	2003-06-03 13:24:36+02	\N
39	0101000020430D000042C05C7E9A762B413702AF85B0123F41	2003-06-03 13:24:37+02	\N
40	0101000020430D00008CD9EEED61742B4187AF0DEBC9133F41	2003-06-03 14:22:20+02	\N
41	0101000020430D000092D9EEED61742B4196AF0DEBC9133F41	2003-06-03 14:22:20+02	\N
42	0101000020430D00009E17815D29722B41B44A6C50E3143F41	2003-06-03 15:20:03+02	\N
43	0101000020430D0000A017815D29722B41AC4A6C50E3143F41	2003-06-03 15:20:03+02	\N
44	0101000020430D00006397843C11712B41609E6DFD59163F41	2003-06-03 16:41:55+02	\N
45	0101000020430D00005D97843C11712B41699E6DFD59163F41	2003-06-03 16:41:56+02	\N
46	0101000020430D0000B7D1524A01722B4191AAA18ED7173F41	2003-06-03 18:10:51+02	\N
47	0101000020430D0000BDD1524A01722B418AAAA18ED7173F41	2003-06-03 18:10:50+02	\N
48	0101000020430D0000160C2158F1722B41B2B6D51F55193F41	2003-06-03 19:39:45+02	\N
49	0101000020430D0000140C2158F1722B41ABB6D51F55193F41	2003-06-03 19:39:45+02	\N
50	0101000020430D0000D713DFE6D1742B41C5FE41EA941A3F41	2003-06-04 07:24:29+02	\N
51	0101000020430D0000D513DFE6D1742B41D3FE41EA941A3F41	2003-06-04 07:24:29+02	\N
52	0101000020430D0000237147C880722B41D7903757A11B3F41	2003-06-04 13:15:30+02	\N
53	0101000020430D0000257147C880722B41E6903757A11B3F41	2003-06-04 13:15:29+02	\N
54	0101000020430D00003EFC5AFAB2722B41D0F3FB20121A3F41	2003-06-04 18:37:18+02	\N
55	0101000020430D00003FFC5AFAB2722B41D7F3FB20121A3F41	2003-06-04 18:37:18+02	\N
56	0101000020430D00004B61499EC8742B4139BBB21FE8183F41	2003-06-05 00:21:52+02	\N
57	0101000020430D00004861499EC8742B4129BBB21FE8183F41	2003-06-05 00:21:51+02	\N
58	0101000020430D00004603116235762B416261751F84173F41	2003-06-05 00:50:16+02	\N
59	0101000020430D00004403116235762B415661751F84173F41	2003-06-05 00:50:17+02	\N
60	0101000020430D00003286D825A2772B41E025381F20163F41	2003-06-05 01:18:42+02	\N
61	0101000020430D00003686D825A2772B41E125381F20163F41	2003-06-05 01:18:42+02	\N
62	0101000020430D00009AF99FE90E792B4195F9FA1EBC143F41	2003-06-05 01:47:07+02	\N
63	0101000020430D000096F99FE90E792B41B1F9FA1EBC143F41	2003-06-05 01:47:08+02	\N
64	0101000020430D0000857C67AD7B7A2B413ABEBD1E58133F41	2003-06-05 02:15:33+02	\N
65	0101000020430D0000887C67AD7B7A2B413CBEBD1E58133F41	2003-06-05 02:15:33+02	\N
66	0101000020430D00000E2E2F71E87B2B414C55801EF4113F41	2003-06-05 02:43:58+02	\N
67	0101000020430D00000D2E2F71E87B2B412555801EF4113F41	2003-06-05 02:43:58+02	\N
68	0101000020430D000094DFF634557D2B4134EC421E90103F41	2003-06-05 03:12:23+02	\N
69	0101000020430D000092DFF634557D2B4139EC421E90103F41	2003-06-05 03:12:24+02	\N
70	0101000020430D00000772BEF8C17E2B419CA1051E2C0F3F41	2003-06-05 03:40:49+02	\N
71	0101000020430D00000572BEF8C17E2B41ABA1051E2C0F3F41	2003-06-05 03:40:49+02	\N
72	0101000020430D00005695277C3A7D2B4133174DF388103F41	2003-06-05 04:40:02+02	\N
73	0101000020430D00005695277C3A7D2B4135174DF388103F41	2003-06-05 04:40:03+02	\N
74	0101000020430D000083A934B2BD7B2B4123E544BBE8113F41	2003-06-05 05:03:58+02	\N
75	0101000020430D000089A934B2BD7B2B410CE544BBE8113F41	2003-06-05 05:03:58+02	\N
76	0101000020430D00008A9141E8407A2B41C9DB3C8348133F41	2003-06-05 05:27:53+02	\N
77	0101000020430D00008A9141E8407A2B41D3DB3C8348133F41	2003-06-05 05:27:54+02	\N
78	0101000020430D0000E19C4E1EC4782B41EBB1344BA8143F41	2003-06-05 05:51:49+02	\N
79	0101000020430D0000E09C4E1EC4782B41E3B1344BA8143F41	2003-06-05 05:51:49+02	\N
80	0101000020430D0000E1845B5447772B41A0A82C1308163F41	2003-06-05 06:15:44+02	\N
81	0101000020430D0000E1845B5447772B41ABA82C1308163F41	2003-06-05 06:15:44+02	\N
82	0101000020430D0000E26C688ACA752B41689F24DB67173F41	2003-06-05 06:39:39+02	\N
83	0101000020430D0000E26C688ACA752B41729F24DB67173F41	2003-06-05 06:39:40+02	\N
84	0101000020430D0000B85D75C04D742B41068E1CA3C7183F41	2003-06-05 07:03:35+02	\N
85	0101000020430D0000B65D75C04D742B41008E1CA3C7183F41	2003-06-05 07:03:35+02	\N
86	0101000020430D00008C4E82F6D0722B41947C146B271A3F41	2003-06-05 07:27:30+02	\N
87	0101000020430D00008B4E82F6D0722B418F7C146B271A3F41	2003-06-05 07:27:31+02	\N
88	0101000020430D00008C368F2C54712B414C730C33871B3F41	2003-06-05 07:51:26+02	\N
89	0101000020430D00008C368F2C54712B4156730C33871B3F41	2003-06-05 07:51:26+02	\N
90	0101000020430D0000BE32E36823702B415E566909F91C3F41	2003-06-05 09:51:46+02	\N
91	0101000020430D0000C032E36823702B415B566909F91C3F41	2003-06-05 09:51:46+02	\N
92	0101000020430D0000D96912DC13712B41BAB6A78A761E3F41	2003-06-05 14:38:14+02	\N
93	0101000020430D0000DC6912DC13712B41BEB6A78A761E3F41	2003-06-05 14:38:14+02	\N
94	0101000020430D0000C35D3FD033742B41286A4A3E721E3F41	2003-06-05 16:58:12+02	\N
95	0101000020430D0000C25D3FD033742B41316A4A3E721E3F41	2003-06-05 16:58:12+02	\N
96	0101000020430D000020DB16B544772B410866C7E0241E3F41	2003-06-05 18:17:33+02	\N
97	0101000020430D00001FDB16B544772B410666C7E0241E3F41	2003-06-05 18:17:33+02	\N
98	0101000020430D0000751EEE99557A2B4195674483D71D3F41	2003-06-05 19:36:54+02	\N
99	0101000020430D0000701EEE99557A2B418E674483D71D3F41	2003-06-05 19:36:54+02	\N
100	0101000020430D0000EAA1114E507B2B41B3FF295D531F3F41	2003-06-05 20:52:28+02	\N
101	0101000020430D0000F2A1114E507B2B41AEFF295D531F3F41	2003-06-05 20:52:28+02	\N
102	0101000020430D000091DD6A78667B2B412E33F635E3203F41	2003-06-05 21:44:37+02	\N
103	0101000020430D000091DD6A78667B2B412333F635E3203F41	2003-06-05 21:44:38+02	\N
104	0101000020430D0000CF34C3A27C7B2B41E34EB20E73223F41	2003-06-05 22:36:47+02	\N
105	0101000020430D0000C934C3A27C7B2B41F24EB20E73223F41	2003-06-05 22:36:47+02	\N
106	0101000020430D0000078C1BCD927B2B41B26A6EE702243F41	2003-06-05 23:28:56+02	\N
107	0101000020430D0000098C1BCD927B2B41C26A6EE702243F41	2003-06-05 23:28:56+02	\N
108	0101000020430D000092788966707D2B41DC3DDD01C2223F41	2003-06-06 00:51:21+02	\N
109	0101000020430D00008F788966707D2B41DE3DDD01C2223F41	2003-06-06 00:51:21+02	\N
110	0101000020430D00008D66104AA37E2B417822FF9B50213F41	2003-06-06 01:25:17+02	\N
111	0101000020430D00009166104AA37E2B415F22FF9B50213F41	2003-06-06 01:25:18+02	\N
112	0101000020430D00000F1D972DD67F2B41C7492136DF1F3F41	2003-06-06 01:59:14+02	\N
113	0101000020430D00000A1D972DD67F2B41D2492136DF1F3F41	2003-06-06 01:59:14+02	\N
114	0101000020430D000009E61D1109812B41F45A43D06D1E3F41	2003-06-06 02:33:10+02	\N
115	0101000020430D000009E61D1109812B41F45A43D06D1E3F41	2003-06-06 02:33:11+02	\N
116	0101000020430D000087C1A4F43B822B41D255656AFC1C3F41	2003-06-06 03:07:07+02	\N
117	0101000020430D00008DC1A4F43B822B41C555656AFC1C3F41	2003-06-06 03:07:07+02	\N
118	0101000020430D00000A9D2BD86E832B41A35087048B1B3F41	2003-06-06 03:41:03+02	\N
119	0101000020430D0000099D2BD86E832B41975087048B1B3F41	2003-06-06 03:41:04+02	\N
120	0101000020430D0000BB55538D46832B41E55B91821A1D3F41	2003-06-06 04:49:05+02	\N
121	0101000020430D0000BD55538D46832B41085C91821A1D3F41	2003-06-06 04:49:04+02	\N
122	0101000020430D0000A14084F3BC822B411CA4798CA41E3F41	2003-06-06 05:21:00+02	\N
123	0101000020430D0000A04084F3BC822B4106A4798CA41E3F41	2003-06-06 05:21:01+02	\N
124	0101000020430D00003B96B55933822B4186BA60962E203F41	2003-06-06 05:52:57+02	\N
125	0101000020430D00003696B55933822B4180BA60962E203F41	2003-06-06 05:52:57+02	\N
126	0101000020430D00001A81E6BFA9812B41940249A0B8213F41	2003-06-06 06:24:53+02	\N
127	0101000020430D00002081E6BFA9812B41A80249A0B8213F41	2003-06-06 06:24:53+02	\N
128	0101000020430D000060A1172620812B41F0B130AA42233F41	2003-06-06 06:56:49+02	\N
129	0101000020430D00005CA1172620812B41FAB130AA42233F41	2003-06-06 06:56:49+02	\N
130	0101000020430D0000EEA6488C96802B41AAAD18B4CC243F41	2003-06-06 07:28:45+02	\N
131	0101000020430D0000EBA6488C96802B41A1AD18B4CC243F41	2003-06-06 07:28:46+02	\N
132	0101000020430D00003026413A52812B410961548A51263F41	2003-06-06 14:36:43+02	\N
133	0101000020430D00003226413A52812B410061548A51263F41	2003-06-06 14:36:42+02	\N
134	0101000020430D000063D6EA0E64842B41BA7A907D9C263F41	2003-06-07 00:07:21+02	\N
135	0101000020430D000067D6EA0E64842B41B77A907D9C263F41	2003-06-07 00:07:21+02	\N
136	0101000020430D0000D6734FF538872B41E25ECCB145273F41	2003-06-07 00:51:04+02	\N
137	0101000020430D0000D3734FF538872B41E95ECCB145273F41	2003-06-07 00:51:04+02	\N
138	0101000020430D00004311B4DB0D8A2B41144308E6EE273F41	2003-06-07 01:34:47+02	\N
139	0101000020430D00004811B4DB0D8A2B411B4308E6EE273F41	2003-06-07 01:34:47+02	\N
140	0101000020430D000092C518C2E28C2B419C2C441A98283F41	2003-06-07 02:18:30+02	\N
141	0101000020430D00008EC518C2E28C2B41802C441A98283F41	2003-06-07 02:18:29+02	\N
142	0101000020430D000076817DA8B78F2B41C917804E41293F41	2003-06-07 03:02:12+02	\N
143	0101000020430D00007A817DA8B78F2B41E817804E41293F41	2003-06-07 03:02:12+02	\N
144	0101000020430D00003E54E28E8C922B418608BC82EA293F41	2003-06-07 03:45:55+02	\N
145	0101000020430D00003754E28E8C922B418408BC82EA293F41	2003-06-07 03:45:55+02	\N
146	0101000020430D0000F59B0965918F2B41E62DA98772293F41	2003-06-07 04:43:59+02	\N
147	0101000020430D0000FA9B0965918F2B41E12DA98772293F41	2003-06-07 04:43:59+02	\N
148	0101000020430D0000DDDA9A569E8C2B41D9C0B158EE283F41	2003-06-07 05:17:18+02	\N
149	0101000020430D0000DADA9A569E8C2B41D8C0B158EE283F41	2003-06-07 05:17:18+02	\N
150	0101000020430D000071782C48AB892B416364BA296A283F41	2003-06-07 05:50:37+02	\N
151	0101000020430D000073782C48AB892B416A64BA296A283F41	2003-06-07 05:50:37+02	\N
152	0101000020430D0000DCCCBD39B8862B4125FBC2FAE5273F41	2003-06-07 06:23:56+02	\N
153	0101000020430D0000DDCCBD39B8862B4112FBC2FAE5273F41	2003-06-07 06:23:57+02	\N
154	0101000020430D0000A0504F2BC5832B41189ACBCB61273F41	2003-06-07 06:57:16+02	\N
155	0101000020430D0000A0504F2BC5832B411D9ACBCB61273F41	2003-06-07 06:57:16+02	\N
156	0101000020430D0000C6CBE01CD2802B41A137D49CDD263F41	2003-06-07 07:30:35+02	\N
157	0101000020430D0000C3CBE01CD2802B41A537D49CDD263F41	2003-06-07 07:30:36+02	\N
158	0101000020430D0000004C74FEBD7D2B41DF4F52EE98263F41	2003-06-07 08:55:02+02	\N
159	0101000020430D0000024C74FEBD7D2B41D94F52EE98263F41	2003-06-07 08:55:02+02	\N
160	0101000020430D0000A54849BF667C2B41E9D9DB3D02283F41	2003-06-07 13:15:33+02	\N
161	0101000020430D0000A74849BF667C2B41DBD9DB3D02283F41	2003-06-07 13:15:33+02	\N
162	0101000020430D00001D003344EA7C2B413F0099CC8C293F41	2003-06-07 15:44:26+02	\N
163	0101000020430D000019003344EA7C2B41420099CC8C293F41	2003-06-07 15:44:27+02	\N
164	0101000020430D0000270745B9D9792B41A817638C3E293F41	2003-06-07 16:49:41+02	\N
165	0101000020430D0000240745B9D9792B41A717638C3E293F41	2003-06-07 16:49:41+02	\N
166	0101000020430D00001638474FDB762B41A1D252DDCB283F41	2003-06-07 17:37:23+02	\N
167	0101000020430D00001A38474FDB762B41B6D252DDCB283F41	2003-06-07 17:37:23+02	\N
168	0101000020430D0000073349E5DC732B419A85422E59283F41	2003-06-07 18:25:05+02	\N
169	0101000020430D00000B3349E5DC732B418C85422E59283F41	2003-06-07 18:25:05+02	\N
170	0101000020430D00007D5F4B7BDE702B41DA3F327FE6273F41	2003-06-07 19:12:47+02	\N
171	0101000020430D00007A5F4B7BDE702B41EE3F327FE6273F41	2003-06-07 19:12:47+02	\N
172	0101000020430D0000A73C3B70FC732B41EB714AEDC9273F41	2003-06-07 22:13:13+02	\N
173	0101000020430D0000A83C3B70FC732B41E9714AEDC9273F41	2003-06-07 22:13:13+02	\N
174	0101000020430D000066EC80B717772B4107CD3A52F5273F41	2003-06-07 23:21:17+02	\N
175	0101000020430D000060EC80B717772B4106CD3A52F5273F41	2003-06-07 23:21:17+02	\N
176	0101000020430D0000316E1B34A4792B4175A74EC3DC283F41	2003-06-08 01:08:26+02	\N
177	0101000020430D0000346E1B34A4792B4158A74EC3DC283F41	2003-06-08 01:08:26+02	\N
178	0101000020430D00000183DBCE007B2B410520F7C9442A3F41	2003-06-08 03:07:37+02	\N
179	0101000020430D00000483DBCE007B2B410820F7C9442A3F41	2003-06-08 03:07:37+02	\N
180	0101000020430D00008FFB660C547D2B418CD0218A39293F41	2003-06-08 05:47:35+02	\N
181	0101000020430D00008DFB660C547D2B418AD0218A39293F41	2003-06-08 05:47:35+02	\N
182	0101000020430D0000770B14D9C47E2B414C435394D6273F41	2003-06-08 07:17:21+02	\N
183	0101000020430D00007B0B14D9C47E2B4174435394D6273F41	2003-06-08 07:17:21+02	\N
184	0101000020430D000051ECC4B88E802B41EEA8D8951E293F41	2003-06-08 12:28:19+02	\N
185	0101000020430D000050ECC4B88E802B41CEA8D8951E293F41	2003-06-08 12:28:19+02	\N
186	0101000020430D0000D130B90FB97E2B4144D4F265622A3F41	2003-06-08 14:34:41+02	\N
187	0101000020430D0000CA30B90FB97E2B4148D4F265622A3F41	2003-06-08 14:34:41+02	\N
188	0101000020430D0000CAF8DF9AEC7F2B41B0F7F022F1283F41	2003-06-08 18:32:02+02	\N
189	0101000020430D0000CFF8DF9AEC7F2B41A4F7F022F1283F41	2003-06-08 18:32:02+02	\N
190	0101000020430D0000313318576D812B414285346E92273F41	2003-06-08 20:04:33+02	\N
191	0101000020430D0000303318576D812B414385346E92273F41	2003-06-08 20:04:33+02	\N
192	0101000020430D0000FBFF6E4BBE832B414A6AE9E985263F41	2003-06-08 22:00:15+02	\N
193	0101000020430D0000F9FF6E4BBE832B41676AE9E985263F41	2003-06-08 22:00:15+02	\N
194	0101000020430D000012A3C53F0F862B4151629E6579253F41	2003-06-08 23:55:57+02	\N
195	0101000020430D000015A3C53F0F862B4156629E6579253F41	2003-06-08 23:55:57+02	\N
196	0101000020430D0000479FD64794842B4106CB4EABD9263F41	2003-06-09 01:32:15+02	\N
197	0101000020430D0000459FD64794842B41E9CA4EABD9263F41	2003-06-09 01:32:14+02	\N
198	0101000020430D0000B639C35811832B4167301AC537283F41	2003-06-09 03:01:32+02	\N
199	0101000020430D0000B739C35811832B4183301AC537283F41	2003-06-09 03:01:32+02	\N
200	0101000020430D00002DEF6A1C33802B412084A1F298273F41	2003-06-09 05:05:43+02	\N
201	0101000020430D00002FEF6A1C33802B411F84A1F298273F41	2003-06-09 05:05:43+02	\N
202	0101000020430D0000237F19BF8D7E2B41A51FBEED44263F41	2003-06-09 06:03:18+02	\N
203	0101000020430D0000247F19BF8D7E2B418B1FBEED44263F41	2003-06-09 06:03:18+02	\N
204	0101000020430D00000F1BC861E87C2B41B9C4DAE8F0243F41	2003-06-09 07:00:53+02	\N
205	0101000020430D00000C1BC861E87C2B41B2C4DAE8F0243F41	2003-06-09 07:00:54+02	\N
206	0101000020430D000000AB7604437B2B413860F7E39C233F41	2003-06-09 07:58:29+02	\N
207	0101000020430D000002AB7604437B2B414960F7E39C233F41	2003-06-09 07:58:29+02	\N
208	0101000020430D0000CA3708C6267C2B4134E975561C253F41	2003-06-09 09:52:21+02	\N
209	0101000020430D0000CC3708C6267C2B413BE975561C253F41	2003-06-09 09:52:21+02	\N
210	0101000020430D00005689A0AA0F7D2B41CF0848039B263F41	2003-06-09 11:41:57+02	\N
211	0101000020430D00005689A0AA0F7D2B41D80848039B263F41	2003-06-09 11:41:57+02	\N
212	0101000020430D000028811B9EB97B2B41B614126B31253F41	2003-06-09 13:47:08+02	\N
213	0101000020430D000021811B9EB97B2B41AB14126B31253F41	2003-06-09 13:47:08+02	\N
214	0101000020430D000055CA3F92727A2B41C562BC5EC4233F41	2003-06-09 15:19:16+02	\N
215	0101000020430D000057CA3F92727A2B41C762BC5EC4233F41	2003-06-09 15:19:16+02	\N
216	0101000020430D00000743E926287D2B4154D9AF07FD223F41	2003-06-09 17:52:30+02	\N
217	0101000020430D00000B43E926287D2B414CD9AF07FD223F41	2003-06-09 17:52:30+02	\N
218	0101000020430D0000DBEC70E344802B417CDBAEEFD8223F41	2003-06-09 19:39:27+02	\N
219	0101000020430D0000DBEC70E344802B4175DBAEEFD8223F41	2003-06-09 19:39:26+02	\N
220	0101000020430D00009BA66FC3EB802B4196AFEFBB51213F41	2003-06-09 21:46:32+02	\N
221	0101000020430D00009BA66FC3EB802B41A6AFEFBB51213F41	2003-06-09 21:46:33+02	\N
222	0101000020430D0000F13E8E16FA802B41464C53CCC11F3F41	2003-06-09 23:37:27+02	\N
223	0101000020430D0000EA3E8E16FA802B412D4C53CCC11F3F41	2003-06-09 23:37:27+02	\N
224	0101000020430D0000D5CDAD6908812B418D049CDC311E3F41	2003-06-10 01:28:21+02	\N
225	0101000020430D0000D9CDAD6908812B41AE049CDC311E3F41	2003-06-10 01:28:21+02	\N
226	0101000020430D0000E849CFBC16812B41AEF4AEECA11C3F41	2003-06-10 03:19:15+02	\N
227	0101000020430D0000E649CFBC16812B41A0F4AEECA11C3F41	2003-06-10 03:19:15+02	\N
228	0101000020430D0000EA6322CDD07E2B41C02DC366B41D3F41	2003-06-10 04:39:28+02	\N
229	0101000020430D0000E96322CDD07E2B41BD2DC366B41D3F41	2003-06-10 04:39:28+02	\N
230	0101000020430D0000B217177A077D2B41DBD05299FC1E3F41	2003-06-10 05:10:13+02	\N
231	0101000020430D0000B817177A077D2B41DDD05299FC1E3F41	2003-06-10 05:10:13+02	\N
232	0101000020430D000006180C273E7B2B41123DE2CB44203F41	2003-06-10 05:40:58+02	\N
233	0101000020430D000000180C273E7B2B41213DE2CB44203F41	2003-06-10 05:40:57+02	\N
234	0101000020430D0000570101D474792B41D0B971FE8C213F41	2003-06-10 06:11:42+02	\N
235	0101000020430D00005D0101D474792B41D7B971FE8C213F41	2003-06-10 06:11:42+02	\N
236	0101000020430D000019CCF580AB772B417E4C0131D5223F41	2003-06-10 06:42:27+02	\N
237	0101000020430D000017CCF580AB772B415B4C0131D5223F41	2003-06-10 06:42:27+02	\N
238	0101000020430D00000AD4EA2DE2752B4113B390631D243F41	2003-06-10 07:13:12+02	\N
239	0101000020430D000005D4EA2DE2752B4116B390631D243F41	2003-06-10 07:13:11+02	\N
240	0101000020430D00005CBDDFDA18742B41C52F209665253F41	2003-06-10 07:43:56+02	\N
241	0101000020430D000062BDDFDA18742B41CB2F209665253F41	2003-06-10 07:43:56+02	\N
242	0101000020430D0000D43FE0BE33772B41B4776A7338253F41	2003-06-10 11:09:40+02	\N
243	0101000020430D0000CF3FE0BE33772B41C3776A7338253F41	2003-06-10 11:09:40+02	\N
244	0101000020430D0000DC503A9AF2782B4168250DABEC233F41	2003-06-10 12:57:51+02	\N
245	0101000020430D0000DF503A9AF2782B4157250DABEC233F41	2003-06-10 12:57:51+02	\N
246	0101000020430D0000A6A547ACE2792B41291D841A6F223F41	2003-06-10 14:18:19+02	\N
247	0101000020430D0000A8A547ACE2792B41311D841A6F223F41	2003-06-10 14:18:19+02	\N
248	0101000020430D0000270C55BED27A2B41DBF8FA89F1203F41	2003-06-10 15:38:47+02	\N
249	0101000020430D0000210C55BED27A2B41DAF8FA89F1203F41	2003-06-10 15:38:47+02	\N
250	0101000020430D0000DFC3B755987B2B41BC1A742575223F41	2003-06-10 17:15:40+02	\N
251	0101000020430D0000E2C3B755987B2B41AF1A742575223F41	2003-06-10 17:15:40+02	\N
252	0101000020430D00000C818762057C2B414748A46901243F41	2003-06-10 18:17:06+02	\N
253	0101000020430D00000B818762057C2B414948A46901243F41	2003-06-10 18:17:07+02	\N
254	0101000020430D00001709576F727C2B41D9B4D3AD8D253F41	2003-06-10 19:18:33+02	\N
255	0101000020430D00001509576F727C2B41F3B4D3AD8D253F41	2003-06-10 19:18:33+02	\N
256	0101000020430D0000194D11741A7B2B41F5A0A1D0F6263F41	2003-06-10 20:33:36+02	\N
257	0101000020430D00001E4D11741A7B2B41FAA0A1D0F6263F41	2003-06-10 20:33:36+02	\N
258	0101000020430D0000AE1A07BE40782B41875E7AC49A273F41	2003-06-10 21:32:20+02	\N
259	0101000020430D0000AF1A07BE40782B416B5E7AC49A273F41	2003-06-10 21:32:20+02	\N
260	0101000020430D0000B5D8FC0767752B41771F53B83E283F41	2003-06-10 22:31:04+02	\N
261	0101000020430D0000B7D8FC0767752B418D1F53B83E283F41	2003-06-10 22:31:03+02	\N
262	0101000020430D0000FCF3F2518D722B41A5CB2BACE2283F41	2003-06-10 23:29:47+02	\N
263	0101000020430D0000F5F3F2518D722B418BCB2BACE2283F41	2003-06-10 23:29:47+02	\N
264	0101000020430D000016B4892B86742B41EBBB21F7182A3F41	2003-06-11 00:43:04+02	\N
265	0101000020430D000016B4892B86742B41E7BB21F7182A3F41	2003-06-11 00:43:04+02	\N
266	0101000020430D00005364F1D64D772B413469F5ABCF2A3F41	2003-06-11 01:17:54+02	\N
267	0101000020430D00005364F1D64D772B414E69F5ABCF2A3F41	2003-06-11 01:17:54+02	\N
268	0101000020430D000026065982157A2B41E612C960862B3F41	2003-06-11 01:52:44+02	\N
269	0101000020430D00002C065982157A2B41D912C960862B3F41	2003-06-11 01:52:43+02	\N
270	0101000020430D00009EBDC02DDD7C2B41FFC19C153D2C3F41	2003-06-11 02:27:33+02	\N
271	0101000020430D000097BDC02DDD7C2B41EDC19C153D2C3F41	2003-06-11 02:27:33+02	\N
272	0101000020430D0000D36D28D9A47F2B41396F70CAF32C3F41	2003-06-11 03:02:23+02	\N
273	0101000020430D0000D56D28D9A47F2B41546F70CAF32C3F41	2003-06-11 03:02:23+02	\N
274	0101000020430D0000554990846C822B41BC27447FAA2D3F41	2003-06-11 03:37:13+02	\N
275	0101000020430D00005B4990846C822B41A227447FAA2D3F41	2003-06-11 03:37:13+02	\N
276	0101000020430D000003E1761050812B41A93C05A3342C3F41	2003-06-11 05:10:51+02	\N
277	0101000020430D0000FFE0761050812B41AB3C05A3342C3F41	2003-06-11 05:10:51+02	\N
278	0101000020430D00006CD3EFFC6B7F2B4153A5F32CF62A3F41	2003-06-11 05:56:35+02	\N
279	0101000020430D00006BD3EFFC6B7F2B4154A5F32CF62A3F41	2003-06-11 05:56:35+02	\N
280	0101000020430D0000D8C568E9877D2B41FC0DE2B6B7293F41	2003-06-11 06:42:19+02	\N
281	0101000020430D0000D6C568E9877D2B41FD0DE2B6B7293F41	2003-06-11 06:42:20+02	\N
282	0101000020430D000056C1E1D5A37B2B419E7CD04079283F41	2003-06-11 07:28:04+02	\N
283	0101000020430D000059C1E1D5A37B2B41B07CD04079283F41	2003-06-11 07:28:04+02	\N
284	0101000020430D000072BCC09311792B41FC571CEF95273F41	2003-06-11 13:03:57+02	\N
285	0101000020430D000073BCC09311792B41FA571CEF95273F41	2003-06-11 13:03:57+02	\N
286	0101000020430D0000BC1DB2225E792B41381D231924293F41	2003-06-12 02:26:17+02	\N
287	0101000020430D0000B91DB2225E792B413B1D231924293F41	2003-06-12 02:26:17+02	\N
288	0101000020430D0000D16A50A96E762B41D9C0FAE79A283F41	2003-06-12 06:04:42+02	\N
289	0101000020430D0000D26A50A96E762B41D1C0FAE79A283F41	2003-06-12 06:04:42+02	\N
290	0101000020430D000015DD22D905742B41FD061B2E9C273F41	2003-06-12 07:26:46+02	\N
291	0101000020430D000014DD22D905742B4117071B2E9C273F41	2003-06-12 07:26:45+02	\N
292	0101000020430D0000DD8C609B16762B413570F00170263F41	2003-06-12 08:44:56+02	\N
293	0101000020430D0000DE8C609B16762B411570F00170263F41	2003-06-12 08:44:56+02	\N
294	0101000020430D00006F9D796CE0782B417A8F4F68BB253F41	2003-06-12 09:26:08+02	\N
295	0101000020430D0000729D796CE0782B418A8F4F68BB253F41	2003-06-12 09:26:08+02	\N
296	0101000020430D0000142B923DAA7B2B410FD0AECE06253F41	2003-06-12 10:07:20+02	\N
297	0101000020430D0000102B923DAA7B2B410DD0AECE06253F41	2003-06-12 10:07:20+02	\N
298	0101000020430D0000E0A2AA0E747E2B4119160E3552243F41	2003-06-12 10:48:32+02	\N
299	0101000020430D0000DFA2AA0E747E2B4118160E3552243F41	2003-06-12 10:48:32+02	\N
300	0101000020430D00003F79C3DF3D812B4136446D9B9D233F41	2003-06-12 11:29:44+02	\N
301	0101000020430D00004579C3DF3D812B4126446D9B9D233F41	2003-06-12 11:29:44+02	\N
302	0101000020430D000047D62D88F77E2B41D2F563DEAF243F41	2003-06-12 14:41:07+02	\N
303	0101000020430D000041D62D88F77E2B41F4F563DEAF243F41	2003-06-12 14:41:08+02	\N
304	0101000020430D00002A48180E737C2B41222BD1DA9C253F41	2003-06-12 16:14:59+02	\N
305	0101000020430D00002948180E737C2B41002BD1DA9C253F41	2003-06-12 16:14:59+02	\N
306	0101000020430D0000C6690294EE792B41B57D3ED789263F41	2003-06-12 17:48:50+02	\N
307	0101000020430D0000CE690294EE792B41BF7D3ED789263F41	2003-06-12 17:48:50+02	\N
308	0101000020430D0000D5A0EC196A772B4194C8ABD376273F41	2003-06-12 19:22:41+02	\N
309	0101000020430D0000D3A0EC196A772B419BC8ABD376273F41	2003-06-12 19:22:42+02	\N
310	0101000020430D0000A515602C6C7A2B41196E2936E3273F41	2003-06-12 23:55:13+02	\N
311	0101000020430D0000A615602C6C7A2B410D6E2936E3273F41	2003-06-12 23:55:13+02	\N
312	0101000020430D00000A16DCDD8B7D2B41245F5E49EE273F41	2003-06-13 02:58:32+02	\N
313	0101000020430D00000516DCDD8B7D2B41315F5E49EE273F41	2003-06-13 02:58:32+02	\N
314	0101000020430D0000F48545CA737C2B4194AED9F864293F41	2003-06-13 09:42:42+02	\N
315	0101000020430D0000FA8545CA737C2B4188AED9F864293F41	2003-06-13 09:42:42+02	\N
316	0101000020430D0000A449EBF84A7C2B4188C67673F42A3F41	2003-06-13 11:03:00+02	\N
317	0101000020430D0000A149EBF84A7C2B4186C67673F42A3F41	2003-06-13 11:03:00+02	\N
318	0101000020430D00007B74EE70D77B2B4176E7E2A468293F41	2003-06-13 17:14:45+02	\N
319	0101000020430D00007974EE70D77B2B416BE7E2A468293F41	2003-06-13 17:14:45+02	\N
320	0101000020430D00000CB9573A777B2B418597248CDB273F41	2003-06-13 20:49:31+02	\N
321	0101000020430D00000BB9573A777B2B418F97248CDB273F41	2003-06-13 20:49:32+02	\N
322	0101000020430D00005B233ADC64782B418C63C50492273F41	2003-06-14 08:44:52+02	\N
323	0101000020430D00005F233ADC64782B41A263C50492273F41	2003-06-14 08:44:51+02	\N
324	0101000020430D00005B74243055752B41A4FEA96BE2273F41	2003-06-14 14:25:39+02	\N
325	0101000020430D00005C74243055752B4197FEA96BE2273F41	2003-06-14 14:25:39+02	\N
326	0101000020430D00001A83C4B858782B41BF31BA2C4C283F41	2003-06-14 18:33:10+02	\N
327	0101000020430D00001683C4B858782B41C031BA2C4C283F41	2003-06-14 18:33:09+02	\N
328	\N	\N	\N
329	0101000020430D00000000000058662B41000000004A023F41	2003-06-01 08:00:00+02	\N
330	0101000020430D0000721CEE2167632B41214D30BBC2013F41	2003-06-01 11:05:31+02	\N
331	0101000020430D0000751CEE2167632B41254D30BBC2013F41	2003-06-01 11:05:30+02	\N
332	0101000020430D0000707AF16ADC602B41EA38B00BDA003F41	2003-06-01 12:45:10+02	\N
333	0101000020430D0000707AF16ADC602B41ED38B00BDA003F41	2003-06-01 12:45:10+02	\N
334	0101000020430D00007BD1374A895E2B4161B4CFBBCEFF3E41	2003-06-01 13:47:45+02	\N
335	0101000020430D000075D1374A895E2B415EB4CFBBCEFF3E41	2003-06-01 13:47:46+02	\N
336	0101000020430D000011207E29365C2B410A2CEF6BC3FE3E41	2003-06-01 14:50:21+02	\N
337	0101000020430D000016207E29365C2B41F22BEF6BC3FE3E41	2003-06-01 14:50:21+02	\N
338	0101000020430D00006D90C408E3592B41C4B20E1CB8FD3E41	2003-06-01 15:52:56+02	\N
339	0101000020430D00006890C408E3592B41CBB20E1CB8FD3E41	2003-06-01 15:52:56+02	\N
340	0101000020430D00003EC06FC54D5C2B418720A4AAB5FE3E41	2003-06-01 18:55:27+02	\N
341	0101000020430D00003EC06FC54D5C2B418620A4AAB5FE3E41	2003-06-01 18:55:27+02	\N
342	0101000020430D00005F84441D84592B41A0A6B06C6AFF3E41	2003-06-01 20:51:48+02	\N
343	0101000020430D00006184441D84592B41A6A6B06C6AFF3E41	2003-06-01 20:51:48+02	\N
344	0101000020430D00005D596CF26D562B41582E15F2A8FF3E41	2003-06-01 21:34:11+02	\N
345	0101000020430D00005E596CF26D562B41652E15F2A8FF3E41	2003-06-01 21:34:12+02	\N
346	0101000020430D00007B9093C757532B4195C27977E7FF3E41	2003-06-01 22:16:35+02	\N
347	0101000020430D00007C9093C757532B418FC27977E7FF3E41	2003-06-01 22:16:35+02	\N
348	0101000020430D0000761BBB9C41502B411B50DEFC25003F41	2003-06-01 22:58:58+02	\N
349	0101000020430D0000741BBB9C41502B412D50DEFC25003F41	2003-06-01 22:58:58+02	\N
350	0101000020430D0000D688E2712B4D2B4112E0428264003F41	2003-06-01 23:41:21+02	\N
351	0101000020430D0000D488E2712B4D2B41F9DF428264003F41	2003-06-01 23:41:21+02	\N
352	0101000020430D0000EF3C7B22C64F2B414A75859941013F41	2003-06-02 01:43:28+02	\N
353	0101000020430D0000F33C7B22C64F2B414A75859941013F41	2003-06-02 01:43:28+02	\N
354	0101000020430D0000208A6483B1522B41BF867846D0013F41	2003-06-02 02:59:44+02	\N
355	0101000020430D0000218A6483B1522B41CF867846D0013F41	2003-06-02 02:59:44+02	\N
356	0101000020430D00006F7ECF81D1552B41D44DC3D8D1013F41	2003-06-02 04:20:12+02	\N
357	0101000020430D0000697ECF81D1552B41C84DC3D8D1013F41	2003-06-02 04:20:12+02	\N
358	0101000020430D000097C6152FF6572B41620782BFAE003F41	2003-06-02 05:13:08+02	\N
359	0101000020430D000099C6152FF6572B41570782BFAE003F41	2003-06-02 05:13:08+02	\N
360	0101000020430D0000AC645CDC1A5A2B415F9340A68BFF3E41	2003-06-02 06:06:04+02	\N
361	0101000020430D0000B0645CDC1A5A2B416E9340A68BFF3E41	2003-06-02 06:06:03+02	\N
362	0101000020430D0000F1EEA2893F5C2B41FA29FF8C68FE3E41	2003-06-02 06:58:59+02	\N
363	0101000020430D0000F2EEA2893F5C2B41EC29FF8C68FE3E41	2003-06-02 06:58:59+02	\N
364	0101000020430D00002958E936645E2B4100D2BD7345FD3E41	2003-06-02 07:51:55+02	\N
365	0101000020430D00002658E936645E2B4108D2BD7345FD3E41	2003-06-02 07:51:55+02	\N
366	0101000020430D0000C70A21D4955C2B41B0FD2FDF8BFE3E41	2003-06-02 09:54:29+02	\N
367	0101000020430D0000C50A21D4955C2B41CAFD2FDF8BFE3E41	2003-06-02 09:54:28+02	\N
368	0101000020430D000019A23C7BBB5A2B4140CDE4F8CDFF3E41	2003-06-02 11:33:54+02	\N
369	0101000020430D00001DA23C7BBB5A2B411FCDE4F8CDFF3E41	2003-06-02 11:33:54+02	\N
370	0101000020430D0000D18E5822E1582B419C62991210013F41	2003-06-02 13:13:20+02	\N
371	0101000020430D0000D18E5822E1582B41BD62991210013F41	2003-06-02 13:13:20+02	\N
372	0101000020430D0000AE2E74C906572B41672C4E2C52023F41	2003-06-02 14:52:46+02	\N
373	0101000020430D0000AF2E74C906572B415E2C4E2C52023F41	2003-06-02 14:52:45+02	\N
374	0101000020430D0000A04C3D307A582B41FDDF4BE4EF003F41	2003-06-02 17:18:57+02	\N
375	0101000020430D00009A4C3D307A582B41FDDF4BE4EF003F41	2003-06-02 17:18:57+02	\N
376	0101000020430D00002B367845185A2B41C4C0C1A499FF3E41	2003-06-02 18:06:11+02	\N
377	0101000020430D00002E367845185A2B41AAC0C1A499FF3E41	2003-06-02 18:06:11+02	\N
378	0101000020430D00007736B35AB65B2B41AA8E376543FE3E41	2003-06-02 18:53:25+02	\N
379	0101000020430D00007936B35AB65B2B41B88E376543FE3E41	2003-06-02 18:53:25+02	\N
380	0101000020430D0000AD14EE6F545D2B41E478AD25EDFC3E41	2003-06-02 19:40:39+02	\N
381	0101000020430D0000AC14EE6F545D2B41F578AD25EDFC3E41	2003-06-02 19:40:39+02	\N
382	0101000020430D00001BF12F66FA5B2B414DC3A7CA55FE3E41	2003-06-03 09:27:21+02	\N
383	0101000020430D00001BF12F66FA5B2B4128C3A7CA55FE3E41	2003-06-03 09:27:21+02	\N
384	0101000020430D0000FFBB5BC03E5A2B418AC231A6A2FF3E41	2003-06-03 11:24:14+02	\N
385	0101000020430D000002BC5BC03E5A2B419BC231A6A2FF3E41	2003-06-03 11:24:14+02	\N
386	0101000020430D0000F371871A83582B41B4D1BB81EF003F41	2003-06-03 13:21:07+02	\N
387	0101000020430D0000F171871A83582B41A8D1BB81EF003F41	2003-06-03 13:21:06+02	\N
388	0101000020430D0000D63CB374C7562B4109D1455D3C023F41	2003-06-03 15:17:59+02	\N
389	0101000020430D0000D03CB374C7562B411BD1455D3C023F41	2003-06-03 15:17:59+02	\N
390	0101000020430D00009FD67B0EA5582B41D8E2D677FB003F41	2003-06-03 17:19:08+02	\N
391	0101000020430D0000A1D67B0EA5582B41D0E2D677FB003F41	2003-06-03 17:19:08+02	\N
392	0101000020430D00003849A4CD795A2B4116210E53B7FF3E41	2003-06-03 18:17:22+02	\N
393	0101000020430D00003A49A4CD795A2B412B210E53B7FF3E41	2003-06-03 18:17:22+02	\N
394	0101000020430D000056ABCC8C4E5C2B41D76A452E73FE3E41	2003-06-03 19:15:36+02	\N
395	0101000020430D000059ABCC8C4E5C2B41C36A452E73FE3E41	2003-06-03 19:15:35+02	\N
396	0101000020430D0000CE74C7DB0E5E2B41833D3579BEFF3E41	2003-06-04 08:24:16+02	\N
397	0101000020430D0000C974C7DB0E5E2B417A3D3579BEFF3E41	2003-06-04 08:24:16+02	\N
398	0101000020430D0000438DA696D5602B41E9D2861776003F41	2003-06-04 11:34:13+02	\N
399	0101000020430D0000488DA696D5602B41EDD2861776003F41	2003-06-04 11:34:13+02	\N
400	0101000020430D0000EFED819DB55D2B416C777C5D79003F41	2003-06-05 01:05:45+02	\N
401	0101000020430D0000F0ED819DB55D2B4175777C5D79003F41	2003-06-05 01:05:45+02	\N
402	0101000020430D00001C648B1A005C2B412AB7423FC8013F41	2003-06-05 02:13:14+02	\N
403	0101000020430D000019648B1A005C2B4135B7423FC8013F41	2003-06-05 02:13:14+02	\N
404	0101000020430D0000770295974A5A2B4126D8082117033F41	2003-06-05 03:20:43+02	\N
405	0101000020430D0000750295974A5A2B4116D8082117033F41	2003-06-05 03:20:43+02	\N
406	0101000020430D000041F03BEF1E5A2B41C657A0B987013F41	2003-06-05 05:33:23+02	\N
407	0101000020430D000046F03BEF1E5A2B41CF57A0B987013F41	2003-06-05 05:33:24+02	\N
408	0101000020430D00000C7B52BAAA5A2B41873C1EE1FDFF3E41	2003-06-05 06:35:18+02	\N
409	0101000020430D0000087B52BAAA5A2B41813C1EE1FDFF3E41	2003-06-05 06:35:18+02	\N
410	0101000020430D0000D4E96885365B2B410D709C0874FE3E41	2003-06-05 07:37:12+02	\N
411	0101000020430D0000D7E96885365B2B410E709C0874FE3E41	2003-06-05 07:37:12+02	\N
412	0101000020430D00000D40A344AA582B41BE29D6A35BFF3E41	2003-06-05 09:29:24+02	\N
413	0101000020430D00000C40A344AA582B41C329D6A35BFF3E41	2003-06-05 09:29:24+02	\N
414	0101000020430D0000A206AD2288562B412E39A9EE7F003F41	2003-06-05 10:38:47+02	\N
415	0101000020430D0000A306AD2288562B411F39A9EE7F003F41	2003-06-05 10:38:47+02	\N
416	0101000020430D000050F4B60066542B419D337C39A4013F41	2003-06-05 11:48:10+02	\N
417	0101000020430D000051F4B60066542B41AD337C39A4013F41	2003-06-05 11:48:11+02	\N
418	0101000020430D00007CDBC0DE43522B41A7314F84C8023F41	2003-06-05 12:57:34+02	\N
419	0101000020430D000074DBC0DE43522B4196314F84C8023F41	2003-06-05 12:57:34+02	\N
420	0101000020430D000097B5CABC21502B41893622CFEC033F41	2003-06-05 14:06:57+02	\N
421	0101000020430D00009BB5CABC21502B418C3622CFEC033F41	2003-06-05 14:06:57+02	\N
422	0101000020430D0000D5B6D49AFF4D2B419426F51911053F41	2003-06-05 15:16:20+02	\N
423	0101000020430D0000D1B6D49AFF4D2B41B326F51911053F41	2003-06-05 15:16:20+02	\N
424	0101000020430D000060C7B59EE84E2B411DE6E57192033F41	2003-06-05 17:17:55+02	\N
425	0101000020430D000066C7B59EE84E2B41F8E5E57192033F41	2003-06-05 17:17:55+02	\N
426	0101000020430D00004E9EC97253502B415FA11BF32D023F41	2003-06-05 18:06:57+02	\N
427	0101000020430D00004D9EC97253502B4171A11BF32D023F41	2003-06-05 18:06:57+02	\N
428	0101000020430D0000A1C1DD46BE512B41C2115174C9003F41	2003-06-05 18:55:59+02	\N
429	0101000020430D0000A3C1DD46BE512B41C0115174C9003F41	2003-06-05 18:55:59+02	\N
430	0101000020430D00004189F11A29532B412DDC86F564FF3E41	2003-06-05 19:45:01+02	\N
431	0101000020430D00003C89F11A29532B4128DC86F564FF3E41	2003-06-05 19:45:00+02	\N
432	0101000020430D0000AEB4B91F45562B413E7A2E1A3DFF3E41	2003-06-06 14:21:53+02	\N
433	0101000020430D0000B1B4B91F45562B413C7A2E1A3DFF3E41	2003-06-06 14:21:53+02	\N
434	0101000020430D00001E0FB67174582B417F69C51C1FFE3E41	2003-06-06 17:49:02+02	\N
435	0101000020430D00001B0FB67174582B418169C51C1FFE3E41	2003-06-06 17:49:03+02	\N
436	0101000020430D00008A00B2C3A35A2B41738E5C1F01FD3E41	2003-06-06 21:16:12+02	\N
437	0101000020430D00009000B2C3A35A2B41768E5C1F01FD3E41	2003-06-06 21:16:12+02	\N
438	0101000020430D000090A6B396C35D2B412B4103BDF8FC3E41	2003-06-07 07:19:14+02	\N
439	0101000020430D00008BA6B396C35D2B41284103BDF8FC3E41	2003-06-07 07:19:14+02	\N
440	0101000020430D00002E580E97D95A2B41465C463589FD3E41	2003-06-08 05:22:22+02	\N
441	0101000020430D000032580E97D95A2B415B5C463589FD3E41	2003-06-08 05:22:23+02	\N
442	0101000020430D0000A51733A9D8572B41009F549AF7FD3E41	2003-06-08 08:42:50+02	\N
443	0101000020430D00009E1733A9D8572B41E99E549AF7FD3E41	2003-06-08 08:42:50+02	\N
444	0101000020430D00006D20523EE4542B41B70088D379FE3E41	2003-06-08 09:57:36+02	\N
445	0101000020430D00006F20523EE4542B41C00088D379FE3E41	2003-06-08 09:57:36+02	\N
446	0101000020430D00007C6E71D3EF512B41A256BB0CFCFE3E41	2003-06-08 11:12:22+02	\N
447	0101000020430D0000826E71D3EF512B41AE56BB0CFCFE3E41	2003-06-08 11:12:22+02	\N
448	0101000020430D00005DFE5B01D0542B41BB103A7E5FFE3E41	2003-06-08 22:14:07+02	\N
449	0101000020430D000059FE5B01D0542B419D103A7E5FFE3E41	2003-06-08 22:14:07+02	\N
450	0101000020430D00009990FF7FB8572B417165BD18CDFD3E41	2003-06-09 04:29:30+02	\N
451	0101000020430D00009990FF7FB8572B417C65BD18CDFD3E41	2003-06-09 04:29:29+02	\N
452	0101000020430D00004030333CA15A2B41E912DD2F5FFE3E41	2003-06-09 09:00:10+02	\N
453	0101000020430D00003F30333CA15A2B41EB12DD2F5FFE3E41	2003-06-09 09:00:10+02	\N
454	0101000020430D0000B4865A68735C2B4182D9E641A4FF3E41	2003-06-09 10:25:54+02	\N
455	0101000020430D0000B4865A68735C2B4193D9E641A4FF3E41	2003-06-09 10:25:54+02	\N
456	0101000020430D000044E58194455E2B41D0A5F053E9003F41	2003-06-09 11:51:38+02	\N
457	0101000020430D000048E58194455E2B41C5A5F053E9003F41	2003-06-09 11:51:38+02	\N
458	0101000020430D00000D54A9C017602B414F7DFA652E023F41	2003-06-09 13:17:22+02	\N
459	0101000020430D00000854A9C017602B415F7DFA652E023F41	2003-06-09 13:17:22+02	\N
460	0101000020430D000097B2D0ECE9612B419C49047873033F41	2003-06-09 14:43:06+02	\N
461	0101000020430D00009CB2D0ECE9612B419149047873033F41	2003-06-09 14:43:06+02	\N
462	0101000020430D00005157DA7D1D5F2B417910557AC1023F41	2003-06-09 18:02:28+02	\N
463	0101000020430D00004F57DA7D1D5F2B417E10557AC1023F41	2003-06-09 18:02:29+02	\N
464	0101000020430D00007F72B636B55C2B41CBB4966DC2013F41	2003-06-09 19:09:01+02	\N
465	0101000020430D00007F72B636B55C2B41B8B4966DC2013F41	2003-06-09 19:09:01+02	\N
466	0101000020430D000022B392EF4C5A2B418468D860C3003F41	2003-06-09 20:15:33+02	\N
467	0101000020430D000020B392EF4C5A2B418C68D860C3003F41	2003-06-09 20:15:33+02	\N
468	0101000020430D000024966EA8E4572B4199F51954C4FF3E41	2003-06-09 21:22:05+02	\N
469	0101000020430D000025966EA8E4572B419FF51954C4FF3E41	2003-06-09 21:22:05+02	\N
470	0101000020430D00000FC44A617C552B41ACA15B47C5FE3E41	2003-06-09 22:28:37+02	\N
471	0101000020430D00000DC44A617C552B4191A15B47C5FE3E41	2003-06-09 22:28:37+02	\N
472	0101000020430D0000CAB9261A14532B415D369D3AC6FD3E41	2003-06-09 23:35:09+02	\N
473	0101000020430D0000CBB9261A14532B415C369D3AC6FD3E41	2003-06-09 23:35:09+02	\N
474	0101000020430D0000253ADEF4A6552B4138B5B21DA9FE3E41	2003-06-10 00:35:51+02	\N
475	0101000020430D00002A3ADEF4A6552B4149B5B21DA9FE3E41	2003-06-10 00:35:51+02	\N
476	0101000020430D0000250243BC2E582B4123FA30D793FF3E41	2003-06-10 01:01:59+02	\N
477	0101000020430D0000220243BC2E582B411EFA30D793FF3E41	2003-06-10 01:01:59+02	\N
478	0101000020430D0000BDEAA783B65A2B41CA4AAF907E003F41	2003-06-10 01:28:07+02	\N
479	0101000020430D0000C0EAA783B65A2B41DC4AAF907E003F41	2003-06-10 01:28:06+02	\N
480	0101000020430D0000BCB20C4B3E5D2B41B68F2D4A69013F41	2003-06-10 01:54:14+02	\N
481	0101000020430D0000B8B20C4B3E5D2B41B08F2D4A69013F41	2003-06-10 01:54:14+02	\N
482	0101000020430D000025807112C65F2B4182D6AB0354023F41	2003-06-10 02:20:22+02	\N
483	0101000020430D000029807112C65F2B4188D6AB0354023F41	2003-06-10 02:20:22+02	\N
484	0101000020430D00008627D6D94D622B41900F2ABD3E033F41	2003-06-10 02:46:30+02	\N
485	0101000020430D00008327D6D94D622B41730F2ABD3E033F41	2003-06-10 02:46:30+02	\N
486	0101000020430D00005DFA3AA1D5642B413D58A87629043F41	2003-06-10 03:12:38+02	\N
487	0101000020430D00005BFA3AA1D5642B414E58A87629043F41	2003-06-10 03:12:37+02	\N
488	0101000020430D0000E8BC9F685D672B41309B263014053F41	2003-06-10 03:38:45+02	\N
489	0101000020430D0000ECBC9F685D672B411F9B263014053F41	2003-06-10 03:38:45+02	\N
490	0101000020430D00001C10E2C2BA652B415FB6B954BF033F41	2003-06-10 04:53:16+02	\N
491	0101000020430D00001A10E2C2BA652B4170B6B954BF033F41	2003-06-10 04:53:16+02	\N
492	0101000020430D000083BA3341A7632B412438C65F94023F41	2003-06-10 05:23:13+02	\N
493	0101000020430D00007EBA3341A7632B413338C65F94023F41	2003-06-10 05:23:14+02	\N
494	0101000020430D0000E04085BF93612B41A2A5D26A69013F41	2003-06-10 05:53:11+02	\N
495	0101000020430D0000E14085BF93612B41AAA5D26A69013F41	2003-06-10 05:53:11+02	\N
496	0101000020430D00004BEBD63D805F2B415D27DF753E003F41	2003-06-10 06:23:08+02	\N
497	0101000020430D00004EEBD63D805F2B414227DF753E003F41	2003-06-10 06:23:09+02	\N
498	0101000020430D0000B48928BC6C5D2B4134A2EB8013FF3E41	2003-06-10 06:53:06+02	\N
499	0101000020430D0000B78928BC6C5D2B4125A2EB8013FF3E41	2003-06-10 06:53:06+02	\N
500	0101000020430D000019107A3A595B2B41950FF88BE8FD3E41	2003-06-10 07:23:03+02	\N
501	0101000020430D00001A107A3A595B2B419C0FF88BE8FD3E41	2003-06-10 07:23:04+02	\N
502	0101000020430D00007FA2CBB845592B41CC830497BDFC3E41	2003-06-10 07:53:01+02	\N
503	0101000020430D000078A2CBB845592B41C8830497BDFC3E41	2003-06-10 07:53:01+02	\N
504	0101000020430D0000F25F43DC18572B411CB3DEC6DCFD3E41	2003-06-10 13:00:26+02	\N
505	0101000020430D0000F35F43DC18572B4129B3DEC6DCFD3E41	2003-06-10 13:00:26+02	\N
506	0101000020430D00007D17CF1E57592B416DDE2B44F3FE3E41	2003-06-10 18:04:48+02	\N
507	0101000020430D00008017CF1E57592B4180DE2B44F3FE3E41	2003-06-10 18:04:48+02	\N
508	0101000020430D00006450697A6D5C2B415143BE2E31FF3E41	2003-06-10 20:03:12+02	\N
509	0101000020430D00006250697A6D5C2B414743BE2E31FF3E41	2003-06-10 20:03:13+02	\N
510	0101000020430D000075C903D6835F2B411FAD50196FFF3E41	2003-06-10 22:01:37+02	\N
511	0101000020430D000074C903D6835F2B4117AD50196FFF3E41	2003-06-10 22:01:37+02	\N
512	0101000020430D0000DA220E463F5F2B417C5C1292E0FD3E41	2003-06-11 01:51:17+02	\N
513	0101000020430D0000D8220E463F5F2B41795C1292E0FD3E41	2003-06-11 01:51:16+02	\N
514	0101000020430D0000EEEBC7AB1D5D2B41F76FEC07BCFC3E41	2003-06-11 03:01:58+02	\N
515	0101000020430D0000F0EBC7AB1D5D2B410070EC07BCFC3E41	2003-06-11 03:01:59+02	\N
516	0101000020430D00009C71FC8F7D5A2B415BE09814E3FB3E41	2003-06-11 04:23:52+02	\N
517	0101000020430D00009A71FC8F7D5A2B4161E09814E3FB3E41	2003-06-11 04:23:52+02	\N
518	0101000020430D00007122ECF66D572B41FED9C8A933FC3E41	2003-06-11 05:47:14+02	\N
519	0101000020430D00007522ECF66D572B41F9D9C8A933FC3E41	2003-06-11 05:47:14+02	\N
520	0101000020430D00001925DC5D5E542B412ECBF83E84FC3E41	2003-06-11 07:10:36+02	\N
521	0101000020430D00001625DC5D5E542B412DCBF83E84FC3E41	2003-06-11 07:10:35+02	\N
522	0101000020430D000025D176931C532B416438C275F2FD3E41	2003-06-11 08:36:09+02	\N
523	0101000020430D000029D176931C532B417438C275F2FD3E41	2003-06-11 08:36:10+02	\N
524	0101000020430D00000A633955CB532B418853B3CC78FF3E41	2003-06-11 09:20:30+02	\N
525	0101000020430D000009633955CB532B417F53B3CC78FF3E41	2003-06-11 09:20:30+02	\N
526	0101000020430D0000EDA2FB167A542B4173B7A323FF003F41	2003-06-11 10:04:50+02	\N
527	0101000020430D0000F0A2FB167A542B4155B7A323FF003F41	2003-06-11 10:04:50+02	\N
528	0101000020430D0000D4E2BDD828552B41491B947A85023F41	2003-06-11 10:49:10+02	\N
529	0101000020430D0000CFE2BDD828552B41551B947A85023F41	2003-06-11 10:49:10+02	\N
530	0101000020430D0000073E809AD7552B4151BC84D10B043F41	2003-06-11 11:33:30+02	\N
531	0101000020430D0000063E809AD7552B4168BC84D10B043F41	2003-06-11 11:33:30+02	\N
532	0101000020430D00008BA2FAE4F2552B41861C200D7C023F41	2003-06-11 13:57:06+02	\N
533	0101000020430D00008DA2FAE4F2552B41801C200D7C023F41	2003-06-11 13:57:07+02	\N
534	0101000020430D0000D24EBA41C2552B41109489CAEC003F41	2003-06-11 15:11:00+02	\N
535	0101000020430D0000D74EBA41C2552B41139489CAEC003F41	2003-06-11 15:11:00+02	\N
536	0101000020430D00002D992604F9562B41A06C00347CFF3E41	2003-06-11 17:37:18+02	\N
537	0101000020430D00002D992604F9562B418C6C00347CFF3E41	2003-06-11 17:37:18+02	\N
538	0101000020430D00003D5BC3DD74592B416ACC0C7689FE3E41	2003-06-11 21:31:06+02	\N
539	0101000020430D00003D5BC3DD74592B416CCC0C7689FE3E41	2003-06-11 21:31:06+02	\N
540	0101000020430D0000F3A90E224E5B2B419985B0F646FD3E41	2003-06-12 02:55:38+02	\N
541	0101000020430D0000F0A90E224E5B2B419985B0F646FD3E41	2003-06-12 02:55:38+02	\N
542	0101000020430D0000D4EE66D0B0582B4187FB3F0F22FE3E41	2003-06-12 07:34:59+02	\N
543	0101000020430D0000D5EE66D0B0582B4199FB3F0F22FE3E41	2003-06-12 07:34:58+02	\N
544	0101000020430D00001FA8729711572B41847A62F677FF3E41	2003-06-12 09:07:31+02	\N
545	0101000020430D00001CA8729711572B41747A62F677FF3E41	2003-06-12 09:07:31+02	\N
546	0101000020430D00002E9ACAEE9B552B4188975BA6D9003F41	2003-06-12 10:24:50+02	\N
547	0101000020430D0000319ACAEE9B552B4180975BA6D9003F41	2003-06-12 10:24:50+02	\N
548	0101000020430D0000917B224626542B4160C454563B023F41	2003-06-12 11:42:09+02	\N
549	0101000020430D0000917B224626542B417DC454563B023F41	2003-06-12 11:42:09+02	\N
550	0101000020430D00004E761E6D76532B41A0BAE48DC1033F41	2003-06-13 08:57:38+02	\N
551	0101000020430D000049761E6D76532B417FBAE48DC1033F41	2003-06-13 08:57:38+02	\N
552	0101000020430D000048F5F6A89C532B413F83E11851053F41	2003-06-13 09:54:59+02	\N
553	0101000020430D000048F5F6A89C532B413D83E11851053F41	2003-06-13 09:54:59+02	\N
554	0101000020430D00004874CFE4C2532B41FD4BDEA3E0063F41	2003-06-13 10:52:20+02	\N
555	0101000020430D00004774CFE4C2532B41FB4BDEA3E0063F41	2003-06-13 10:52:20+02	\N
556	0101000020430D000046F3A720E9532B41AB14DB2E70083F41	2003-06-13 11:49:41+02	\N
557	0101000020430D000046F3A720E9532B41B914DB2E70083F41	2003-06-13 11:49:41+02	\N
558	0101000020430D000040F3655144522B41D007FFFD1B073F41	2003-06-13 13:29:34+02	\N
559	0101000020430D000046F3655144522B41DD07FFFD1B073F41	2003-06-13 13:29:34+02	\N
560	0101000020430D0000B71B5CC8D3502B410F1CA1F6B8053F41	2003-06-13 14:46:45+02	\N
561	0101000020430D0000B51B5CC8D3502B411A1CA1F6B8053F41	2003-06-13 14:46:44+02	\N
562	0101000020430D000027BD4F2EAF522B418011274077043F41	2003-06-13 16:32:58+02	\N
563	0101000020430D000024BD4F2EAF522B416711274077043F41	2003-06-13 16:32:58+02	\N
564	0101000020430D0000C0628CA2CE552B41BAA5950686043F41	2003-06-13 17:04:55+02	\N
565	0101000020430D0000C7628CA2CE552B41C4A5950686043F41	2003-06-13 17:04:55+02	\N
566	0101000020430D00009C12C916EE582B41473A04CD94043F41	2003-06-13 17:36:52+02	\N
567	0101000020430D00009412C916EE582B414C3A04CD94043F41	2003-06-13 17:36:52+02	\N
568	0101000020430D000065F0058B0D5C2B41A9CF7293A3043F41	2003-06-13 18:08:49+02	\N
569	0101000020430D00006BF0058B0D5C2B41ABCF7293A3043F41	2003-06-13 18:08:48+02	\N
570	0101000020430D00005BA542FF2C5F2B414664E159B2043F41	2003-06-13 18:40:45+02	\N
571	0101000020430D00005BA542FF2C5F2B413464E159B2043F41	2003-06-13 18:40:45+02	\N
572	0101000020430D000030557F734C622B41B7F84F20C1043F41	2003-06-13 19:12:42+02	\N
573	0101000020430D000031557F734C622B41BCF84F20C1043F41	2003-06-13 19:12:42+02	\N
574	0101000020430D0000921EBCE76B652B41B88DBEE6CF043F41	2003-06-13 19:44:39+02	\N
575	0101000020430D0000901EBCE76B652B41C58DBEE6CF043F41	2003-06-13 19:44:39+02	\N
576	0101000020430D0000878130016C622B41930225BB5F043F41	2003-06-13 20:51:57+02	\N
577	0101000020430D0000868130016C622B41990225BB5F043F41	2003-06-13 20:51:57+02	\N
578	0101000020430D0000A8425C9F5C5F2B4103D821A00E043F41	2003-06-13 21:27:17+02	\N
579	0101000020430D0000AA425C9F5C5F2B41ECD721A00E043F41	2003-06-13 21:27:16+02	\N
580	0101000020430D00000617883D4D5C2B4154AF1E85BD033F41	2003-06-13 22:02:36+02	\N
581	0101000020430D00000817883D4D5C2B416EAF1E85BD033F41	2003-06-13 22:02:36+02	\N
582	0101000020430D00000B0DB4DB3D592B41528A1B6A6C033F41	2003-06-13 22:37:56+02	\N
583	0101000020430D0000050DB4DB3D592B414A8A1B6A6C033F41	2003-06-13 22:37:55+02	\N
584	0101000020430D00006BF9DF792E562B412E64184F1B033F41	2003-06-13 23:13:15+02	\N
585	0101000020430D000069F9DF792E562B412564184F1B033F41	2003-06-13 23:13:15+02	\N
586	0101000020430D00000AF90B181F532B4108401534CA023F41	2003-06-13 23:48:35+02	\N
587	0101000020430D000010F90B181F532B4103401534CA023F41	2003-06-13 23:48:35+02	\N
588	\N	\N	\N
589	0101000020430D00000000000014532B4100000000BC023F41	2003-06-01 00:00:00+02	\N
590	0101000020430D000033D61B43FB532B41F81CE6133D013F41	2003-06-01 05:58:50+02	\N
591	0101000020430D000031D61B43FB532B41001DE6133D013F41	2003-06-01 05:58:50+02	\N
592	0101000020430D00002BCF83B7F0522B4110390939B6023F41	2003-06-01 11:59:17+02	\N
593	0101000020430D00002DCF83B7F0522B410F390939B6023F41	2003-06-01 11:59:16+02	\N
594	0101000020430D0000F7B362C467502B4149AE2F23A0033F41	2003-06-01 14:30:09+02	\N
595	0101000020430D0000F7B362C467502B4143AE2F23A0033F41	2003-06-01 14:30:10+02	\N
596	0101000020430D000000000000E44E2B417BA5F501FE043F41	2003-06-01 19:54:27+02	\N
597	0101000020430D000000000000E44E2B4189A5F501FE043F41	2003-06-01 19:54:27+02	\N
598	0101000020430D00007ED92B98D4512B419D36E0A785053F41	2003-06-02 11:00:51+02	\N
599	0101000020430D000080D92B98D4512B418C36E0A785053F41	2003-06-02 11:00:51+02	\N
600	0101000020430D00003ECE191FE0522B41AE3B7CA0FE063F41	2003-06-02 15:39:30+02	\N
601	0101000020430D00003BCE191FE0522B41BB3B7CA0FE063F41	2003-06-02 15:39:30+02	\N
602	0101000020430D00006EDF58D70C502B41CF98128EA9073F41	2003-06-02 19:18:40+02	\N
603	0101000020430D000073DF58D70C502B41B498128EA9073F41	2003-06-02 19:18:40+02	\N
604	0101000020430D00000AD03235E6512B41F33A0E04EC083F41	2003-06-03 11:53:24+02	\N
605	0101000020430D000003D03235E6512B41013B0E04EC083F41	2003-06-03 11:53:24+02	\N
606	0101000020430D00006BB9F50B84542B418FCED3B6C6093F41	2003-06-04 05:50:50+02	\N
607	0101000020430D00006FB9F50B84542B419FCED3B6C6093F41	2003-06-04 05:50:50+02	\N
608	0101000020430D0000B1AA738706572B410954DE0CB50A3F41	2003-06-04 09:29:07+02	\N
609	0101000020430D0000AEAA738706572B410954DE0CB50A3F41	2003-06-04 09:29:07+02	\N
610	0101000020430D00008EEBDBFB91592B41223AB7379D0B3F41	2003-06-04 11:13:04+02	\N
611	0101000020430D000092EBDBFB91592B41133AB7379D0B3F41	2003-06-04 11:13:04+02	\N
612	0101000020430D0000B350F79E385B2B414DE575D7F00C3F41	2003-06-04 12:24:46+02	\N
613	0101000020430D0000AF50F79E385B2B415FE575D7F00C3F41	2003-06-04 12:24:46+02	\N
614	0101000020430D0000C53617EB0B5C2B41D3D22BA3720E3F41	2003-06-04 13:05:28+02	\N
615	0101000020430D0000CB3617EB0B5C2B41C2D22BA3720E3F41	2003-06-04 13:05:28+02	\N
616	0101000020430D0000BA043737DF5C2B411C94E16EF40F3F41	2003-06-04 13:46:10+02	\N
617	0101000020430D0000B5043737DF5C2B412F94E16EF40F3F41	2003-06-04 13:46:10+02	\N
618	0101000020430D0000CBEA5683B25D2B41A181973A76113F41	2003-06-04 14:26:52+02	\N
619	0101000020430D0000C8EA5683B25D2B419181973A76113F41	2003-06-04 14:26:52+02	\N
620	0101000020430D0000DED076CF855E2B41056F4D06F8123F41	2003-06-04 15:07:34+02	\N
621	0101000020430D0000E4D076CF855E2B41F46E4D06F8123F41	2003-06-04 15:07:34+02	\N
622	0101000020430D0000FAB6961B595F2B41665C03D279143F41	2003-06-04 15:48:16+02	\N
623	0101000020430D0000F7B6961B595F2B41815C03D279143F41	2003-06-04 15:48:16+02	\N
624	0101000020430D00002792C38C74622B41437DC62E4F143F41	2003-06-05 00:37:57+02	\N
625	0101000020430D00002A92C38C74622B41277DC62E4F143F41	2003-06-05 00:37:57+02	\N
626	0101000020430D0000B58E3B1D6A652B41FEE500A3CE133F41	2003-06-05 05:46:28+02	\N
627	0101000020430D0000B38E3B1D6A652B4104E600A3CE133F41	2003-06-05 05:46:28+02	\N
628	0101000020430D00004DB9D034FD622B412350F268D2123F41	2003-06-05 11:02:10+02	\N
629	0101000020430D000049B9D034FD622B413F50F268D2123F41	2003-06-05 11:02:10+02	\N
630	0101000020430D0000BAE0D5C6D0602B41195B59CEF1133F41	2003-06-05 21:00:28+02	\N
631	0101000020430D0000BFE0D5C6D0602B41105B59CEF1133F41	2003-06-05 21:00:28+02	\N
632	0101000020430D00001B513EED5C602B419F38BC0566123F41	2003-06-07 16:54:11+02	\N
633	0101000020430D000016513EED5C602B418038BC0566123F41	2003-06-07 16:54:11+02	\N
634	0101000020430D000001519345E95E2B4188DEBCCE03113F41	2003-06-07 18:06:21+02	\N
635	0101000020430D000009519345E95E2B4198DEBCCE03113F41	2003-06-07 18:06:21+02	\N
636	0101000020430D0000F450E89D755D2B41A084BD97A10F3F41	2003-06-07 19:18:31+02	\N
637	0101000020430D0000F350E89D755D2B41B084BD97A10F3F41	2003-06-07 19:18:31+02	\N
638	0101000020430D0000079A3E5B205B2B41BEDDF278970E3F41	2003-06-07 22:07:10+02	\N
639	0101000020430D0000009A3E5B205B2B41AEDDF278970E3F41	2003-06-07 22:07:10+02	\N
640	0101000020430D00008BBA4A1ED4582B410E6BED5F880D3F41	2003-06-08 04:41:18+02	\N
641	0101000020430D00008EBA4A1ED4582B41286BED5F880D3F41	2003-06-08 04:41:18+02	\N
642	0101000020430D0000D7499AF704572B419D04F239420C3F41	2003-06-08 05:42:39+02	\N
643	0101000020430D0000D4499AF704572B419504F239420C3F41	2003-06-08 05:42:39+02	\N
644	0101000020430D000039C9E9D035552B41D992F613FC0A3F41	2003-06-08 06:44:00+02	\N
645	0101000020430D00003AC9E9D035552B41C492F613FC0A3F41	2003-06-08 06:43:59+02	\N
646	0101000020430D0000905039AA66532B41A026FBEDB5093F41	2003-06-08 07:45:20+02	\N
647	0101000020430D0000955039AA66532B41A726FBEDB5093F41	2003-06-08 07:45:20+02	\N
648	0101000020430D00002D0BE9DD03522B419C795D6B4F083F41	2003-06-08 09:43:31+02	\N
649	0101000020430D00002D0BE9DD03522B41AE795D6B4F083F41	2003-06-08 09:43:31+02	\N
650	0101000020430D0000445994B8C4502B411AFA92A0E0063F41	2003-06-08 11:58:51+02	\N
651	0101000020430D00003E5994B8C4502B4118FA92A0E0063F41	2003-06-08 11:58:50+02	\N
652	0101000020430D0000EE9C3F93854F2B418E6EC8D571053F41	2003-06-08 14:14:10+02	\N
653	0101000020430D0000F09C3F93854F2B416E6EC8D571053F41	2003-06-08 14:14:10+02	\N
654	0101000020430D00003B20DB7A9F4D2B414403C72434043F41	2003-06-08 22:59:19+02	\N
655	0101000020430D00003B20DB7A9F4D2B415F03C72434043F41	2003-06-08 22:59:19+02	\N
656	0101000020430D00001B8A5A5962502B41E2941ED678033F41	2003-06-11 06:51:15+02	\N
657	0101000020430D0000208A5A5962502B41EC941ED678033F41	2003-06-11 06:51:15+02	\N
658	0101000020430D0000C54FFAB6DE522B41B166B66E86023F41	2003-06-11 10:23:58+02	\N
659	0101000020430D0000C54FFAB6DE522B41AF66B66E86023F41	2003-06-11 10:23:58+02	\N
660	0101000020430D00005A4CF3D0E34F2B41C99B6CD5FE023F41	2003-06-12 22:14:11+02	\N
661	0101000020430D0000574CF3D0E34F2B41B59B6CD5FE023F41	2003-06-12 22:14:11+02	\N
662	0101000020430D0000DD86C5A8F5522B41466F78EAB3023F41	2003-06-13 13:00:04+02	\N
663	0101000020430D0000DD86C5A8F5522B41526F78EAB3023F41	2003-06-13 13:00:03+02	\N
664	0101000020430D0000CE2229ACB3542B415AD583D967013F41	2003-06-13 16:26:17+02	\N
665	0101000020430D0000CA2229ACB3542B4162D583D967013F41	2003-06-13 16:26:17+02	\N
666	0101000020430D000087C5D98F8F542B41122FED41D8FF3E41	2003-06-13 18:20:19+02	\N
667	0101000020430D00008CC5D98F8F542B41ED2EED41D8FF3E41	2003-06-13 18:20:19+02	\N
668	0101000020430D0000C75A7CA856552B41F08DC1D754FE3E41	2003-06-13 23:25:47+02	\N
669	0101000020430D0000C45A7CA856552B41FF8DC1D754FE3E41	2003-06-13 23:25:47+02	\N
670	\N	\N	\N
671	0101000020430D000000000000C0402B410000000038FF3E41	2003-06-01 00:00:00+02	\N
672	0101000020430D0000F27B52527A3E2B411A360B9D4A003F41	2003-06-01 08:28:51+02	\N
673	0101000020430D0000F07B52527A3E2B4114360B9D4A003F41	2003-06-01 08:28:51+02	\N
674	0101000020430D000090C20FFC2D3D2B41460E1277B6013F41	2003-06-01 10:23:27+02	\N
675	0101000020430D000096C20FFC2D3D2B414A0E1277B6013F41	2003-06-01 10:23:27+02	\N
676	0101000020430D000017B9871B3C3B2B414EF6495E7D003F41	2003-06-01 14:16:11+02	\N
677	0101000020430D000014B9871B3C3B2B4143F6495E7D003F41	2003-06-01 14:16:10+02	\N
678	0101000020430D00006953BF92B13A2B4123155069F3FE3E41	2003-06-01 15:42:45+02	\N
679	0101000020430D00006853BF92B13A2B4141155069F3FE3E41	2003-06-01 15:42:46+02	\N
680	0101000020430D000071186BBFC3382B410941B31B2E003F41	2003-06-02 07:10:52+02	\N
681	0101000020430D000074186BBFC3382B410B41B31B2E003F41	2003-06-02 07:10:52+02	\N
682	0101000020430D00004F9CC9921B3A2B41B8D5004897013F41	2003-06-02 17:24:51+02	\N
683	0101000020430D0000499CC9921B3A2B4193D5004897013F41	2003-06-02 17:24:50+02	\N
684	0101000020430D0000DC0C703BFE3B2B41DFBEA647D6023F41	2003-06-02 19:37:59+02	\N
685	0101000020430D0000E10C703BFE3B2B41F1BEA647D6023F41	2003-06-02 19:37:59+02	\N
686	0101000020430D0000BD92F4C006392B4104DFDC9658023F41	2003-06-03 04:20:36+02	\N
687	0101000020430D0000BA92F4C006392B4114DFDC9658023F41	2003-06-03 04:20:36+02	\N
688	0101000020430D00005921BCC1ED352B4177BC5AC723023F41	2003-06-03 07:41:47+02	\N
689	0101000020430D00005921BCC1ED352B4164BC5AC723023F41	2003-06-03 07:41:47+02	\N
690	0101000020430D00003E50A013DA322B41FC2D14B569023F41	2003-06-03 10:06:42+02	\N
691	0101000020430D00004250A013DA322B410A2E14B569023F41	2003-06-03 10:06:42+02	\N
692	0101000020430D0000525A35F3CA2F2B4187DB6A6DBB023F41	2003-06-03 12:25:18+02	\N
693	0101000020430D00004C5A35F3CA2F2B416BDB6A6DBB023F41	2003-06-03 12:25:19+02	\N
694	0101000020430D0000607CCAD2BB2C2B416686C1250D033F41	2003-06-03 14:43:55+02	\N
695	0101000020430D0000667CCAD2BB2C2B417386C1250D033F41	2003-06-03 14:43:55+02	\N
696	0101000020430D00009AA27C396D2E2B41C043EC5C5D043F41	2003-06-03 19:57:02+02	\N
697	0101000020430D000093A27C396D2E2B41B643EC5C5D043F41	2003-06-03 19:57:02+02	\N
698	0101000020430D0000652373ED152E2B41368869C0CF023F41	2003-06-04 01:39:28+02	\N
699	0101000020430D00006C2373ED152E2B412F8869C0CF023F41	2003-06-04 01:39:28+02	\N
700	0101000020430D0000FFCBD8E1B42D2B414311A2B442013F41	2003-06-04 07:15:24+02	\N
701	0101000020430D0000F8CBD8E1B42D2B416211A2B442013F41	2003-06-04 07:15:24+02	\N
702	0101000020430D0000E44CF866642F2B416AA6BFE2F1FF3E41	2003-06-04 16:29:42+02	\N
703	0101000020430D0000E94CF866642F2B4174A6BFE2F1FF3E41	2003-06-04 16:29:42+02	\N
704	0101000020430D00003676EA0F74322B41B9723674A1FF3E41	2003-06-04 16:52:39+02	\N
705	0101000020430D00003476EA0F74322B41AE723674A1FF3E41	2003-06-04 16:52:39+02	\N
706	0101000020430D000091B7DCB883352B417C3CAD0551FF3E41	2003-06-04 17:15:36+02	\N
707	0101000020430D000095B7DCB883352B41643CAD0551FF3E41	2003-06-04 17:15:37+02	\N
708	0101000020430D0000C1FDCE6193382B41B305249700FF3E41	2003-06-04 17:38:34+02	\N
709	0101000020430D0000BBFDCE6193382B41C405249700FF3E41	2003-06-04 17:38:34+02	\N
710	0101000020430D0000173FC10AA33B2B4192CF9A28B0FE3E41	2003-06-04 18:01:31+02	\N
711	0101000020430D00001C3FC10AA33B2B41A5CF9A28B0FE3E41	2003-06-04 18:01:31+02	\N
712	0101000020430D00007980B3B3B23E2B41729911BA5FFE3E41	2003-06-04 18:24:28+02	\N
713	0101000020430D00007680B3B3B23E2B415B9911BA5FFE3E41	2003-06-04 18:24:28+02	\N
714	0101000020430D0000B4DEA55CC2412B413260884B0FFE3E41	2003-06-04 18:47:25+02	\N
715	0101000020430D0000B3DEA55CC2412B413660884B0FFE3E41	2003-06-04 18:47:25+02	\N
716	0101000020430D0000F1EF9705D2442B41F42EFFDCBEFD3E41	2003-06-04 19:10:22+02	\N
717	0101000020430D0000F6EF9705D2442B41F52EFFDCBEFD3E41	2003-06-04 19:10:23+02	\N
718	0101000020430D000064498AAEE1472B414AF6756E6EFD3E41	2003-06-04 19:33:20+02	\N
719	0101000020430D00005E498AAEE1472B4151F6756E6EFD3E41	2003-06-04 19:33:20+02	\N
720	0101000020430D00000BB67C57F14A2B41ADBBECFF1DFD3E41	2003-06-04 19:56:17+02	\N
721	0101000020430D000012B67C57F14A2B41ABBBECFF1DFD3E41	2003-06-04 19:56:17+02	\N
722	0101000020430D00008F842DB5DE472B418CE70CD066FD3E41	2003-06-04 20:27:14+02	\N
723	0101000020430D00008C842DB5DE472B416FE70CD066FD3E41	2003-06-04 20:27:14+02	\N
724	0101000020430D00008C564378CC442B4130ACF9AFB0FD3E41	2003-06-04 20:50:41+02	\N
725	0101000020430D00008E564378CC442B4154ACF9AFB0FD3E41	2003-06-04 20:50:41+02	\N
726	0101000020430D0000E162593BBA412B41996BE68FFAFD3E41	2003-06-04 21:14:08+02	\N
727	0101000020430D0000E262593BBA412B41846BE68FFAFD3E41	2003-06-04 21:14:08+02	\N
728	0101000020430D000054486FFEA73E2B41712ED36F44FE3E41	2003-06-04 21:37:35+02	\N
729	0101000020430D000051486FFEA73E2B41662ED36F44FE3E41	2003-06-04 21:37:35+02	\N
730	0101000020430D0000751585C1953B2B419BF3BF4F8EFE3E41	2003-06-04 22:01:02+02	\N
731	0101000020430D0000751585C1953B2B41A0F3BF4F8EFE3E41	2003-06-04 22:01:03+02	\N
732	0101000020430D000054EC9A8483382B41ECB7AC2FD8FE3E41	2003-06-04 22:24:30+02	\N
733	0101000020430D000055EC9A8483382B4104B8AC2FD8FE3E41	2003-06-04 22:24:30+02	\N
734	0101000020430D000032C3B04771352B414F7C990F22FF3E41	2003-06-04 22:47:57+02	\N
735	0101000020430D00002CC3B04771352B413D7C990F22FF3E41	2003-06-04 22:47:57+02	\N
736	0101000020430D00000A9AC60A5F322B41884086EF6BFF3E41	2003-06-04 23:11:24+02	\N
737	0101000020430D00000B9AC60A5F322B41A14086EF6BFF3E41	2003-06-04 23:11:24+02	\N
738	0101000020430D00000C6CDCCD4C2F2B41620573CFB5FF3E41	2003-06-04 23:34:51+02	\N
739	0101000020430D00000D6CDCCD4C2F2B415B0573CFB5FF3E41	2003-06-04 23:34:51+02	\N
740	0101000020430D0000AD90F2903A2C2B4158C25FAFFFFF3E41	2003-06-04 23:58:18+02	\N
741	0101000020430D0000AC90F2903A2C2B415DC25FAFFFFF3E41	2003-06-04 23:58:18+02	\N
742	0101000020430D000007E159CD822B2B41BB233AFD84013F41	2003-06-06 00:10:24+02	\N
743	0101000020430D00000CE159CD822B2B41BD233AFD84013F41	2003-06-06 00:10:24+02	\N
744	0101000020430D0000C2534C137B2D2B411B1D2F84BB023F41	2003-06-07 07:42:45+02	\N
745	0101000020430D0000C1534C137B2D2B41F91C2F84BB023F41	2003-06-07 07:42:45+02	\N
746	0101000020430D0000CDA3E7CAD52B2B41109F8D8F0F043F41	2003-06-07 09:11:09+02	\N
747	0101000020430D0000CFA3E7CAD52B2B410F9F8D8F0F043F41	2003-06-07 09:11:08+02	\N
748	0101000020430D000056DBF3A4152A2B41EE9B5DE85A053F41	2003-06-07 10:24:54+02	\N
749	0101000020430D000051DBF3A4152A2B41129C5DE85A053F41	2003-06-07 10:24:54+02	\N
750	0101000020430D00003C21007F55282B414D8E2D41A6063F41	2003-06-07 11:38:40+02	\N
751	0101000020430D00004121007F55282B412E8E2D41A6063F41	2003-06-07 11:38:41+02	\N
752	0101000020430D00007139A7780A292B41F3B99BE22B083F41	2003-06-07 13:02:12+02	\N
753	0101000020430D00006A39A7780A292B4105BA9BE22B083F41	2003-06-07 13:02:11+02	\N
754	0101000020430D00000A45431F802A2B4101321F938D093F41	2003-06-07 14:17:02+02	\N
755	0101000020430D00000A45431F802A2B41F4311F938D093F41	2003-06-07 14:17:03+02	\N
756	0101000020430D0000F73FDFC5F52B2B41229AA243EF0A3F41	2003-06-07 15:31:54+02	\N
757	0101000020430D0000FD3FDFC5F52B2B411E9AA243EF0A3F41	2003-06-07 15:31:54+02	\N
758	0101000020430D00001974CB892B2B2B4174B88E416C093F41	2003-06-08 06:08:56+02	\N
759	0101000020430D00001874CB892B2B2B416AB88E416C093F41	2003-06-08 06:08:56+02	\N
760	0101000020430D00005B4B0636D52B2B41329B2A5BE5073F41	2003-06-08 07:53:21+02	\N
761	0101000020430D00005A4B0636D52B2B41349B2A5BE5073F41	2003-06-08 07:53:21+02	\N
762	0101000020430D0000990941E27E2C2B419CB7C6745E063F41	2003-06-08 09:37:46+02	\N
763	0101000020430D00009C0941E27E2C2B41B5B7C6745E063F41	2003-06-08 09:37:46+02	\N
764	0101000020430D0000E1F97B8E282D2B41DF60628ED7043F41	2003-06-08 11:22:11+02	\N
765	0101000020430D0000DDF97B8E282D2B41C860628ED7043F41	2003-06-08 11:22:11+02	\N
766	0101000020430D000045FB6282C02C2B41208126F44A033F41	2003-06-08 18:13:49+02	\N
767	0101000020430D000044FB6282C02C2B411E8126F44A033F41	2003-06-08 18:13:49+02	\N
768	0101000020430D0000C75019445A2C2B4130F7E33BBE013F41	2003-06-09 19:31:17+02	\N
769	0101000020430D0000C55019445A2C2B4136F7E33BBE013F41	2003-06-09 19:31:16+02	\N
770	0101000020430D0000F00FA75F3C2E2B41B086DC70FD023F41	2003-06-10 17:16:05+02	\N
771	0101000020430D0000F10FA75F3C2E2B41A986DC70FD023F41	2003-06-10 17:16:05+02	\N
772	0101000020430D0000485677B9502F2B41691942D174043F41	2003-06-10 18:25:10+02	\N
773	0101000020430D00004E5677B9502F2B41801942D174043F41	2003-06-10 18:25:10+02	\N
774	0101000020430D0000A69C471365302B4140ACA731EC053F41	2003-06-10 19:34:15+02	\N
775	0101000020430D0000A29C471365302B412CACA731EC053F41	2003-06-10 19:34:16+02	\N
776	0101000020430D0000800B186D79312B41F6750D9263073F41	2003-06-10 20:43:21+02	\N
777	0101000020430D00007E0B186D79312B410A760D9263073F41	2003-06-10 20:43:21+02	\N
778	0101000020430D0000D451E8C68D322B41C80873F2DA083F41	2003-06-10 21:52:26+02	\N
779	0101000020430D0000DB51E8C68D322B41B60873F2DA083F41	2003-06-10 21:52:26+02	\N
780	0101000020430D00003298B820A2332B41749BD852520A3F41	2003-06-10 23:01:31+02	\N
781	0101000020430D00002F98B820A2332B418D9BD852520A3F41	2003-06-10 23:01:31+02	\N
782	0101000020430D0000DA6C0C6DEC312B41A6ABFC8003093F41	2003-06-11 15:34:44+02	\N
783	0101000020430D0000DC6C0C6DEC312B418DABFC8003093F41	2003-06-11 15:34:45+02	\N
784	0101000020430D00002F8F6D642E302B414669C371B7073F41	2003-06-11 18:52:01+02	\N
785	0101000020430D00002D8F6D642E302B414C69C371B7073F41	2003-06-11 18:52:00+02	\N
786	0101000020430D000081B1CE5B702E2B4105278A626B063F41	2003-06-11 22:09:16+02	\N
787	0101000020430D00007EB1CE5B702E2B410B278A626B063F41	2003-06-11 22:09:16+02	\N
788	0101000020430D000036B17201572B2B41D485AFED37063F41	2003-06-13 08:21:30+02	\N
789	0101000020430D00003CB17201572B2B41EA85AFED37063F41	2003-06-13 08:21:30+02	\N
790	0101000020430D0000AD932C5F74282B41BE520E4A9E053F41	2003-06-13 10:01:26+02	\N
791	0101000020430D0000A9932C5F74282B41A9520E4A9E053F41	2003-06-13 10:01:26+02	\N
792	0101000020430D00005092E6BC91252B415B256DA604053F41	2003-06-13 11:41:22+02	\N
793	0101000020430D00004E92E6BC91252B4147256DA604053F41	2003-06-13 11:41:21+02	\N
794	0101000020430D0000939659D6EB222B4171B32F0CD9053F41	2003-06-13 20:06:08+02	\N
795	0101000020430D0000979659D6EB222B4177B32F0CD9053F41	2003-06-13 20:06:08+02	\N
796	0101000020430D000011B60F5526242B4119F6A44069043F41	2003-06-14 15:54:47+02	\N
797	0101000020430D000012B60F5526242B4119F6A44069043F41	2003-06-14 15:54:48+02	\N
798	\N	\N	\N
\.


--
-- TOC entry 3709 (class 0 OID 0)
-- Dependencies: 230
-- Name: relocation_id_seq; Type: SEQUENCE SET; Schema: ibex_traj_materialized_bursts; Owner: -
--

SELECT pg_catalog.setval('"relocation_id_seq"', 798, true);


--
-- TOC entry 3667 (class 0 OID 629630)
-- Dependencies: 234
-- Data for Name: s_b_rel; Type: TABLE DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

COPY "s_b_rel" ("step_id", "animal_burst_id") FROM stdin;
164	1
163	1
162	1
161	1
160	1
159	1
158	1
157	1
156	1
155	1
154	1
153	1
152	1
151	1
150	1
149	1
148	1
147	1
146	1
145	1
144	1
143	1
142	1
141	1
140	1
139	1
138	1
137	1
136	1
135	1
134	1
133	1
132	1
131	1
130	1
129	1
128	1
127	1
126	1
125	1
124	1
123	1
122	1
121	1
120	1
119	1
118	1
117	1
116	1
115	1
114	1
113	1
112	1
111	1
110	1
109	1
108	1
107	1
106	1
105	1
104	1
103	1
102	1
101	1
100	1
99	1
98	1
97	1
96	1
95	1
94	1
93	1
92	1
91	1
90	1
89	1
88	1
87	1
86	1
85	1
84	1
83	1
82	1
81	1
80	1
79	1
78	1
77	1
76	1
75	1
74	1
73	1
72	1
71	1
70	1
69	1
68	1
67	1
66	1
65	1
64	1
63	1
62	1
61	1
60	1
59	1
58	1
57	1
56	1
55	1
54	1
53	1
52	1
51	1
50	1
49	1
48	1
47	1
46	1
45	1
44	1
43	1
42	1
41	1
40	1
39	1
38	1
37	1
36	1
35	1
34	1
33	1
32	1
31	1
30	1
29	1
28	1
27	1
26	1
25	1
24	1
23	1
22	1
21	1
20	1
19	1
18	1
17	1
16	1
15	1
14	1
13	1
12	1
11	1
10	1
9	1
8	1
7	1
6	1
5	1
4	1
3	1
2	1
1	1
294	2
293	2
292	2
291	2
290	2
289	2
288	2
287	2
286	2
285	2
284	2
283	2
282	2
281	2
280	2
279	2
278	2
277	2
276	2
275	2
274	2
273	2
272	2
271	2
270	2
269	2
268	2
267	2
266	2
265	2
264	2
263	2
262	2
261	2
260	2
259	2
258	2
257	2
256	2
255	2
254	2
253	2
252	2
251	2
250	2
249	2
248	2
247	2
246	2
245	2
244	2
243	2
242	2
241	2
240	2
239	2
238	2
237	2
236	2
235	2
234	2
233	2
232	2
231	2
230	2
229	2
228	2
227	2
226	2
225	2
224	2
223	2
222	2
221	2
220	2
219	2
218	2
217	2
216	2
215	2
214	2
213	2
212	2
211	2
210	2
209	2
208	2
207	2
206	2
205	2
204	2
203	2
202	2
201	2
200	2
199	2
198	2
197	2
196	2
195	2
194	2
193	2
192	2
191	2
190	2
189	2
188	2
187	2
186	2
185	2
184	2
183	2
182	2
181	2
180	2
179	2
178	2
177	2
176	2
175	2
174	2
173	2
172	2
171	2
170	2
169	2
168	2
167	2
166	2
165	2
335	3
334	3
333	3
332	3
331	3
330	3
329	3
328	3
327	3
326	3
325	3
324	3
323	3
322	3
321	3
320	3
319	3
318	3
317	3
316	3
315	3
314	3
313	3
312	3
311	3
310	3
309	3
308	3
307	3
306	3
305	3
304	3
303	3
302	3
301	3
300	3
299	3
298	3
297	3
296	3
295	3
399	4
398	4
397	4
396	4
395	4
394	4
393	4
392	4
391	4
390	4
389	4
388	4
387	4
386	4
385	4
384	4
383	4
382	4
381	4
380	4
379	4
378	4
377	4
376	4
375	4
374	4
373	4
372	4
371	4
370	4
369	4
368	4
367	4
366	4
365	4
364	4
363	4
362	4
361	4
360	4
359	4
358	4
357	4
356	4
355	4
354	4
353	4
352	4
351	4
350	4
349	4
348	4
347	4
346	4
345	4
344	4
343	4
342	4
341	4
340	4
339	4
338	4
337	4
336	4
\.


--
-- TOC entry 3666 (class 0 OID 629611)
-- Dependencies: 233
-- Data for Name: step; Type: TABLE DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

COPY "step" ("id", "relocation_id_1", "relocation_id_2", "dt", "r_rowname", "r2n", "rel_angle") FROM stdin;
1	1	2	06:59:59	1	0	\N
2	3	4	02:49:31	2	159999.988185583003	-0.0795601735845623964
3	5	6	18:50:23	3	638987.731724943966	-0.48918489822005301
4	7	8	00:49:32	4	1351081.69408343011	0.282421800296594028
5	9	10	00:49:32	5	2438560.9369437499	1.92956761679852005e-13
6	11	12	00:49:32	6	3846040.17705261009	8.52651282912119971e-14
7	13	14	00:49:32	7	5573519.42618182953	-1.08135722598489995e-13
8	15	16	00:44:05	8	7620998.66065454017	-0.625755578209051033
9	17	18	00:43:31	9	9531027.14497172087	-0.0236329555907686985
10	19	20	00:43:31	10	11728643.1764751002	7.29416527178728049e-13
11	21	22	00:43:31	11	14246259.2151116002	-6.48925357893403998e-13
12	23	24	00:43:31	12	17083875.2472118996	6.55031584528841964e-15
13	25	26	01:09:14	13	20241491.2870266996	0.0161850948979965006
14	27	28	01:40:18	14	23741261.3469595015	0.0195689455178668995
15	29	30	02:57:23	15	27586587.0739952996	-0.0340276807227166966
16	31	32	16:07:27	16	31706388.954305999	0.62536142679252904
17	33	34	01:36:27	17	36159001.7864454016	0.760423596583061023
18	35	36	01:19:53	18	38719656.2779133022	0.160171734562145007
19	37	38	00:57:43	19	40900618.854859598	0.189148944967856003
20	39	40	00:57:43	20	42504452.7158192024	-6.34159391665889012e-13
21	41	42	00:57:43	21	44428286.5900837034	3.17079695832945011e-13
22	43	44	01:21:52	22	46672120.4572563022	-0.432757109097231973
23	45	46	01:28:55	23	51072786.0231015012	-0.662506370051597959
24	47	48	01:28:55	24	56949344.2829457	2.77555756156288984e-13
25	49	50	11:44:44	25	63145902.5438631028	-0.339609304712289006
26	51	52	05:51:01	26	69270470.2144964039	1.47952589610937002
27	53	54	05:21:49	27	72193503.5360361934	2.36922513767945997
28	55	56	05:44:34	28	65917811.8987760022	0.66745690759102605
29	57	58	00:28:25	29	62628678.8292710036	-0.256796639649891023
30	59	60	00:28:25	30	58364301.5376304016	1.44328993201270003e-14
31	61	62	00:28:25	31	54419924.2651178017	-1.12798659301916005e-13
32	63	64	00:28:25	32	50795546.9980712011	1.06359365759089997e-13
33	65	66	00:28:25	33	47491169.7180852965	-1.48103751484996009e-13
34	67	68	00:28:25	34	44506792.4132668972	-6.21724893790087978e-15
35	69	70	00:28:25	35	41842415.1099904031	2.92654789291191012e-13
36	71	72	00:59:13	36	39498037.8193506971	-3.10368485082247014
37	73	74	00:23:55	37	41669221.7657418996	-0.0152688929041078
38	75	76	00:23:55	38	44230490.6471221	-1.16351372980716002e-13
39	77	78	00:23:55	39	47111759.5483338982	2.93098878501041011e-14
40	79	80	00:23:55	40	50313028.4341814965	-2.93098878501041011e-14
41	81	82	00:23:55	41	53834297.3400786966	0
42	83	84	00:23:55	42	57675566.2492036	6.57252030578093051e-14
43	85	86	00:23:55	43	61836835.1555813998	0
44	87	88	00:23:55	44	66318104.0643019974	-6.57252030578093051e-14
45	89	90	02:00:20	45	71119372.9822251946	-0.105255500437953994
46	91	92	04:46:28	46	76693513.7799810022	-0.696111722892497009
47	93	94	02:19:58	47	83834770.661490202	-1.27625999093757003
48	95	96	01:19:21	48	85551490.9226115048	-0.183893899385076998
49	97	98	01:19:21	49	86247739.6720163971	-1.84741111297625998e-13
50	99	100	01:15:34	50	87263988.4168792069	1.44668636191296995
51	101	102	00:52:09	51	94892899.2331110984	0.291039521075601992
52	103	104	00:52:09	52	102441491.353621006	1.08801856413265e-13
53	105	106	00:52:09	53	110310079.228856996	0
54	107	108	01:22:25	54	118498667.396345004	-2.47412704306578979
55	109	110	00:33:56	55	113635598.586122006	-0.246052066753930987
56	111	112	00:33:56	56	107501391.297360003	4.44089209850063011e-15
57	113	114	00:33:56	57	101687184.077554002	-3.04201108747293018e-14
58	115	116	00:33:56	58	96192976.8396846056	-1.21458398893991999e-13
59	117	118	00:33:56	59	91018769.5872087032	-2.68896016564213015e-13
60	119	120	01:08:01	60	86164562.3404394984	2.79827617771428017
61	121	122	00:31:56	61	92681732.4225848019	0.122473835470672004
62	123	124	00:31:56	62	98999983.0811097026	-3.68594044175552022e-13
63	125	126	00:31:56	63	105638233.412807003	3.68594044175552022e-13
64	127	128	00:31:56	64	112596484.031360999	-1.27453603226967996e-13
65	129	130	00:31:56	65	119874734.465406001	-1.36557432028894002e-13
66	131	132	07:07:57	66	127472984.961737007	-0.409667121501414988
67	133	134	09:30:39	67	136591493.601301014	-1.14550033609141
68	135	136	00:43:43	68	141629381.754940987	0.248275224053930987
69	137	138	00:43:43	69	148787978.67998001	-1.23123733430930012e-13
70	139	140	00:43:43	70	156266575.603814006	2.69007038866674975e-13
71	141	142	00:43:43	71	164065172.541399986	4.41313652288499977e-13
72	143	144	00:43:43	72	172183769.484173	-5.04651875843365006e-13
73	145	146	00:58:04	73	180622366.443500996	3.00947017634441005
74	147	148	00:33:19	74	173109035.196969002	0.0321472679725088029
75	149	150	00:33:19	75	165677438.856916994	6.92335078156248023e-13
76	151	152	00:33:19	76	158565842.571150988	1.89182003396127003e-13
77	153	154	00:33:19	77	151774246.244612008	-4.77839989798666971e-13
78	155	156	00:33:19	78	145302649.942907006	-9.32587340685131021e-15
79	157	158	01:24:26	79	139151053.63597101	-0.164230215937418988
80	159	160	04:20:31	80	134592090.539436996	-1.29990546738494994
81	161	162	02:28:53	81	141449345.032373011	-0.608598811657645955
82	163	164	01:05:14	82	151040168.458039999	1.9328418240696601
83	165	166	00:47:42	83	146568391.665455014	0.0938936570728512027
84	167	168	00:47:42	84	141622509.969597995	3.73923114693752975e-13
85	169	170	00:47:42	85	136996628.254184008	-5.87085935421782981e-13
86	171	172	03:00:26	86	132690746.556639001	2.77931644929019006
87	173	174	01:08:04	87	133810769.788653001	0.180185390943705004
88	175	176	01:47:09	88	136872579.111001015	0.50831671791104005
89	177	178	01:59:11	89	144123932.19501099	0.502902325069637945
90	179	180	02:39:58	90	153721680.627873003	-1.85160244821796005
91	181	182	01:29:46	91	149467279.736360997	-0.359991514399493007
92	183	184	05:10:58	92	142666401.991665989	2.05311222646108016
93	185	186	02:06:22	93	151993483.961517006	1.23680076122233995
94	187	188	03:57:21	94	157811033.455320001	2.90874095062051996
95	189	190	01:32:31	95	150290581.678761005	0.107112930303997003
96	191	192	01:55:42	96	143825238.102144986	0.333143245239851005
97	193	194	01:55:42	97	140391291.370303988	5.72430991496731015e-13
98	195	196	01:36:18	98	137277344.653052986	2.80024615352738016
99	197	198	01:29:18	99	143198720.038147986	0.0113405709488793999
100	199	200	02:04:11	100	149355859.537286997	1.47426262893331006
101	201	202	00:57:35	101	142697467.305992991	0.607769668186904033
102	203	204	00:57:35	102	133521551.872803003	-9.81437153768638003e-14
103	205	206	00:57:35	103	124665636.454897001	9.81437153768638003e-14
104	207	208	01:53:52	104	116129721.022293001	-2.87556065644315018
105	209	210	01:49:36	105	124907664.273091003	-0.00670494047573733012
106	211	212	02:05:11	106	134006965.725511	2.99519285737977992
107	213	214	01:32:08	107	124981534.101788998	0.0206457045705886015
108	215	216	02:33:14	108	116253632.451912999	1.47024910396682995
109	217	218	01:46:57	109	114561950.955520004	0.431337350626735005
110	219	220	02:07:06	110	116852760.648999006	-1.27030279461265994
111	221	222	01:50:54	111	109816451.124761	-0.192229407759781007
112	223	224	01:50:54	112	102310600.134491995	4.30322444344710978e-13
113	225	226	01:50:54	113	95124742.1102973074	-5.52002887843628034e-13
114	227	228	01:20:13	114	88258871.1570726931	-2.34494449030965013
115	229	230	00:30:45	115	90680415.8052673936	-0.206032861145421992
116	231	232	00:30:45	116	94833648.198121503	-3.29070104498895995e-13
117	233	234	00:30:45	117	99306880.5477028042	3.48610029732299002e-13
118	235	236	00:30:45	118	104100112.908653006	-4.11226608321157983e-13
119	237	238	00:30:45	119	109213345.289105996	2.50466314355435013e-13
120	239	240	00:30:45	120	114646577.625946999	1.60760293965722995e-13
121	241	242	03:25:44	121	120399809.982286006	-2.29239823973715984
122	243	244	01:48:11	122	121524189.782343	-0.865054480842763041
123	245	246	01:20:28	123	115876362.438566998	-0.287876988111248011
124	247	248	01:20:28	124	108890117.313228995	2.53796983429310987e-13
125	249	250	01:36:53	125	102223872.159703001	2.58723566780466996
126	251	252	01:01:26	126	110445293.313139006	0.112833667213750002
127	253	254	01:01:26	127	118859004.579362005	-2.81552559044940002e-13
128	255	256	01:15:03	128	127592715.599855006	0.581205468895991006
129	257	258	00:58:44	129	134307428.114771992	0.704005180234431038
130	259	260	00:58:44	130	135681314.521972001	-6.46149800331841006e-13
131	261	262	00:58:44	131	137375200.932752013	3.34399175017096999e-13
132	263	264	01:13:17	132	139389087.329005003	-1.83139443833145998
133	265	266	00:34:50	133	147870102.547105014	-0.413518005228485974
134	267	268	00:34:50	134	154147098.798191994	-8.64364135821916028e-13
135	269	270	00:34:50	135	160744095.040223986	5.19806420129497989e-13
136	271	272	00:34:50	136	167661091.29341799	-4.03010957938932014e-14
137	273	274	00:34:50	137	174898087.54164201	2.41973108217053019e-13
138	275	276	01:33:38	138	182455083.816944987	-2.40867312052121019
139	277	278	00:45:44	139	171818761.751569986	-0.286365098941359975
140	279	280	00:45:44	140	162058720.752517015	0
141	281	282	00:45:44	141	152618679.755001992	-2.67341704329737998e-13
142	283	284	05:35:53	142	143498638.769039005	-0.316474957855818972
143	285	286	13:22:20	143	136201564.182413995	-2.2710767104721401
144	287	288	03:38:25	144	145563600.207071006	2.01672852255848012
145	289	290	01:22:04	145	140192654.49059999	0.340272941375218019
146	291	292	01:18:11	146	132800541.176777005	1.60251774958156989
147	293	294	00:41:12	147	127475372.668494999	0.38026836771120498
148	295	296	00:41:12	148	125589474.165616006	-2.68285393900668977e-13
149	297	298	00:41:12	149	124023575.682242006	8.86568596314418957e-13
150	299	300	00:41:12	150	122777677.197997004	-6.3604677080775198e-13
151	301	302	03:11:23	151	121851778.703673005	2.85453701205626009
152	303	304	01:33:51	152	125237211.098144993	0.121386293010865995
153	305	306	01:33:51	153	127921110.308597997	-8.39328606616617966e-14
154	307	308	01:33:51	154	130925009.541939005	7.86037901434610957e-14
155	309	310	04:32:31	155	134248908.772525996	-2.2330851723958598
156	311	312	03:03:19	156	139040246.884745002	-0.246700990709212004
157	313	314	06:44:10	157	142040865.082733989	1.90077852479260989
158	315	316	01:20:18	158	149686790.997224003	-0.306628904910147992
159	317	318	06:11:45	159	159070974.967272013	2.94562751477687979
160	319	320	03:34:46	160	149232124.609894991	0.0243623664412392985
161	321	322	11:55:20	161	139749085.770808995	-1.26536465568001999
162	323	324	05:40:48	162	135591514.637506008	-0.387256859036065992
163	325	326	04:07:31	163	135227573.680974007	-2.67164251868842983
164	327	328	\N	164	139781176.750077993	\N
165	329	330	03:05:31	1	0	\N
166	331	332	01:39:40	2	159999.999948576995	0.27586040721958599
167	333	334	01:02:35	3	627901.183144171955	0.111060166672992996
168	335	336	01:02:35	4	1402273.8523518499	-7.58504370423907049e-13
169	337	338	01:02:35	5	2496646.52305791993	2.42472708578133986e-13
170	339	340	03:02:31	6	3911019.18942542002	3.09627393975284981
171	341	342	01:56:21	7	2491185.93491205014	1.98612855526067
172	343	344	00:42:23	8	3237047.49127432983	0.311942285744873982
173	345	346	00:42:23	9	4602479.20872258954	-1.20792265079217006e-13
174	347	348	00:42:23	10	6287910.94450430013	7.42073069659455036e-13
175	349	350	00:42:23	11	8293342.67056610994	-8.95727936267575994e-13
176	351	352	02:02:07	12	10618774.4021055996	-2.39901329935829999
177	353	354	01:16:16	13	8415839.39908402972	-0.220911843540316011
178	355	356	01:20:28	14	6341266.13657358009	-0.360792676705469995
179	357	358	00:52:56	15	4488704.41098123975	-0.818959316625815004
180	359	360	00:52:56	16	3558070.54413559008	7.57172102794357013e-14
181	361	362	00:52:56	17	2947436.66866397019	2.55351295663786004e-15
182	363	364	00:52:56	18	2656802.79502440011	2.54130050336697979e-13
183	365	366	02:02:34	19	2686168.92087752977	3.00208103967072004
184	367	368	01:39:26	20	2478224.64723782009	0.0184435674189197991
185	369	370	01:39:26	21	2613498.02576588001	-2.84217094304040011e-14
186	371	372	01:39:26	22	3068771.40242563002	1.31450406115618989e-13
187	373	374	02:26:12	23	3844044.78598226979	2.98968481330769986
188	375	376	00:47:14	24	3270081.43416891014	0.0612581028292578031
189	377	378	00:47:14	25	2932033.07623418979	1.37667655053519001e-14
190	379	380	00:47:14	26	2913984.71791636012	1.82298620643451007e-13
191	381	382	13:46:42	27	3215936.3585775001	3.04486122983337015
192	383	384	01:56:53	28	2784965.14230100997	0.140517323805658012
193	385	386	01:56:53	29	2859754.73676420003	2.32702745961433013e-13
194	387	388	01:56:53	30	3254544.3340877099	-1.52322598978570998e-13
195	389	390	02:01:09	31	3969333.93204839993	-3.08966894245630996
196	391	392	00:58:14	32	3186574.61977502983	-0.0137260826159719997
197	393	394	00:58:14	33	2741513.31590569019	1.7508217098338701e-13
198	395	396	13:08:41	34	2616452.01280322019	1.92070990339963998
199	397	398	03:09:57	35	1549297.12388018006	-0.499023809624976
200	399	400	13:31:32	36	716253.153835215955	2.65648819794026014
201	401	402	01:07:29	37	1437335.68601858011	-0.98396870950714399
202	403	404	01:07:29	38	1769674.52988211997	-6.8389738316909605e-14
203	405	406	02:12:40	39	2422013.37395999022	2.50834919209924001
204	407	408	01:01:54	40	2485505.44842321984	0.230242496772836008
205	409	410	01:01:54	41	2579822.91818547994	2.22488694134880992e-13
206	411	412	01:52:12	42	2994140.39261450013	-2.3639608128139602
207	413	414	01:09:23	43	3628571.69653677987	-0.201870587969287002
208	415	416	01:09:23	44	4306127.89398667961	4.82724971107017963e-13
209	417	418	01:09:23	45	5303684.0869086897	-1.38999922683070003e-13
210	419	420	01:09:23	46	6621240.27855988033	1.74971148680924999e-13
211	421	422	01:09:23	47	8258796.47090187017	-3.11750625314744007e-13
212	423	424	02:01:35	48	10216352.6532546002	2.68574106404859991
213	425	426	00:49:02	49	9106016.27409105934	0.175175323631266006
214	427	428	00:49:02	50	7943465.33867838979	1.3500311979441901e-13
215	429	430	00:49:02	51	7100914.38925473019	-5.08482145278322011e-14
216	431	432	18:36:53	52	6578363.44788612984	1.00026030966688007
217	433	434	03:27:09	53	4842852.53529977985	-0.696780262699460029
218	435	436	03:27:09	54	4298743.46792194992	-7.11652958784724964e-14
219	437	438	10:03:02	55	4074634.40410722001	0.775625957359090012
220	439	440	22:03:08	56	3059089.00475913007	2.79302758916159011
221	441	442	03:20:27	57	3645026.5759476102	0.0899107374663859066
222	443	444	01:14:46	58	4667624.05757360999	-0.0519861524640283998
223	445	446	01:14:46	59	5943127.27270017006	1.78523862359724995e-13
224	447	448	11:01:45	60	7538630.48056831956	3.07105170472933997
225	449	450	06:15:23	61	6040544.22212958988	0.0274458464021135988
226	451	452	04:30:41	62	4823427.00563696027	0.74857292233450301
227	453	454	01:25:44	63	3253781.62630428001	0.574854709170202982
228	455	456	01:25:44	64	2062841.01937646	-3.17190718135407022e-13
229	457	458	01:25:44	65	1191900.41014596005	-5.83977310952831962e-14
230	459	460	01:25:44	66	640959.799202298047	2.94986257642903992e-13
231	461	462	03:19:22	67	410019.188828920014	2.65401158598141018
232	463	464	01:06:32	68	870370.281853995984	0.230261566237799004
233	465	466	01:06:32	69	1539638.38130720006	2.82440737464639975e-13
234	467	468	01:06:32	70	2528906.47652474977	5.99520433297585037e-14
235	469	470	01:06:32	71	3838174.58265516022	-3.32622818177697e-13
236	471	472	01:06:32	72	5467442.67922789976	6.0484950381578498e-13
237	473	474	01:00:42	73	7416710.78602906968	3.05330553792156989
238	475	476	00:26:08	74	5427550.62458568998	0.0239919206919997005
239	477	478	00:26:08	75	3767493.14458648022	-1.75193193285850005e-13
240	479	480	00:26:08	76	2427435.66042781994	4.44089209850063011e-15
241	481	482	00:26:08	77	1407378.18015478994	-3.57158747021913011e-13
242	483	484	00:26:08	78	707320.698994443053	3.6159963912041298e-13
243	485	486	00:26:08	79	327263.21830824099	-3.5527136788005003e-14
244	487	488	00:26:08	80	267205.735484009027	4.66293670342565999e-14
245	489	490	01:14:31	81	527148.252052961965	-2.74864153025841995
246	491	492	00:29:57	82	145557.009947832994	-0.175938432990802002
247	493	494	00:29:57	83	124124.033073722007	5.15587572635923e-13
248	495	496	00:29:57	84	422691.057965627988	8.83737527601624985e-14
249	497	498	00:29:57	85	1041258.08221094997	-4.48086012738712978e-13
250	499	500	00:29:57	86	1979825.10784944007	-2.70894418008538007e-14
251	501	502	00:29:57	87	3238392.13808372989	6.17728090901436998e-13
252	503	504	05:07:25	88	4816959.16847618017	-1.64500576605964
253	505	506	05:04:22	89	5092819.41856568027	-1.57059180293870004
254	507	508	01:58:24	90	3500929.64276881004	-0.614707517323222041
255	509	510	01:58:24	91	2239582.7155490201	-1.13603570994769004e-13
256	511	512	03:49:40	92	1298235.78343431	-1.81202015508303993
257	513	514	01:10:42	93	2100734.4409266701	-0.66469013153990697
258	515	516	01:21:53	94	3417145.52814255003	-0.247035076549733001
259	517	518	01:23:22	95	4988010.08378676046	-0.77610802551876501
260	519	520	01:23:22	96	6072762.20904173981	-8.5931262105987096e-13
261	521	522	01:25:34	97	7477514.32648433	-0.953990936638206
262	523	524	00:44:20	98	7295547.07590030041	-0.634182110412621958
263	525	526	00:44:20	99	6157589.79092742037	1.71640479607048999e-13
264	527	528	00:44:20	100	5339632.53945036978	0
265	529	530	00:44:20	101	4841675.28517389018	-3.01536573488193021e-13
266	531	532	02:23:36	102	4663718.02793010976	-2.88725055151935983
267	533	534	01:13:53	103	4406428.88049967028	-0.0949549185231637061
268	535	536	02:26:18	104	4628530.75086943991	0.459782811322489993
269	537	538	03:53:48	105	4386256.69356205035	0.519750473440353966
270	539	540	05:24:32	106	3643705.77047111979	-0.285677212511899981
271	541	542	04:39:21	107	3642563.34834783012	-2.78347817138919984
272	543	544	01:32:33	108	4186050.40870128013	-0.445422412982129978
273	545	546	01:17:19	109	4344161.71466957033	-0.0597353171188724011
274	547	548	01:17:19	110	4723989.83258009981	4.24549284616660013e-13
275	549	550	21:15:29	111	5423817.95418807026	-0.264358809750931012
276	551	552	00:57:21	112	5981899.81943019014	-0.269429808371328017
277	553	554	00:57:21	113	6349597.04064447992	-2.90878432451791014e-13
278	555	556	00:57:21	114	7037294.26186082046	-1.54321000422897012e-13
279	557	558	01:39:53	115	8044991.48306859005	2.63549848334711001
280	559	560	01:17:11	116	8126819.54553002957	0.0751556558441181938
281	561	562	01:46:14	117	8357691.22989232	1.11507903858248003
282	563	564	00:31:57	118	6642845.23960459046	0.971412447244000998
283	565	566	00:31:57	119	4807558.32728375029	-2.1297547059262499e-13
284	567	568	00:31:57	120	3292271.41190523002	2.53359833113364983e-13
285	569	570	00:31:57	121	2096984.49144059001	-3.43718109530045012e-13
286	571	572	00:31:57	122	1221697.57381321001	9.03582764166799027e-14
287	573	574	00:31:57	123	666410.655043128994	7.61266050197662025e-14
288	575	576	01:07:18	124	431123.734592856024	-2.89430121213545011
289	577	578	00:35:20	125	536870.483612507	-0.0800581379796834053
290	579	580	00:35:20	126	1003549.43861486996	-2.35367281220532985e-13
291	581	582	00:35:20	127	1790228.39447216992	-3.86357612569553971e-14
292	583	584	00:35:20	128	2896907.34838963998	6.87894186057746992e-13
293	585	586	00:35:20	129	4323586.30313231982	-7.46513961757954955e-13
294	587	588	\N	130	6070265.25521824043	\N
295	589	590	05:58:50	1	0	\N
296	591	592	06:00:27	2	160000.009617947013	-3.09517989859650999
297	593	594	02:30:53	3	344.60115502509899	0.606503346069179994
298	595	596	05:24:17	4	169090.349128994014	-0.440148990283502017
299	597	598	15:06:24	5	621388.848679656046	-1.73084506851316999
300	599	600	04:38:39	6	534809.532154454966	0.883836749278870015
301	601	602	03:39:10	7	1190139.87052417989	1.47024767279335999
302	603	604	16:34:44	8	1741738.73688621004	-1.76244592373365005
303	605	606	17:57:26	9	2531875.82015284011	-0.359147342413204007
304	607	608	03:38:17	10	3283642.9733116501	0.0598387301178181993
305	609	610	01:43:57	11	4421178.46416013967	-0.0190690517605927
306	611	612	01:11:42	12	5858065.99504895043	0.39496101097252001
307	613	614	00:40:42	13	7913352.5878064204	0.289299705655752026
308	615	616	00:40:42	14	10309636.4177874997	-1.25233157177718011e-13
309	617	618	00:40:42	15	13025920.2290346008	-1.82298620643451007e-13
310	619	620	00:40:42	16	16062204.0585593991	3.07531777821168008e-13
311	621	622	00:40:42	17	19418487.888951201	-3.07531777821168008e-13
312	623	624	08:49:41	18	23094771.7202024981	-1.41030017124926998
313	625	626	05:08:31	19	24116751.312226899	-0.220373537879541004
314	627	628	05:15:42	20	24611142.4543933012	-2.13213860808310995
315	629	630	09:58:18	21	21109052.9055862986	-1.48391276334188005
316	631	632	43:53:43	22	22503056.5498602986	2.2271021668674198
317	633	634	01:12:10	23	18971855.3340938985	-0.337824057491230012
318	635	636	01:12:10	24	15659050.8625818007	0
319	637	638	02:48:39	25	12666246.3901613001	-0.359752319545537991
320	639	640	06:34:08	26	10275360.1786247008	0.0167940961386317013
321	641	642	01:01:21	27	8183550.66577086039	0.208678981066465014
322	643	644	01:01:21	28	6199451.43133737985	1.13686837721616004e-13
323	645	646	01:01:21	29	4535352.19333755039	-1.25677246387567998e-13
324	647	648	01:58:11	30	3191252.95736702019	0.157929410805600995
325	649	650	02:15:20	31	2056040.24398290995	0.0491451553120191981
326	651	652	02:15:20	32	1212332.85786203993	3.32622818177697e-13
327	653	654	08:45:09	33	688625.465486961999	-0.242707228818598991
328	655	656	55:51:56	34	629051.147404460004	1.73652599691463005
329	657	658	03:32:43	35	154563.799951891997	-0.163705031835296999
330	659	660	35:50:13	36	3579.30947530198	-2.79630219988051998
331	661	662	14:45:53	37	171005.735686514003	-3.02425549963334994
332	663	664	03:26:14	38	295.492734730562006	-0.79099776863836202
333	665	666	01:54:02	39	158898.155823095003	-0.636545000553851992
334	667	668	05:05:28	40	583235.740899145021	0.296667262703330992
335	669	670	\N	41	1354194.67282931996	\N
336	671	672	08:28:51	1	0	\N
337	673	674	01:54:36	2	159999.996855312987	-0.385679668408561993
338	675	676	03:52:44	3	616493.73929735797	2.04145012655658986
339	677	678	01:26:35	4	604224.620954587008	0.497691491255451979
340	679	680	15:28:06	5	605660.189848395996	-2.30226431710490997
341	681	682	10:13:59	6	1105311.08604867989	-1.10953450904829998
342	683	684	02:13:09	7	1091653.19705959992	-0.203410560031313997
343	685	686	08:42:37	8	1228734.04784925003	2.53810002220971986
344	687	688	03:21:11	9	1618318.94083415996	-0.187228675654140003
345	689	690	02:24:55	10	2477734.90525047015	-0.308137548193755995
346	691	692	02:18:36	11	3833349.90707055014	-0.0300242556007512991
347	693	694	02:18:36	12	5520148.37335858028	2.56239474083485978e-13
348	695	696	05:13:07	13	7526946.83716102038	-1.93756700048774011
349	697	698	05:42:26	14	7236288.78311813995	-2.67841222852542993
350	699	700	05:35:56	15	6553437.13738085981	-0.0122671537783040994
351	701	702	09:14:18	16	6214914.4982316196	0.691330578193277034
352	703	704	00:22:57	17	4970943.80085122027	0.798612150088886974
353	705	706	00:22:57	18	3359906.76418709988	7.06018576934752976e-13
354	707	708	00:22:57	19	2068869.72302292008	-3.73479025483903014e-13
355	709	710	00:22:57	20	1097832.68030325999	3.14942516510540979e-13
356	711	712	00:22:57	21	446795.636738551024	-5.11646280898502988e-13
357	713	714	00:22:57	22	115758.591914834004	4.4958481382195699e-13
358	715	716	00:22:57	23	104721.546159414007	-9.25648446781224013e-14
359	717	718	00:22:57	24	413684.497804422979	-1.62675428683201012e-13
360	719	720	00:22:57	25	1042647.45018003997	3.92241794600068008e-13
361	721	722	00:30:57	26	1991610.40409153001	-3.12218596403354987
362	723	724	00:23:27	27	1046965.09037972998	-0.00270006852616910993
363	725	726	00:23:27	28	421692.948129873024	6.22168982999938028e-13
364	727	728	00:23:27	29	116420.806730972996	-4.68514116391815959e-13
365	729	730	00:23:27	30	131148.663225575001	3.53050921830799982e-13
366	731	732	00:23:27	31	465876.519896776997	-6.0262905776653497e-13
367	733	734	00:23:27	32	1120604.37641110993	6.79456491070596005e-13
368	735	736	00:23:27	33	2095332.23289828002	-5.37347943918576018e-14
369	737	738	00:23:27	34	3390060.08935745992	-5.83533221742981975e-13
370	739	740	00:23:27	35	5004787.94644326996	3.76143560743002985e-13
371	741	742	24:12:06	36	6939515.79061699007	-1.15326856036619008
372	743	744	31:32:21	37	7737688.34815835021	-0.913767710822715018
373	745	746	01:28:24	38	6892565.97117174976	1.23659330260742006
374	747	748	01:13:46	39	8703395.09311998077	0.0400092761814025977
375	749	750	01:13:46	40	10884583.7179438006	5.37347943918576018e-14
376	751	752	01:23:31	41	13385772.3327626996	-0.822803801483113051
377	753	754	01:14:51	42	14462532.373226	-0.257772584396297022
378	755	756	01:14:51	43	15109821.6708933003	1.6853185513809899e-13
379	757	758	14:37:02	44	16077110.9660493992	-2.91119205759539978
380	759	760	01:44:25	45	14453801.2256042995	0.469280403028067006
381	761	762	01:44:25	46	12102864.2256793007	-2.26041407813681998e-13
382	763	764	01:44:25	47	10071927.2325781994	1.30118138486067993e-13
383	765	766	06:51:38	48	8360990.19698404986	-0.344142674563322981
384	767	768	25:17:28	49	7640048.6448749397	0.00227391651398423014
385	769	770	21:44:49	50	7234244.77678176016	2.62294893064010015
386	771	772	01:09:05	51	6548090.5649282299	0.294092315224539991
387	773	774	01:09:05	52	6777998.43809267972	-2.73114864057789014e-13
388	775	776	01:09:05	53	7327906.31146434043	-2.71560551823312987e-13
389	777	778	01:09:05	54	8197814.19404414017	4.15667500419659013e-13
390	779	780	01:09:05	55	9387722.07062654011	-2.73114864057789014e-13
391	781	782	16:33:13	56	10897629.9474155009	2.91537026160680979
392	783	784	03:17:16	57	9889171.13776535913	-0.0124935965287425003
393	785	786	03:17:16	58	9230367.26233050972	2.41584530158434013e-13
394	787	788	34:12:14	59	8891563.38595961966	-0.850375658491157038
395	789	790	01:39:56	60	10721332.3528976999	0.265232001328292
396	791	792	01:39:56	61	12354935.586011	1.11910480882215994e-13
397	793	794	08:24:47	62	14308538.8147289995	-0.954003499602321003
398	795	796	19:48:39	63	17457715.7443922013	2.53459013729061988
399	797	798	\N	64	15168616.8377832994	\N
\.


--
-- TOC entry 3710 (class 0 OID 0)
-- Dependencies: 232
-- Name: step_id_seq; Type: SEQUENCE SET; Schema: ibex_traj_materialized_bursts; Owner: -
--

SELECT pg_catalog.setval('"step_id_seq"', 399, true);


--
-- TOC entry 3510 (class 2606 OID 629590)
-- Name: animal_burst animal_burst_pkey; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "animal_burst"
    ADD CONSTRAINT "animal_burst_pkey" PRIMARY KEY ("id");


--
-- TOC entry 3512 (class 2606 OID 629592)
-- Name: animal_burst burst_pgtraj_unique; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "animal_burst"
    ADD CONSTRAINT "burst_pgtraj_unique" UNIQUE ("burst_name", "pgtraj_id");


--
-- TOC entry 3522 (class 2606 OID 629686)
-- Name: infolocs_ibex_int_space infolocs_ibex_int_space_pkey; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "infolocs_ibex_int_space"
    ADD CONSTRAINT "infolocs_ibex_int_space_pkey" PRIMARY KEY ("step_id");


--
-- TOC entry 3506 (class 2606 OID 629579)
-- Name: pgtraj pgtraj_pgtraj_name_key; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "pgtraj"
    ADD CONSTRAINT "pgtraj_pgtraj_name_key" UNIQUE ("pgtraj_name");


--
-- TOC entry 3508 (class 2606 OID 629577)
-- Name: pgtraj pgtraj_pkey; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "pgtraj"
    ADD CONSTRAINT "pgtraj_pkey" PRIMARY KEY ("id");


--
-- TOC entry 3515 (class 2606 OID 629608)
-- Name: relocation relocation_pkey; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "relocation"
    ADD CONSTRAINT "relocation_pkey" PRIMARY KEY ("id");


--
-- TOC entry 3520 (class 2606 OID 629634)
-- Name: s_b_rel s_b_rel_pkey; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "s_b_rel"
    ADD CONSTRAINT "s_b_rel_pkey" PRIMARY KEY ("step_id", "animal_burst_id");


--
-- TOC entry 3518 (class 2606 OID 629619)
-- Name: step step_pkey; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "step"
    ADD CONSTRAINT "step_pkey" PRIMARY KEY ("id");


--
-- TOC entry 3523 (class 1259 OID 629700)
-- Name: all_burst_summary_shiny_burst_name_idx; Type: INDEX; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE INDEX "all_burst_summary_shiny_burst_name_idx" ON "all_burst_summary_shiny" USING "btree" ("burst_name");


--
-- TOC entry 3513 (class 1259 OID 629645)
-- Name: relocation_geom_idx; Type: INDEX; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE INDEX "relocation_geom_idx" ON "relocation" USING "gist" ("geom");


--
-- TOC entry 3516 (class 1259 OID 629646)
-- Name: relocation_time_idx; Type: INDEX; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE INDEX "relocation_time_idx" ON "relocation" USING "btree" ("relocation_time");


--
-- TOC entry 3524 (class 1259 OID 629709)
-- Name: step_geometry_shiny_ibex_int_space_date_idx; Type: INDEX; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE INDEX "step_geometry_shiny_ibex_int_space_date_idx" ON "step_geometry_shiny_ibex_int_space" USING "btree" ("date");


--
-- TOC entry 3525 (class 1259 OID 629710)
-- Name: step_geometry_shiny_ibex_int_space_step_geom_idx; Type: INDEX; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE INDEX "step_geometry_shiny_ibex_int_space_step_geom_idx" ON "step_geometry_shiny_ibex_int_space" USING "gist" ("step_geom");


--
-- TOC entry 3526 (class 2606 OID 629593)
-- Name: animal_burst animal_burst_pgtraj_id_fkey; Type: FK CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "animal_burst"
    ADD CONSTRAINT "animal_burst_pgtraj_id_fkey" FOREIGN KEY ("pgtraj_id") REFERENCES "pgtraj"("id") ON DELETE CASCADE;


--
-- TOC entry 3531 (class 2606 OID 629687)
-- Name: infolocs_ibex_int_space infolocs_ibex_int_space_step_id_fkey; Type: FK CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "infolocs_ibex_int_space"
    ADD CONSTRAINT "infolocs_ibex_int_space_step_id_fkey" FOREIGN KEY ("step_id") REFERENCES "step"("id") ON DELETE CASCADE;


--
-- TOC entry 3530 (class 2606 OID 629640)
-- Name: s_b_rel s_b_rel_animal_burst_id_fkey; Type: FK CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "s_b_rel"
    ADD CONSTRAINT "s_b_rel_animal_burst_id_fkey" FOREIGN KEY ("animal_burst_id") REFERENCES "animal_burst"("id") ON DELETE CASCADE;


--
-- TOC entry 3529 (class 2606 OID 629635)
-- Name: s_b_rel s_b_rel_step_id_fkey; Type: FK CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "s_b_rel"
    ADD CONSTRAINT "s_b_rel_step_id_fkey" FOREIGN KEY ("step_id") REFERENCES "step"("id") ON DELETE CASCADE;


--
-- TOC entry 3527 (class 2606 OID 629620)
-- Name: step step_relocation_id_1_fkey; Type: FK CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "step"
    ADD CONSTRAINT "step_relocation_id_1_fkey" FOREIGN KEY ("relocation_id_1") REFERENCES "relocation"("id") ON DELETE CASCADE;


--
-- TOC entry 3528 (class 2606 OID 629625)
-- Name: step step_relocation_id_2_fkey; Type: FK CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY "step"
    ADD CONSTRAINT "step_relocation_id_2_fkey" FOREIGN KEY ("relocation_id_2") REFERENCES "relocation"("id") ON DELETE SET NULL;


--
-- TOC entry 3669 (class 0 OID 629692)
-- Dependencies: 240 3672
-- Name: all_burst_summary_shiny; Type: MATERIALIZED VIEW DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

REFRESH MATERIALIZED VIEW "all_burst_summary_shiny";


--
-- TOC entry 3670 (class 0 OID 629701)
-- Dependencies: 241 3672
-- Name: step_geometry_shiny_ibex_int_space; Type: MATERIALIZED VIEW DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

REFRESH MATERIALIZED VIEW "step_geometry_shiny_ibex_int_space";


-- Completed on 2017-08-28 17:53:01 CEST

--
-- PostgreSQL database dump complete
--

