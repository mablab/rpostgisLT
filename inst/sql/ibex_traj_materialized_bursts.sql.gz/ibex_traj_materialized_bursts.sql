--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.8
-- Dumped by pg_dump version 9.6.4

-- Started on 2017-08-16 13:06:17 CEST

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 22 (class 2615 OID 615730)
-- Name: ibex_traj_materialized_bursts; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA ibex_traj_materialized_bursts;


SET search_path = ibex_traj_materialized_bursts, pg_catalog;

--
-- TOC entry 1402 (class 1255 OID 615812)
-- Name: insert_pgtraj(integer); Type: FUNCTION; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE FUNCTION insert_pgtraj(integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
DECLARE pg record;
BEGIN
-- insert pgtrajs
INSERT INTO pgtraj (pgtraj_name, proj4string, time_zone, note)
		SELECT DISTINCT pgtraj_name, proj4string, time_zone, note
		FROM zgaqtsn_temp
		ORDER BY pgtraj_name;
IF $1 = 2 THEN
-- loop bursts
	FOR pg IN 
	SELECT DISTINCT pgtraj_name, animal_name, burst_name FROM zgaqtsn_temp ORDER BY pgtraj_name, burst_name
	LOOP
		ALTER TABLE relocation ADD COLUMN mark integer;
		ALTER TABLE step ADD COLUMN mark integer;
		--burst
		INSERT INTO animal_burst (burst_name, animal_name, pgtraj_id)
			SELECT pg.burst_name, pg.animal_name, pgtraj.id
			FROM pgtraj
			WHERE pg.pgtraj_name = pgtraj.pgtraj_name;
		-- relocations
		INSERT INTO relocation (geom, relocation_time, orig_id, mark) --added orig_id for infoloc support
			SELECT geom, relocation_time ,id, 1	--added orig_id for infoloc support
			FROM zgaqtsn_temp
			WHERE pgtraj_name = pg.pgtraj_name
			AND animal_name = pg.animal_name
			AND burst_name = pg.burst_name
			ORDER BY relocation_time;
		-- steps	
		WITH relos AS (
			SELECT
				a.id AS relocation_id_1,
				a.relocation_time AS rt,
				b.id AS relocation_id_2,
				b.relocation_time - a.relocation_time AS dt,
				a.mark
			FROM (SELECT * FROM relocation WHERE mark = 1) a 
			LEFT OUTER JOIN LATERAL 
				(SELECT c.id, c.relocation_time
				   FROM relocation c
				   WHERE mark = 1
				   AND a.relocation_time < c.relocation_time
				   ORDER BY c.relocation_time ASC
				   LIMIT 1
				 ) AS b 
			ON TRUE
			)
		INSERT INTO step (relocation_id_1, relocation_id_2, dt, mark)
			SELECT relocation_id_1, relocation_id_2, dt, 1
			FROM relos
			ORDER BY rt;
		-- step-burst rel
		INSERT INTO s_b_rel (step_id, animal_burst_id)
			SELECT a.id, a.burst_id
			FROM (SELECT step.id as id, pg.burst_name, pgtraj.id as pg_id, animal_burst.id as burst_id 
				 FROM step, animal_burst, pgtraj
				 WHERE step.mark = 1
				 AND pgtraj.id = animal_burst.pgtraj_id
				 AND pg.pgtraj_name = pgtraj.pgtraj_name
				 AND pg.burst_name = animal_burst.burst_name) a;
		-- drop mark columns
		ALTER TABLE relocation DROP COLUMN mark;
		ALTER TABLE step DROP COLUMN mark;
	END LOOP;
ELSE
-- loop bursts for type 1 (no time)
	FOR pg IN 
	SELECT DISTINCT pgtraj_name, animal_name, burst_name FROM zgaqtsn_temp ORDER BY pgtraj_name, burst_name
	LOOP
		ALTER TABLE relocation ADD COLUMN mark integer;
		ALTER TABLE step ADD COLUMN mark integer;
		--burst
		INSERT INTO animal_burst (burst_name, animal_name, pgtraj_id)
			SELECT pg.burst_name, pg.animal_name, pgtraj.id
			FROM pgtraj
			WHERE pg.pgtraj_name = pgtraj.pgtraj_name;
		-- relocations
		INSERT INTO relocation (geom, orig_id, mark) --added orig_id for infoloc support
			SELECT geom ,id, 1	--added orig_id for infoloc support
			FROM zgaqtsn_temp
			WHERE pgtraj_name = pg.pgtraj_name
			AND animal_name = pg.animal_name
			AND burst_name = pg.burst_name
			ORDER BY id;
		-- steps	
		WITH relos AS (
			SELECT
				a.id AS relocation_id_1,
				b.id AS relocation_id_2,
				a.mark
			FROM (SELECT * FROM relocation WHERE mark = 1) a 
			LEFT OUTER JOIN LATERAL 
				(SELECT c.id
				   FROM relocation c
				   WHERE mark = 1
				   AND a.id < c.id
				   ORDER BY c.id ASC
				   LIMIT 1
				 ) AS b 
			ON TRUE
			)
		INSERT INTO step (relocation_id_1, relocation_id_2, mark)
			SELECT relocation_id_1, relocation_id_2, 1
			FROM relos
			ORDER BY relocation_id_1;
		-- step-burst rel
		INSERT INTO s_b_rel (step_id, animal_burst_id)
			SELECT a.id, a.burst_id
			FROM (SELECT step.id as id, pg.burst_name, pgtraj.id as pg_id, animal_burst.id as burst_id 
				 FROM step, animal_burst, pgtraj
				 WHERE step.mark = 1
				 AND pgtraj.id = animal_burst.pgtraj_id
				 AND pg.pgtraj_name = pgtraj.pgtraj_name
				 AND pg.burst_name = animal_burst.burst_name) a;
		-- drop mark columns
		ALTER TABLE relocation DROP COLUMN mark;
		ALTER TABLE step DROP COLUMN mark;
	END LOOP;
END IF;
RETURN TRUE;
END;
$_$;


SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 222 (class 1259 OID 615747)
-- Name: animal_burst; Type: TABLE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE TABLE animal_burst (
    id integer NOT NULL,
    burst_name text NOT NULL,
    animal_name text NOT NULL,
    pgtraj_id integer NOT NULL,
    info_cols text[]
);


--
-- TOC entry 3670 (class 0 OID 0)
-- Dependencies: 222
-- Name: TABLE animal_burst; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON TABLE animal_burst IS 'Contains animal and burst information and their relation to pgtrajs.';


--
-- TOC entry 3671 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN animal_burst.id; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN animal_burst.id IS 'Auto-generated numeric ID.';


--
-- TOC entry 3672 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN animal_burst.burst_name; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN animal_burst.burst_name IS 'Name of burst.';


--
-- TOC entry 3673 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN animal_burst.animal_name; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN animal_burst.animal_name IS 'Name of animal.';


--
-- TOC entry 3674 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN animal_burst.pgtraj_id; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN animal_burst.pgtraj_id IS 'Foreign key to pgtraj records.';


--
-- TOC entry 3675 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN animal_burst.info_cols; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN animal_burst.info_cols IS 'Array holding R data type definitions for infolocs columns. Do not edit.';


--
-- TOC entry 220 (class 1259 OID 615733)
-- Name: pgtraj; Type: TABLE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE TABLE pgtraj (
    id integer NOT NULL,
    pgtraj_name text NOT NULL,
    proj4string text,
    time_zone text,
    note text,
    insert_timestamp timestamp with time zone DEFAULT now()
);


--
-- TOC entry 3676 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE pgtraj; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON TABLE pgtraj IS 'Groups of trajectories, with unique names. Groups can be defined on any criteria, e.g. steps belonging to one ltraj object can form a group.';


--
-- TOC entry 3677 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN pgtraj.id; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN pgtraj.id IS 'Auto-generated numeric ID.';


--
-- TOC entry 3678 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN pgtraj.pgtraj_name; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN pgtraj.pgtraj_name IS 'Name or identifier of trajectory group, not null.';


--
-- TOC entry 3679 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN pgtraj.proj4string; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN pgtraj.proj4string IS 'A PROJ.4 projection string of the ltraj, imported from R.';


--
-- TOC entry 3680 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN pgtraj.time_zone; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN pgtraj.time_zone IS 'Time zone of the imported trajectory.';


--
-- TOC entry 3681 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN pgtraj.note; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN pgtraj.note IS 'User comment.';


--
-- TOC entry 3682 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN pgtraj.insert_timestamp; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN pgtraj.insert_timestamp IS 'Time when pgtraj was created.';


--
-- TOC entry 224 (class 1259 OID 615765)
-- Name: relocation; Type: TABLE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE TABLE relocation (
    id integer NOT NULL,
    geom public.geometry,
    relocation_time timestamp with time zone,
    orig_id integer
);


--
-- TOC entry 3683 (class 0 OID 0)
-- Dependencies: 224
-- Name: TABLE relocation; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON TABLE relocation IS 'Relocation geometry and time stamp.';


--
-- TOC entry 3684 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN relocation.id; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN relocation.id IS 'Auto-generated numeric ID.';


--
-- TOC entry 3685 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN relocation.geom; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN relocation.geom IS 'Geometry of the relocation.';


--
-- TOC entry 3686 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN relocation.relocation_time; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN relocation.relocation_time IS 'Time stamp of the relocation.';


--
-- TOC entry 3687 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN relocation.orig_id; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN relocation.orig_id IS 'ID number from the original relocations table in the database.';


--
-- TOC entry 227 (class 1259 OID 615795)
-- Name: s_b_rel; Type: TABLE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE TABLE s_b_rel (
    step_id integer NOT NULL,
    animal_burst_id integer NOT NULL
);


--
-- TOC entry 3688 (class 0 OID 0)
-- Dependencies: 227
-- Name: TABLE s_b_rel; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON TABLE s_b_rel IS 'Relates step and burst.';


--
-- TOC entry 226 (class 1259 OID 615776)
-- Name: step; Type: TABLE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE TABLE step (
    id integer NOT NULL,
    relocation_id_1 integer,
    relocation_id_2 integer,
    dt interval,
    r_rowname text,
    r2n double precision,
    rel_angle double precision
);


--
-- TOC entry 3689 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE step; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON TABLE step IS 'Steps derived from relocations.';


--
-- TOC entry 3690 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN step.id; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN step.id IS 'Auto-generated numeric ID.';


--
-- TOC entry 3691 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN step.relocation_id_1; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN step.relocation_id_1 IS 'The first of the two successive relocations that form a step.';


--
-- TOC entry 3692 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN step.relocation_id_2; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN step.relocation_id_2 IS 'The second of the two successive relocations that form a step.';


--
-- TOC entry 3693 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN step.dt; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN step.dt IS 'Duration of the step.';


--
-- TOC entry 3694 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN step.r_rowname; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN step.r_rowname IS 'Row name in the ltraj. This value is used for backward referencing between pgtraj and ltraj.';


--
-- TOC entry 3695 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN step.r2n; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN step.r2n IS 'R2n parameter copied from the ltraj on import from R.';


--
-- TOC entry 3696 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN step.rel_angle; Type: COMMENT; Schema: ibex_traj_materialized_bursts; Owner: -
--

COMMENT ON COLUMN step.rel_angle IS 'Rel.angle parameter copied from the ltraj on import from R.';


--
-- TOC entry 229 (class 1259 OID 615818)
-- Name: all_burst_summary; Type: VIEW; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE VIEW all_burst_summary AS
 SELECT p.id AS pgtraj_id,
    p.pgtraj_name,
    ab.animal_name,
    ab.burst_name,
    count(r.id) AS num_relocations,
    (count(r.id) - count(r.geom)) AS num_na,
    min(r.relocation_time) AS date_begin,
    max(r.relocation_time) AS date_end
   FROM pgtraj p,
    animal_burst ab,
    relocation r,
    s_b_rel sb,
    step s
  WHERE ((p.id = ab.pgtraj_id) AND (ab.id = sb.animal_burst_id) AND (sb.step_id = s.id) AND (s.relocation_id_1 = r.id))
  GROUP BY p.id, p.pgtraj_name, ab.id, ab.animal_name, ab.burst_name
  ORDER BY p.id, ab.id;


--
-- TOC entry 233 (class 1259 OID 615853)
-- Name: all_burst_summary_shiny; Type: MATERIALIZED VIEW; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE MATERIALIZED VIEW all_burst_summary_shiny AS
 SELECT p.id AS pgtraj_id,
    p.pgtraj_name,
    ab.animal_name,
    ab.burst_name,
    count(r.id) AS num_relocations,
    (count(r.id) - count(r.geom)) AS num_na,
    min(r.relocation_time) AS date_begin,
    max(r.relocation_time) AS date_end,
    (public.st_transform(public.st_makeline(r.geom), 4326))::public.geometry(LineString,4326) AS burst_geom
   FROM pgtraj p,
    animal_burst ab,
    relocation r,
    s_b_rel sb,
    step s
  WHERE ((p.id = ab.pgtraj_id) AND (ab.id = sb.animal_burst_id) AND (sb.step_id = s.id) AND (s.relocation_id_1 = r.id))
  GROUP BY p.id, p.pgtraj_name, ab.id, ab.animal_name, ab.burst_name
  ORDER BY p.id, ab.id
  WITH NO DATA;


--
-- TOC entry 228 (class 1259 OID 615813)
-- Name: all_pgtraj_summary; Type: VIEW; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE VIEW all_pgtraj_summary AS
 WITH p AS (
         SELECT p_1.id,
            p_1.pgtraj_name,
            p_1.proj4string,
            p_1.time_zone,
            p_1.note,
            p_1.insert_timestamp,
            a.table_name
           FROM (pgtraj p_1
             LEFT JOIN ( SELECT tables.table_name
                   FROM information_schema.tables
                  WHERE (((tables.table_schema)::text = 'ibex_traj_materialized_bursts'::text) AND ((tables.table_name)::text ~~ 'infolocs_%'::text))) a ON ((p_1.pgtraj_name = "substring"((a.table_name)::text, 10))))
        )
 SELECT p.id AS pgtraj_id,
    p.pgtraj_name,
    p.insert_timestamp AS last_update,
    count(DISTINCT ab.burst_name) AS num_bursts,
    count(r.id) AS num_relocations,
    min(r.relocation_time) AS earliest_date,
    max(r.relocation_time) AS latest_date,
    (p.table_name)::text AS infolocs_table
   FROM p,
    animal_burst ab,
    relocation r,
    s_b_rel sb,
    step s
  WHERE ((p.id = ab.pgtraj_id) AND (ab.id = sb.animal_burst_id) AND (sb.step_id = s.id) AND (s.relocation_id_1 = r.id))
  GROUP BY p.id, p.pgtraj_name, p.insert_timestamp, p.table_name
  ORDER BY p.id;


--
-- TOC entry 221 (class 1259 OID 615745)
-- Name: animal_burst_id_seq; Type: SEQUENCE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE SEQUENCE animal_burst_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3697 (class 0 OID 0)
-- Dependencies: 221
-- Name: animal_burst_id_seq; Type: SEQUENCE OWNED BY; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER SEQUENCE animal_burst_id_seq OWNED BY animal_burst.id;


--
-- TOC entry 230 (class 1259 OID 615833)
-- Name: parameters_ibex; Type: VIEW; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE VIEW parameters_ibex AS
 WITH step_geom AS (
         SELECT s.id AS step_id,
            public.st_makeline(r1.geom, r2.geom) AS step_geom,
            r1.relocation_time,
            s.dt,
            s.r_rowname,
            r1.geom AS relocation1_geom,
            r2.geom AS relocation2_geom,
            s.r2n,
            s.rel_angle,
            ab.burst_name,
            ab.id AS burst_order,
            ab.animal_name,
            p.pgtraj_name,
            ab.id AS ab_id
           FROM (((((step s
             JOIN relocation r1 ON ((s.relocation_id_1 = r1.id)))
             LEFT JOIN relocation r2 ON ((s.relocation_id_2 = r2.id)))
             JOIN s_b_rel rel ON ((rel.step_id = s.id)))
             JOIN animal_burst ab ON ((ab.id = rel.animal_burst_id)))
             JOIN pgtraj p ON ((p.id = ab.pgtraj_id)))
          WHERE (p.pgtraj_name = 'ibex'::text)
        )
 SELECT t.step_id,
    t.r_rowname,
    public.st_x(t.relocation1_geom) AS x,
    public.st_y(t.relocation1_geom) AS y,
    t.relocation_time AS date,
    t.dx,
    t.dy,
    t.dist,
    date_part('epoch'::text, t.dt) AS dt,
    t.r2n,
        CASE
            WHEN (t.dist < (0.0000001)::double precision) THEN NULL::double precision
            WHEN (t.dist >= (0.0000001)::double precision) THEN atan2(t.dy, t.dx)
            ELSE NULL::double precision
        END AS abs_angle,
    t.rel_angle,
    t.animal_name,
    t.burst_name AS burst,
    t.pgtraj_name AS pgtraj
   FROM ( SELECT step_geom.step_id,
            step_geom.relocation_time,
            step_geom.dt,
            step_geom.r_rowname,
            step_geom.relocation1_geom,
            step_geom.relocation2_geom,
            step_geom.burst_name,
            step_geom.burst_order,
            step_geom.animal_name,
            step_geom.pgtraj_name,
            public.st_length(step_geom.step_geom) AS dist,
            (public.st_x(step_geom.relocation2_geom) - public.st_x(step_geom.relocation1_geom)) AS dx,
            (public.st_y(step_geom.relocation2_geom) - public.st_y(step_geom.relocation1_geom)) AS dy,
            step_geom.r2n,
            step_geom.rel_angle
           FROM step_geom) t
  ORDER BY t.burst_order, t.step_id;


--
-- TOC entry 219 (class 1259 OID 615731)
-- Name: pgtraj_id_seq; Type: SEQUENCE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE SEQUENCE pgtraj_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3698 (class 0 OID 0)
-- Dependencies: 219
-- Name: pgtraj_id_seq; Type: SEQUENCE OWNED BY; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER SEQUENCE pgtraj_id_seq OWNED BY pgtraj.id;


--
-- TOC entry 223 (class 1259 OID 615763)
-- Name: relocation_id_seq; Type: SEQUENCE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE SEQUENCE relocation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3699 (class 0 OID 0)
-- Dependencies: 223
-- Name: relocation_id_seq; Type: SEQUENCE OWNED BY; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER SEQUENCE relocation_id_seq OWNED BY relocation.id;


--
-- TOC entry 231 (class 1259 OID 615838)
-- Name: step_geometry_ibex; Type: VIEW; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE VIEW step_geometry_ibex AS
 SELECT s.id AS step_id,
    (public.st_makeline(r1.geom, r2.geom))::public.geometry(LineString,3395) AS step_geom,
    r1.relocation_time,
    s.dt,
    s.r_rowname,
    ab.burst_name,
    ab.animal_name,
    p.pgtraj_name,
    ab.id AS ab_id
   FROM (((((step s
     JOIN relocation r1 ON ((s.relocation_id_1 = r1.id)))
     JOIN relocation r2 ON ((s.relocation_id_2 = r2.id)))
     JOIN s_b_rel rel ON ((rel.step_id = s.id)))
     JOIN animal_burst ab ON ((ab.id = rel.animal_burst_id)))
     JOIN pgtraj p ON ((p.id = ab.pgtraj_id)))
  WHERE (p.pgtraj_name = 'ibex'::text)
  ORDER BY ab.id, s.id;


--
-- TOC entry 232 (class 1259 OID 615843)
-- Name: step_geometry_shiny_ibex; Type: MATERIALIZED VIEW; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE MATERIALIZED VIEW step_geometry_shiny_ibex AS
 SELECT p.step_id,
    (public.st_transform(public.st_makeline(r1.geom, r2.geom), 4326))::public.geometry(LineString,4326) AS step_geom,
    r1.relocation_time AS date,
    p.dx,
    p.dy,
    p.dist,
    p.dt,
    p.abs_angle,
    p.rel_angle,
    p.animal_name,
    p.burst AS burst_name,
    p.pgtraj AS pgtraj_name
   FROM (((parameters_ibex p
     JOIN step s ON ((p.step_id = s.id)))
     JOIN relocation r1 ON ((s.relocation_id_1 = r1.id)))
     JOIN relocation r2 ON ((s.relocation_id_2 = r2.id)))
  WHERE (public.st_makeline(r1.geom, r2.geom) IS NOT NULL)
  WITH NO DATA;


--
-- TOC entry 225 (class 1259 OID 615774)
-- Name: step_id_seq; Type: SEQUENCE; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE SEQUENCE step_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3700 (class 0 OID 0)
-- Dependencies: 225
-- Name: step_id_seq; Type: SEQUENCE OWNED BY; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER SEQUENCE step_id_seq OWNED BY step.id;


SET search_path = public, pg_catalog;

--
-- TOC entry 214 (class 1259 OID 598920)
-- Name: infoloc_test; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE infoloc_test (
    gid integer,
    dummy integer,
    info_day date
);


SET search_path = ibex_traj_materialized_bursts, pg_catalog;

--
-- TOC entry 3499 (class 2604 OID 615750)
-- Name: animal_burst id; Type: DEFAULT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY animal_burst ALTER COLUMN id SET DEFAULT nextval('animal_burst_id_seq'::regclass);


--
-- TOC entry 3497 (class 2604 OID 615736)
-- Name: pgtraj id; Type: DEFAULT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY pgtraj ALTER COLUMN id SET DEFAULT nextval('pgtraj_id_seq'::regclass);


--
-- TOC entry 3500 (class 2604 OID 615768)
-- Name: relocation id; Type: DEFAULT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY relocation ALTER COLUMN id SET DEFAULT nextval('relocation_id_seq'::regclass);


--
-- TOC entry 3501 (class 2604 OID 615779)
-- Name: step id; Type: DEFAULT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY step ALTER COLUMN id SET DEFAULT nextval('step_id_seq'::regclass);


--
-- TOC entry 3657 (class 0 OID 615747)
-- Dependencies: 222
-- Data for Name: animal_burst; Type: TABLE DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

COPY animal_burst (id, burst_name, animal_name, pgtraj_id, info_cols) FROM stdin;
1	A153	A153	1	\N
2	A160	A160	1	\N
3	A286	A286	1	\N
4	A289	A289	1	\N
\.


--
-- TOC entry 3701 (class 0 OID 0)
-- Dependencies: 221
-- Name: animal_burst_id_seq; Type: SEQUENCE SET; Schema: ibex_traj_materialized_bursts; Owner: -
--

SELECT pg_catalog.setval('animal_burst_id_seq', 4, true);


--
-- TOC entry 3655 (class 0 OID 615733)
-- Dependencies: 220
-- Data for Name: pgtraj; Type: TABLE DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

COPY pgtraj (id, pgtraj_name, proj4string, time_zone, note, insert_timestamp) FROM stdin;
1	ibex	+init=epsg:3395 +proj=merc +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0	Europe/Paris	\N	2017-08-16 13:03:23.08785+02
\.


--
-- TOC entry 3702 (class 0 OID 0)
-- Dependencies: 219
-- Name: pgtraj_id_seq; Type: SEQUENCE SET; Schema: ibex_traj_materialized_bursts; Owner: -
--

SELECT pg_catalog.setval('pgtraj_id_seq', 1, true);


--
-- TOC entry 3659 (class 0 OID 615765)
-- Dependencies: 224
-- Data for Name: relocation; Type: TABLE DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

COPY relocation (id, geom, relocation_time, orig_id) FROM stdin;
1	0101000020430D00000000000020612B410000000099FB3E41	2003-06-01 00:00:00+02	\N
2	0101000020430D000000000000DC602B410000000082FB3E41	2003-06-01 04:00:00+02	\N
3	0101000020430D000000000000DC602B410000000082FB3E41	2003-06-01 04:00:00+02	\N
4	\N	2003-06-01 08:00:00+02	\N
5	\N	2003-06-01 08:00:00+02	\N
6	\N	2003-06-01 12:00:00+02	\N
7	0101000020430D000000000000A8612B4100000000EAFF3E41	2003-06-01 12:00:00+02	\N
8	\N	2003-06-01 16:00:00+02	\N
9	\N	2003-06-01 16:00:00+02	\N
10	\N	2003-06-01 20:00:00+02	\N
11	0101000020430D00000000000048622B4100000000CBFF3E41	2003-06-01 20:00:00+02	\N
12	0101000020430D0000000000006C622B4100000000D7FE3E41	2003-06-02 00:00:00+02	\N
13	0101000020430D0000000000006C622B4100000000D7FE3E41	2003-06-02 00:00:00+02	\N
14	0101000020430D0000000000006A622B4100000000D2FE3E41	2003-06-02 04:00:00+02	\N
15	0101000020430D0000000000006A622B4100000000D2FE3E41	2003-06-02 04:00:00+02	\N
16	0101000020430D000000000000D8662B41000000000F063F41	2003-06-02 08:00:00+02	\N
17	0101000020430D000000000000D8662B41000000000F063F41	2003-06-02 08:00:00+02	\N
18	0101000020430D000000000000D4742B4100000000190B3F41	2003-06-02 12:00:00+02	\N
19	0101000020430D000000000000D4742B4100000000190B3F41	2003-06-02 12:00:00+02	\N
20	0101000020430D000000000000BC7A2B4100000000640D3F41	2003-06-02 16:00:00+02	\N
21	0101000020430D000000000000BC7A2B4100000000640D3F41	2003-06-02 16:00:00+02	\N
22	\N	2003-06-02 20:00:00+02	\N
23	\N	2003-06-02 20:00:00+02	\N
24	\N	2003-06-03 00:00:00+02	\N
25	\N	2003-06-03 00:00:00+02	\N
26	\N	2003-06-03 04:00:00+02	\N
27	\N	2003-06-03 04:00:00+02	\N
28	\N	2003-06-03 08:00:00+02	\N
29	0101000020430D0000000000002E7D2B4100000000900D3F41	2003-06-03 08:00:00+02	\N
30	0101000020430D000000000000DC792B410000000014113F41	2003-06-03 12:00:00+02	\N
31	0101000020430D000000000000DC792B410000000014113F41	2003-06-03 12:00:00+02	\N
32	0101000020430D000000000000A0702B4100000000A6153F41	2003-06-03 16:00:00+02	\N
33	0101000020430D000000000000A0702B4100000000A6153F41	2003-06-03 16:00:00+02	\N
34	0101000020430D00000000000028732B4100000000AC193F41	2003-06-03 20:00:00+02	\N
35	0101000020430D00000000000028732B4100000000AC193F41	2003-06-03 20:00:00+02	\N
36	\N	2003-06-04 00:00:00+02	\N
37	\N	2003-06-04 00:00:00+02	\N
38	\N	2003-06-04 04:00:00+02	\N
39	\N	2003-06-04 04:00:00+02	\N
40	\N	2003-06-04 08:00:00+02	\N
41	0101000020430D000000000000E8742B4100000000A11A3F41	2003-06-04 08:00:00+02	\N
42	\N	2003-06-04 12:00:00+02	\N
43	\N	2003-06-04 12:00:00+02	\N
44	\N	2003-06-04 16:00:00+02	\N
45	0101000020430D00000000000040712B4100000000271C3F41	2003-06-04 16:00:00+02	\N
46	0101000020430D00000000000076732B4100000000FA183F41	2003-06-04 20:00:00+02	\N
47	0101000020430D00000000000076732B4100000000FA183F41	2003-06-04 20:00:00+02	\N
48	0101000020430D000000000000B0732B4100000000FA193F41	2003-06-05 00:00:00+02	\N
49	0101000020430D000000000000B0732B4100000000FA193F41	2003-06-05 00:00:00+02	\N
50	0101000020430D000000000000B87F2B41000000003C0E3F41	2003-06-05 04:00:00+02	\N
51	0101000020430D000000000000B87F2B41000000003C0E3F41	2003-06-05 04:00:00+02	\N
52	0101000020430D000000000000CC702B4100000000051C3F41	2003-06-05 08:00:00+02	\N
53	0101000020430D000000000000CC702B4100000000051C3F41	2003-06-05 08:00:00+02	\N
54	0101000020430D000000000000626F2B4100000000111E3F41	2003-06-05 12:00:00+02	\N
55	0101000020430D000000000000626F2B4100000000111E3F41	2003-06-05 12:00:00+02	\N
56	0101000020430D000000000000F4712B4100000000AB1E3F41	2003-06-05 16:00:00+02	\N
57	0101000020430D000000000000F4712B4100000000AB1E3F41	2003-06-05 16:00:00+02	\N
58	0101000020430D0000000000003A7B2B4100000000C11D3F41	2003-06-05 20:00:00+02	\N
59	0101000020430D0000000000003A7B2B4100000000C11D3F41	2003-06-05 20:00:00+02	\N
60	0101000020430D000000000000A07B2B4100000000F1243F41	2003-06-06 00:00:00+02	\N
61	0101000020430D000000000000A07B2B4100000000F1243F41	2003-06-06 00:00:00+02	\N
62	0101000020430D0000000000001A842B4100000000BD1A3F41	2003-06-06 04:00:00+02	\N
63	0101000020430D0000000000001A842B4100000000BD1A3F41	2003-06-06 04:00:00+02	\N
64	0101000020430D00000000000010802B41000000004E263F41	2003-06-06 08:00:00+02	\N
65	0101000020430D00000000000010802B41000000004E263F41	2003-06-06 08:00:00+02	\N
66	0101000020430D000000000000807F2B4100000000FC253F41	2003-06-06 12:00:00+02	\N
67	0101000020430D000000000000807F2B4100000000FC253F41	2003-06-06 12:00:00+02	\N
68	0101000020430D0000000000004A822B41000000007F263F41	2003-06-06 16:00:00+02	\N
69	0101000020430D0000000000004A822B41000000007F263F41	2003-06-06 16:00:00+02	\N
70	0101000020430D000000000000E0822B410000000007263F41	2003-06-06 20:00:00+02	\N
71	0101000020430D000000000000E0822B410000000007263F41	2003-06-06 20:00:00+02	\N
72	0101000020430D000000000000EA832B410000000080263F41	2003-06-07 00:00:00+02	\N
73	0101000020430D000000000000EA832B410000000080263F41	2003-06-07 00:00:00+02	\N
74	0101000020430D00000000000076932B4100000000212A3F41	2003-06-07 04:00:00+02	\N
75	0101000020430D00000000000076932B4100000000212A3F41	2003-06-07 04:00:00+02	\N
76	0101000020430D000000000000387E2B410000000069263F41	2003-06-07 08:00:00+02	\N
77	0101000020430D000000000000387E2B410000000069263F41	2003-06-07 08:00:00+02	\N
78	0101000020430D000000000000247C2B41000000003A273F41	2003-06-07 12:00:00+02	\N
79	0101000020430D000000000000247C2B41000000003A273F41	2003-06-07 12:00:00+02	\N
80	0101000020430D000000000000F87C2B4100000000B6293F41	2003-06-07 16:00:00+02	\N
81	0101000020430D000000000000F87C2B4100000000B6293F41	2003-06-07 16:00:00+02	\N
82	0101000020430D000000000000E86D2B410000000075273F41	2003-06-07 20:00:00+02	\N
83	0101000020430D000000000000E86D2B410000000075273F41	2003-06-07 20:00:00+02	\N
84	0101000020430D000000000000DC782B41000000000E283F41	2003-06-08 00:00:00+02	\N
85	0101000020430D000000000000DC782B41000000000E283F41	2003-06-08 00:00:00+02	\N
86	0101000020430D0000000000009A7B2B4100000000E32A3F41	2003-06-08 04:00:00+02	\N
87	0101000020430D0000000000009A7B2B4100000000E32A3F41	2003-06-08 04:00:00+02	\N
88	0101000020430D000000000000747F2B41000000002E273F41	2003-06-08 08:00:00+02	\N
89	0101000020430D000000000000747F2B41000000002E273F41	2003-06-08 08:00:00+02	\N
90	0101000020430D000000000000F8802B4100000000D6283F41	2003-06-08 12:00:00+02	\N
91	0101000020430D000000000000F8802B4100000000D6283F41	2003-06-08 12:00:00+02	\N
92	0101000020430D0000000000007C7D2B41000000003D2B3F41	2003-06-08 16:00:00+02	\N
93	0101000020430D0000000000007C7D2B41000000003D2B3F41	2003-06-08 16:00:00+02	\N
94	0101000020430D00000000000056812B41000000009D273F41	2003-06-08 20:00:00+02	\N
95	0101000020430D00000000000056812B41000000009D273F41	2003-06-08 20:00:00+02	\N
96	0101000020430D00000000000024862B410000000070253F41	2003-06-09 00:00:00+02	\N
97	0101000020430D00000000000024862B410000000070253F41	2003-06-09 00:00:00+02	\N
98	0101000020430D00000000000014822B41000000001D293F41	2003-06-09 04:00:00+02	\N
99	0101000020430D00000000000014822B41000000001D293F41	2003-06-09 04:00:00+02	\N
100	0101000020430D000000000000387B2B410000000094233F41	2003-06-09 08:00:00+02	\N
101	0101000020430D000000000000387B2B410000000094233F41	2003-06-09 08:00:00+02	\N
102	0101000020430D000000000000367D2B4100000000DA263F41	2003-06-09 12:00:00+02	\N
103	0101000020430D000000000000367D2B4100000000DA263F41	2003-06-09 12:00:00+02	\N
104	0101000020430D000000000000E2792B410000000023233F41	2003-06-09 16:00:00+02	\N
105	0101000020430D000000000000E2792B410000000023233F41	2003-06-09 16:00:00+02	\N
106	0101000020430D000000000000DE802B4100000000D2223F41	2003-06-09 20:00:00+02	\N
107	0101000020430D000000000000DE802B4100000000D2223F41	2003-06-09 20:00:00+02	\N
108	\N	2003-06-10 00:00:00+02	\N
109	\N	2003-06-10 00:00:00+02	\N
110	\N	2003-06-10 04:00:00+02	\N
111	0101000020430D0000000000001C812B41000000000F1C3F41	2003-06-10 04:00:00+02	\N
112	0101000020430D0000000000002A732B410000000011263F41	2003-06-10 08:00:00+02	\N
113	0101000020430D0000000000002A732B410000000011263F41	2003-06-10 08:00:00+02	\N
114	0101000020430D00000000000046782B4100000000FF243F41	2003-06-10 12:00:00+02	\N
115	0101000020430D00000000000046782B4100000000FF243F41	2003-06-10 12:00:00+02	\N
116	0101000020430D000000000000127B2B41000000008D203F41	2003-06-10 16:00:00+02	\N
117	0101000020430D000000000000127B2B41000000008D203F41	2003-06-10 16:00:00+02	\N
118	0101000020430D000000000000BC7C2B410000000099263F41	2003-06-10 20:00:00+02	\N
119	0101000020430D000000000000BC7C2B410000000099263F41	2003-06-10 20:00:00+02	\N
120	0101000020430D00000000000016712B410000000037293F41	2003-06-11 00:00:00+02	\N
121	0101000020430D00000000000016712B410000000037293F41	2003-06-11 00:00:00+02	\N
122	0101000020430D0000000000003E842B4100000000222E3F41	2003-06-11 04:00:00+02	\N
123	0101000020430D0000000000003E842B4100000000222E3F41	2003-06-11 04:00:00+02	\N
124	0101000020430D000000000000527A2B41000000009B273F41	2003-06-11 08:00:00+02	\N
125	0101000020430D000000000000527A2B41000000009B273F41	2003-06-11 08:00:00+02	\N
126	\N	2003-06-11 12:00:00+02	\N
127	\N	2003-06-11 12:00:00+02	\N
128	\N	2003-06-11 16:00:00+02	\N
129	0101000020430D00000000000058782B410000000093273F41	2003-06-11 16:00:00+02	\N
130	0101000020430D0000000000003A782B4100000000A4273F41	2003-06-11 20:00:00+02	\N
131	0101000020430D0000000000003A782B4100000000A4273F41	2003-06-11 20:00:00+02	\N
132	0101000020430D0000000000003C782B41000000009E273F41	2003-06-12 00:00:00+02	\N
133	0101000020430D0000000000003C782B41000000009E273F41	2003-06-12 00:00:00+02	\N
134	0101000020430D000000000000187A2B41000000001E2A3F41	2003-06-12 04:00:00+02	\N
135	0101000020430D000000000000187A2B41000000001E2A3F41	2003-06-12 04:00:00+02	\N
136	0101000020430D0000000000000C732B410000000035273F41	2003-06-12 08:00:00+02	\N
137	0101000020430D0000000000000C732B410000000035273F41	2003-06-12 08:00:00+02	\N
138	0101000020430D0000000000004A832B410000000019233F41	2003-06-12 12:00:00+02	\N
139	0101000020430D0000000000004A832B410000000019233F41	2003-06-12 12:00:00+02	\N
140	\N	2003-06-12 16:00:00+02	\N
141	\N	2003-06-12 16:00:00+02	\N
142	\N	2003-06-12 20:00:00+02	\N
143	0101000020430D0000000000006A762B4100000000D5273F41	2003-06-12 20:00:00+02	\N
144	\N	2003-06-13 00:00:00+02	\N
145	\N	2003-06-13 00:00:00+02	\N
146	\N	2003-06-13 04:00:00+02	\N
147	0101000020430D000000000000987E2B4100000000F2273F41	2003-06-13 04:00:00+02	\N
148	0101000020430D000000000000A87C2B410000000066273F41	2003-06-13 08:00:00+02	\N
149	0101000020430D000000000000A87C2B410000000066273F41	2003-06-13 08:00:00+02	\N
150	0101000020430D0000000000002E7C2B4100000000102C3F41	2003-06-13 12:00:00+02	\N
151	0101000020430D0000000000002E7C2B4100000000102C3F41	2003-06-13 12:00:00+02	\N
152	\N	2003-06-13 16:00:00+02	\N
153	\N	2003-06-13 16:00:00+02	\N
154	\N	2003-06-13 20:00:00+02	\N
155	0101000020430D000000000000AA7B2B410000000004283F41	2003-06-13 20:00:00+02	\N
156	0101000020430D000000000000B47A2B410000000040273F41	2003-06-14 00:00:00+02	\N
157	0101000020430D000000000000B47A2B410000000040273F41	2003-06-14 00:00:00+02	\N
158	0101000020430D000000000000087B2B410000000075273F41	2003-06-14 04:00:00+02	\N
159	0101000020430D000000000000087B2B410000000075273F41	2003-06-14 04:00:00+02	\N
160	0101000020430D000000000000D8782B410000000084273F41	2003-06-14 08:00:00+02	\N
161	0101000020430D000000000000D8782B410000000084273F41	2003-06-14 08:00:00+02	\N
162	0101000020430D00000000000070762B4100000000CF273F41	2003-06-14 12:00:00+02	\N
163	0101000020430D00000000000070762B4100000000CF273F41	2003-06-14 12:00:00+02	\N
164	0101000020430D0000000000009E742B4100000000EF273F41	2003-06-14 16:00:00+02	\N
165	0101000020430D0000000000009E742B4100000000EF273F41	2003-06-14 16:00:00+02	\N
166	0101000020430D000000000000767A2B410000000081283F41	2003-06-14 20:00:00+02	\N
167	0101000020430D000000000000767A2B410000000081283F41	2003-06-14 20:00:00+02	\N
168	\N	\N	\N
169	0101000020430D00000000000058662B41000000004A023F41	2003-06-01 08:00:00+02	\N
170	0101000020430D0000000000008A622B41000000009B013F41	2003-06-01 12:00:00+02	\N
171	0101000020430D0000000000008A622B41000000009B013F41	2003-06-01 12:00:00+02	\N
172	0101000020430D000000000000A0592B41000000009AFD3E41	2003-06-01 16:00:00+02	\N
173	0101000020430D000000000000A0592B41000000009AFD3E41	2003-06-01 16:00:00+02	\N
174	0101000020430D0000000000004A5D2B41000000001EFF3E41	2003-06-01 20:00:00+02	\N
175	0101000020430D0000000000004A5D2B41000000001EFF3E41	2003-06-01 20:00:00+02	\N
176	0101000020430D000000000000D04B2B410000000080003F41	2003-06-02 00:00:00+02	\N
177	0101000020430D000000000000D04B2B410000000080003F41	2003-06-02 00:00:00+02	\N
178	0101000020430D00000000000000552B410000000041023F41	2003-06-02 04:00:00+02	\N
179	0101000020430D00000000000000552B410000000041023F41	2003-06-02 04:00:00+02	\N
180	0101000020430D000000000000B85E2B410000000019FD3E41	2003-06-02 08:00:00+02	\N
181	0101000020430D000000000000B85E2B410000000019FD3E41	2003-06-02 08:00:00+02	\N
182	\N	2003-06-02 12:00:00+02	\N
183	\N	2003-06-02 12:00:00+02	\N
184	\N	2003-06-02 16:00:00+02	\N
185	0101000020430D000000000000C6552B41000000002C033F41	2003-06-02 16:00:00+02	\N
186	0101000020430D000000000000FE5D2B410000000061FC3E41	2003-06-02 20:00:00+02	\N
187	0101000020430D000000000000FE5D2B410000000061FC3E41	2003-06-02 20:00:00+02	\N
188	\N	2003-06-03 00:00:00+02	\N
189	\N	2003-06-03 00:00:00+02	\N
190	\N	2003-06-03 04:00:00+02	\N
191	\N	2003-06-03 04:00:00+02	\N
192	\N	2003-06-03 08:00:00+02	\N
193	0101000020430D000000000000465D2B41000000005DFD3E41	2003-06-03 08:00:00+02	\N
194	\N	2003-06-03 12:00:00+02	\N
195	\N	2003-06-03 12:00:00+02	\N
196	\N	2003-06-03 16:00:00+02	\N
197	0101000020430D00000000000028562B4100000000B4023F41	2003-06-03 16:00:00+02	\N
198	0101000020430D000000000000B45D2B41000000007CFD3E41	2003-06-03 20:00:00+02	\N
199	0101000020430D000000000000B45D2B41000000007CFD3E41	2003-06-03 20:00:00+02	\N
200	0101000020430D0000000000006A5D2B410000000049FD3E41	2003-06-04 00:00:00+02	\N
201	0101000020430D0000000000006A5D2B410000000049FD3E41	2003-06-04 00:00:00+02	\N
202	0101000020430D000000000000585D2B410000000042FD3E41	2003-06-04 04:00:00+02	\N
203	0101000020430D000000000000585D2B410000000042FD3E41	2003-06-04 04:00:00+02	\N
204	0101000020430D000000000000B45D2B4100000000A7FF3E41	2003-06-04 08:00:00+02	\N
205	0101000020430D000000000000B45D2B4100000000A7FF3E41	2003-06-04 08:00:00+02	\N
206	0101000020430D00000000000036612B41000000008F003F41	2003-06-04 12:00:00+02	\N
207	0101000020430D00000000000036612B41000000008F003F41	2003-06-04 12:00:00+02	\N
208	0101000020430D000000000000EC612B410000000031003F41	2003-06-04 16:00:00+02	\N
209	0101000020430D000000000000EC612B410000000031003F41	2003-06-04 16:00:00+02	\N
210	0101000020430D000000000000B8602B410000000025FF3E41	2003-06-04 20:00:00+02	\N
211	0101000020430D000000000000B8602B410000000025FF3E41	2003-06-04 20:00:00+02	\N
212	0101000020430D000000000000605F2B410000000033FF3E41	2003-06-05 00:00:00+02	\N
213	0101000020430D000000000000605F2B410000000033FF3E41	2003-06-05 00:00:00+02	\N
214	0101000020430D0000000000004C592B4100000000DA033F41	2003-06-05 04:00:00+02	\N
215	0101000020430D0000000000004C592B4100000000DA033F41	2003-06-05 04:00:00+02	\N
216	0101000020430D0000000000006A5B2B4100000000E3FD3E41	2003-06-05 08:00:00+02	\N
217	0101000020430D0000000000006A5B2B4100000000E3FD3E41	2003-06-05 08:00:00+02	\N
218	\N	2003-06-05 12:00:00+02	\N
219	\N	2003-06-05 12:00:00+02	\N
220	\N	2003-06-05 16:00:00+02	\N
221	0101000020430D000000000000A84C2B4100000000C9053F41	2003-06-05 16:00:00+02	\N
222	0101000020430D00000000000098532B4100000000F8FE3E41	2003-06-05 20:00:00+02	\N
223	0101000020430D00000000000098532B4100000000F8FE3E41	2003-06-05 20:00:00+02	\N
224	\N	2003-06-06 00:00:00+02	\N
225	\N	2003-06-06 00:00:00+02	\N
226	\N	2003-06-06 04:00:00+02	\N
227	\N	2003-06-06 04:00:00+02	\N
228	\N	2003-06-06 08:00:00+02	\N
229	0101000020430D000000000000D2532B4100000000E2FF3E41	2003-06-06 08:00:00+02	\N
230	0101000020430D000000000000C6542B410000000001003F41	2003-06-06 12:00:00+02	\N
231	0101000020430D000000000000C6542B410000000001003F41	2003-06-06 12:00:00+02	\N
232	\N	2003-06-06 16:00:00+02	\N
233	\N	2003-06-06 16:00:00+02	\N
234	\N	2003-06-06 20:00:00+02	\N
235	\N	2003-06-06 20:00:00+02	\N
236	\N	2003-06-07 00:00:00+02	\N
237	0101000020430D0000000000005E5C2B41000000001FFC3E41	2003-06-07 00:00:00+02	\N
238	0101000020430D0000000000004E5C2B410000000003FC3E41	2003-06-07 04:00:00+02	\N
239	0101000020430D0000000000004E5C2B410000000003FC3E41	2003-06-07 04:00:00+02	\N
240	0101000020430D000000000000105E2B41000000002BFD3E41	2003-06-07 08:00:00+02	\N
241	0101000020430D000000000000105E2B41000000002BFD3E41	2003-06-07 08:00:00+02	\N
242	\N	2003-06-07 12:00:00+02	\N
243	\N	2003-06-07 12:00:00+02	\N
244	\N	2003-06-07 16:00:00+02	\N
245	0101000020430D0000000000000A5D2B41000000007CFD3E41	2003-06-07 16:00:00+02	\N
246	\N	2003-06-07 20:00:00+02	\N
247	\N	2003-06-07 20:00:00+02	\N
248	\N	2003-06-08 00:00:00+02	\N
249	0101000020430D000000000000885D2B410000000040FD3E41	2003-06-08 00:00:00+02	\N
250	\N	2003-06-08 04:00:00+02	\N
251	\N	2003-06-08 04:00:00+02	\N
252	\N	2003-06-08 08:00:00+02	\N
253	0101000020430D0000000000008A592B4100000000ADFD3E41	2003-06-08 08:00:00+02	\N
254	0101000020430D0000000000000E502B41000000004FFF3E41	2003-06-08 12:00:00+02	\N
255	0101000020430D0000000000000E502B41000000004FFF3E41	2003-06-08 12:00:00+02	\N
256	\N	2003-06-08 16:00:00+02	\N
257	\N	2003-06-08 16:00:00+02	\N
258	\N	2003-06-08 20:00:00+02	\N
259	\N	2003-06-08 20:00:00+02	\N
260	\N	2003-06-09 00:00:00+02	\N
261	\N	2003-06-09 00:00:00+02	\N
262	\N	2003-06-09 04:00:00+02	\N
263	\N	2003-06-09 04:00:00+02	\N
264	\N	2003-06-09 08:00:00+02	\N
265	0101000020430D0000000000005A592B41000000007BFD3E41	2003-06-09 08:00:00+02	\N
266	\N	2003-06-09 12:00:00+02	\N
267	\N	2003-06-09 12:00:00+02	\N
268	\N	2003-06-09 16:00:00+02	\N
269	0101000020430D0000000000008C632B410000000097043F41	2003-06-09 16:00:00+02	\N
270	\N	2003-06-09 20:00:00+02	\N
271	\N	2003-06-09 20:00:00+02	\N
272	\N	2003-06-10 00:00:00+02	\N
273	0101000020430D0000000000002E522B410000000067FD3E41	2003-06-10 00:00:00+02	\N
274	0101000020430D0000000000006C692B4100000000D3053F41	2003-06-10 04:00:00+02	\N
275	0101000020430D0000000000006C692B4100000000D3053F41	2003-06-10 04:00:00+02	\N
276	0101000020430D000000000000CA582B410000000078FC3E41	2003-06-10 08:00:00+02	\N
277	0101000020430D000000000000CA582B410000000078FC3E41	2003-06-10 08:00:00+02	\N
278	\N	2003-06-10 12:00:00+02	\N
279	\N	2003-06-10 12:00:00+02	\N
280	\N	2003-06-10 16:00:00+02	\N
281	0101000020430D00000000000016562B4100000000B2FE3E41	2003-06-10 16:00:00+02	\N
282	\N	2003-06-10 20:00:00+02	\N
283	\N	2003-06-10 20:00:00+02	\N
284	\N	2003-06-11 00:00:00+02	\N
285	0101000020430D0000000000009A622B4100000000ADFF3E41	2003-06-11 00:00:00+02	\N
286	0101000020430D0000000000005E5B2B4100000000CCFB3E41	2003-06-11 04:00:00+02	\N
287	0101000020430D0000000000005E5B2B4100000000CCFB3E41	2003-06-11 04:00:00+02	\N
288	0101000020430D0000000000008E522B4100000000B4FC3E41	2003-06-11 08:00:00+02	\N
289	0101000020430D0000000000008E522B4100000000B4FC3E41	2003-06-11 08:00:00+02	\N
290	0101000020430D00000000000040562B4100000000F5043F41	2003-06-11 12:00:00+02	\N
291	0101000020430D00000000000040562B4100000000F5043F41	2003-06-11 12:00:00+02	\N
292	0101000020430D000000000000A2552B4100000000E4FF3E41	2003-06-11 16:00:00+02	\N
293	0101000020430D000000000000A2552B4100000000E4FF3E41	2003-06-11 16:00:00+02	\N
294	0101000020430D000000000000F0582B4100000000E4FE3E41	2003-06-11 20:00:00+02	\N
295	0101000020430D000000000000F0582B4100000000E4FE3E41	2003-06-11 20:00:00+02	\N
296	\N	2003-06-12 00:00:00+02	\N
297	\N	2003-06-12 00:00:00+02	\N
298	\N	2003-06-12 04:00:00+02	\N
299	0101000020430D000000000000AC5B2B410000000007FD3E41	2003-06-12 04:00:00+02	\N
300	0101000020430D00000000000058582B410000000043FE3E41	2003-06-12 08:00:00+02	\N
301	0101000020430D00000000000058582B410000000043FE3E41	2003-06-12 08:00:00+02	\N
302	0101000020430D000000000000D0532B41000000008D023F41	2003-06-12 12:00:00+02	\N
303	0101000020430D000000000000D0532B41000000008D023F41	2003-06-12 12:00:00+02	\N
304	0101000020430D000000000000B0532B410000000096023F41	2003-06-12 16:00:00+02	\N
305	0101000020430D000000000000B0532B410000000096023F41	2003-06-12 16:00:00+02	\N
306	0101000020430D00000000000030532B41000000000E023F41	2003-06-12 20:00:00+02	\N
307	0101000020430D00000000000030532B41000000000E023F41	2003-06-12 20:00:00+02	\N
308	0101000020430D00000000000060542B4100000000AA013F41	2003-06-13 00:00:00+02	\N
309	0101000020430D00000000000060542B4100000000AA013F41	2003-06-13 00:00:00+02	\N
310	0101000020430D000000000000FA522B410000000091023F41	2003-06-13 04:00:00+02	\N
311	0101000020430D000000000000FA522B410000000091023F41	2003-06-13 04:00:00+02	\N
312	0101000020430D00000000000050532B410000000030023F41	2003-06-13 08:00:00+02	\N
313	0101000020430D00000000000050532B410000000030023F41	2003-06-13 08:00:00+02	\N
314	0101000020430D000000000000F0532B4100000000B8083F41	2003-06-13 12:00:00+02	\N
315	0101000020430D000000000000F0532B4100000000B8083F41	2003-06-13 12:00:00+02	\N
316	0101000020430D000000000000764F2B410000000068043F41	2003-06-13 16:00:00+02	\N
317	0101000020430D000000000000764F2B410000000068043F41	2003-06-13 16:00:00+02	\N
318	0101000020430D000000000000EC662B4100000000D7043F41	2003-06-13 20:00:00+02	\N
319	0101000020430D000000000000EC662B4100000000D7043F41	2003-06-13 20:00:00+02	\N
320	0101000020430D00000000000022522B4100000000B0023F41	2003-06-14 00:00:00+02	\N
321	0101000020430D00000000000022522B4100000000B0023F41	2003-06-14 00:00:00+02	\N
322	\N	2003-06-14 04:00:00+02	\N
323	\N	2003-06-14 04:00:00+02	\N
324	\N	2003-06-14 08:00:00+02	\N
325	0101000020430D000000000000AA512B410000000031033F41	2003-06-14 08:00:00+02	\N
326	0101000020430D00000000000018542B410000000087023F41	2003-06-14 12:00:00+02	\N
327	0101000020430D00000000000018542B410000000087023F41	2003-06-14 12:00:00+02	\N
328	0101000020430D00000000000032542B410000000070023F41	2003-06-14 16:00:00+02	\N
329	0101000020430D00000000000032542B410000000070023F41	2003-06-14 16:00:00+02	\N
330	\N	\N	\N
331	0101000020430D00000000000014532B4100000000BC023F41	2003-06-01 00:00:00+02	\N
332	0101000020430D00000000000016542B410000000011023F41	2003-06-01 04:00:00+02	\N
333	0101000020430D00000000000016542B410000000011023F41	2003-06-01 04:00:00+02	\N
334	0101000020430D000000000000E0532B410000000065003F41	2003-06-01 08:00:00+02	\N
335	0101000020430D000000000000E0532B410000000065003F41	2003-06-01 08:00:00+02	\N
336	0101000020430D000000000000F0522B4100000000B8023F41	2003-06-01 12:00:00+02	\N
337	0101000020430D000000000000F0522B4100000000B8023F41	2003-06-01 12:00:00+02	\N
338	0101000020430D000000000000E44E2B41000000002B043F41	2003-06-01 16:00:00+02	\N
339	0101000020430D000000000000E44E2B41000000002B043F41	2003-06-01 16:00:00+02	\N
340	0101000020430D000000000000E44E2B410000000003053F41	2003-06-01 20:00:00+02	\N
341	0101000020430D000000000000E44E2B410000000003053F41	2003-06-01 20:00:00+02	\N
342	0101000020430D0000000000001C4F2B41000000002C043F41	2003-06-02 00:00:00+02	\N
343	0101000020430D0000000000001C4F2B41000000002C043F41	2003-06-02 00:00:00+02	\N
344	0101000020430D000000000000F44F2B410000000078043F41	2003-06-02 04:00:00+02	\N
345	0101000020430D000000000000F44F2B410000000078043F41	2003-06-02 04:00:00+02	\N
346	0101000020430D000000000000E04E2B4100000000C7043F41	2003-06-02 08:00:00+02	\N
347	0101000020430D000000000000E04E2B4100000000C7043F41	2003-06-02 08:00:00+02	\N
348	0101000020430D000000000000CC522B4100000000C4053F41	2003-06-02 12:00:00+02	\N
349	0101000020430D000000000000CC522B4100000000C4053F41	2003-06-02 12:00:00+02	\N
350	0101000020430D000000000000E2522B41000000001C073F41	2003-06-02 16:00:00+02	\N
351	0101000020430D000000000000E2522B41000000001C073F41	2003-06-02 16:00:00+02	\N
352	0101000020430D000000000000764F2B4100000000C7073F41	2003-06-02 20:00:00+02	\N
353	0101000020430D000000000000764F2B4100000000C7073F41	2003-06-02 20:00:00+02	\N
354	0101000020430D000000000000164F2B4100000000FE063F41	2003-06-03 00:00:00+02	\N
355	0101000020430D000000000000164F2B4100000000FE063F41	2003-06-03 00:00:00+02	\N
356	0101000020430D0000000000005A4F2B410000000075073F41	2003-06-03 04:00:00+02	\N
357	0101000020430D0000000000005A4F2B410000000075073F41	2003-06-03 04:00:00+02	\N
358	0101000020430D000000000000FE4F2B4100000000AE073F41	2003-06-03 08:00:00+02	\N
359	0101000020430D000000000000FE4F2B4100000000AE073F41	2003-06-03 08:00:00+02	\N
360	0101000020430D000000000000F4512B4100000000F5083F41	2003-06-03 12:00:00+02	\N
361	0101000020430D000000000000F4512B4100000000F5083F41	2003-06-03 12:00:00+02	\N
362	0101000020430D00000000000096522B410000000036093F41	2003-06-03 16:00:00+02	\N
363	0101000020430D00000000000096522B410000000036093F41	2003-06-03 16:00:00+02	\N
364	0101000020430D00000000000014522B410000000010093F41	2003-06-03 20:00:00+02	\N
365	0101000020430D00000000000014522B410000000010093F41	2003-06-03 20:00:00+02	\N
366	\N	2003-06-04 00:00:00+02	\N
367	\N	2003-06-04 00:00:00+02	\N
368	\N	2003-06-04 04:00:00+02	\N
369	0101000020430D0000000000003C542B4100000000A5093F41	2003-06-04 04:00:00+02	\N
370	0101000020430D000000000000D8542B4100000000EE093F41	2003-06-04 08:00:00+02	\N
371	0101000020430D000000000000D8542B4100000000EE093F41	2003-06-04 08:00:00+02	\N
372	0101000020430D000000000000B85A2B4100000000060C3F41	2003-06-04 12:00:00+02	\N
373	0101000020430D000000000000B85A2B4100000000060C3F41	2003-06-04 12:00:00+02	\N
374	0101000020430D000000000000965F2B4100000000E9143F41	2003-06-04 16:00:00+02	\N
375	0101000020430D000000000000965F2B4100000000E9143F41	2003-06-04 16:00:00+02	\N
376	0101000020430D000000000000CA5F2B4100000000C3143F41	2003-06-04 20:00:00+02	\N
377	0101000020430D000000000000CA5F2B4100000000C3143F41	2003-06-04 20:00:00+02	\N
378	\N	2003-06-05 00:00:00+02	\N
379	\N	2003-06-05 00:00:00+02	\N
380	\N	2003-06-05 04:00:00+02	\N
381	\N	2003-06-05 04:00:00+02	\N
382	\N	2003-06-05 08:00:00+02	\N
383	0101000020430D000000000000B2662B410000000097133F41	2003-06-05 08:00:00+02	\N
384	0101000020430D000000000000D0612B410000000094123F41	2003-06-05 12:00:00+02	\N
385	0101000020430D000000000000D0612B410000000094123F41	2003-06-05 12:00:00+02	\N
386	\N	2003-06-05 16:00:00+02	\N
387	\N	2003-06-05 16:00:00+02	\N
388	\N	2003-06-05 20:00:00+02	\N
389	\N	2003-06-05 20:00:00+02	\N
390	\N	2003-06-06 00:00:00+02	\N
391	0101000020430D0000000000007C602B410000000066143F41	2003-06-06 00:00:00+02	\N
392	0101000020430D00000000000080602B410000000067143F41	2003-06-06 04:00:00+02	\N
393	0101000020430D00000000000080602B410000000067143F41	2003-06-06 04:00:00+02	\N
394	\N	2003-06-06 08:00:00+02	\N
395	\N	2003-06-06 08:00:00+02	\N
396	\N	2003-06-06 12:00:00+02	\N
397	0101000020430D000000000000C8612B410000000035143F41	2003-06-06 12:00:00+02	\N
398	0101000020430D00000000000074622B410000000014143F41	2003-06-06 16:00:00+02	\N
399	0101000020430D00000000000074622B410000000014143F41	2003-06-06 16:00:00+02	\N
400	0101000020430D000000000000EE612B41000000006F143F41	2003-06-06 20:00:00+02	\N
401	0101000020430D000000000000EE612B41000000006F143F41	2003-06-06 20:00:00+02	\N
402	0101000020430D00000000000022602B410000000048143F41	2003-06-07 00:00:00+02	\N
403	0101000020430D00000000000022602B410000000048143F41	2003-06-07 00:00:00+02	\N
404	0101000020430D0000000000005A5F2B410000000056143F41	2003-06-07 04:00:00+02	\N
405	0101000020430D0000000000005A5F2B410000000056143F41	2003-06-07 04:00:00+02	\N
406	0101000020430D00000000000004612B4100000000DD143F41	2003-06-07 08:00:00+02	\N
407	0101000020430D00000000000004612B4100000000DD143F41	2003-06-07 08:00:00+02	\N
408	0101000020430D00000000000092612B4100000000F9133F41	2003-06-07 12:00:00+02	\N
409	0101000020430D00000000000092612B4100000000F9133F41	2003-06-07 12:00:00+02	\N
410	0101000020430D00000000000074612B410000000070133F41	2003-06-07 16:00:00+02	\N
411	0101000020430D00000000000074612B410000000070133F41	2003-06-07 16:00:00+02	\N
412	0101000020430D000000000000A05C2B4100000000D60E3F41	2003-06-07 20:00:00+02	\N
413	0101000020430D000000000000A05C2B4100000000D60E3F41	2003-06-07 20:00:00+02	\N
414	0101000020430D000000000000CC592B4100000000600E3F41	2003-06-08 00:00:00+02	\N
415	0101000020430D000000000000CC592B4100000000600E3F41	2003-06-08 00:00:00+02	\N
416	0101000020430D0000000000000C5A2B4100000000640E3F41	2003-06-08 04:00:00+02	\N
417	0101000020430D0000000000000C5A2B4100000000640E3F41	2003-06-08 04:00:00+02	\N
418	0101000020430D000000000000F8522B410000000068093F41	2003-06-08 08:00:00+02	\N
419	0101000020430D000000000000F8522B410000000068093F41	2003-06-08 08:00:00+02	\N
420	\N	2003-06-08 12:00:00+02	\N
421	\N	2003-06-08 12:00:00+02	\N
422	\N	2003-06-08 16:00:00+02	\N
423	0101000020430D0000000000008C4E2B410000000053043F41	2003-06-08 16:00:00+02	\N
424	0101000020430D000000000000A24E2B41000000009C043F41	2003-06-08 20:00:00+02	\N
425	0101000020430D000000000000A24E2B41000000009C043F41	2003-06-08 20:00:00+02	\N
426	0101000020430D000000000000484D2B410000000011043F41	2003-06-09 00:00:00+02	\N
427	0101000020430D000000000000484D2B410000000011043F41	2003-06-09 00:00:00+02	\N
428	0101000020430D000000000000224F2B410000000031043F41	2003-06-09 04:00:00+02	\N
429	0101000020430D000000000000224F2B410000000031043F41	2003-06-09 04:00:00+02	\N
430	0101000020430D0000000000008A4E2B410000000093043F41	2003-06-09 08:00:00+02	\N
431	0101000020430D0000000000008A4E2B410000000093043F41	2003-06-09 08:00:00+02	\N
432	\N	2003-06-09 12:00:00+02	\N
433	\N	2003-06-09 12:00:00+02	\N
434	\N	2003-06-09 16:00:00+02	\N
435	0101000020430D000000000000EA4D2B410000000073043F41	2003-06-09 16:00:00+02	\N
436	0101000020430D000000000000344E2B41000000000B053F41	2003-06-09 20:00:00+02	\N
437	0101000020430D000000000000344E2B41000000000B053F41	2003-06-09 20:00:00+02	\N
438	0101000020430D000000000000184E2B41000000009F043F41	2003-06-10 00:00:00+02	\N
439	0101000020430D000000000000184E2B41000000009F043F41	2003-06-10 00:00:00+02	\N
440	0101000020430D0000000000002C4E2B41000000007D043F41	2003-06-10 04:00:00+02	\N
441	0101000020430D0000000000002C4E2B41000000007D043F41	2003-06-10 04:00:00+02	\N
442	0101000020430D000000000000A04E2B410000000087043F41	2003-06-10 08:00:00+02	\N
443	0101000020430D000000000000A04E2B410000000087043F41	2003-06-10 08:00:00+02	\N
444	0101000020430D000000000000DC4E2B410000000070043F41	2003-06-10 12:00:00+02	\N
445	0101000020430D000000000000DC4E2B410000000070043F41	2003-06-10 12:00:00+02	\N
446	0101000020430D000000000000A04E2B41000000006F043F41	2003-06-10 16:00:00+02	\N
447	0101000020430D000000000000A04E2B41000000006F043F41	2003-06-10 16:00:00+02	\N
448	0101000020430D000000000000044E2B410000000074043F41	2003-06-10 20:00:00+02	\N
449	0101000020430D000000000000044E2B410000000074043F41	2003-06-10 20:00:00+02	\N
450	0101000020430D000000000000C84E2B410000000024043F41	2003-06-11 00:00:00+02	\N
451	0101000020430D000000000000C84E2B410000000024043F41	2003-06-11 00:00:00+02	\N
452	0101000020430D000000000000624E2B41000000003C043F41	2003-06-11 04:00:00+02	\N
453	0101000020430D000000000000624E2B41000000003C043F41	2003-06-11 04:00:00+02	\N
454	\N	2003-06-11 08:00:00+02	\N
455	\N	2003-06-11 08:00:00+02	\N
456	\N	2003-06-11 12:00:00+02	\N
457	0101000020430D000000000000FE532B410000000019023F41	2003-06-11 12:00:00+02	\N
458	\N	2003-06-11 16:00:00+02	\N
459	\N	2003-06-11 16:00:00+02	\N
460	\N	2003-06-11 20:00:00+02	\N
461	\N	2003-06-11 20:00:00+02	\N
462	\N	2003-06-12 00:00:00+02	\N
463	0101000020430D00000000000036522B4100000000E7023F41	2003-06-12 00:00:00+02	\N
464	\N	2003-06-12 04:00:00+02	\N
465	\N	2003-06-12 04:00:00+02	\N
466	\N	2003-06-12 08:00:00+02	\N
467	0101000020430D000000000000C2522B41000000000C033F41	2003-06-12 08:00:00+02	\N
468	0101000020430D00000000000010532B4100000000DB023F41	2003-06-12 12:00:00+02	\N
469	0101000020430D00000000000010532B4100000000DB023F41	2003-06-12 12:00:00+02	\N
470	0101000020430D0000000000007C522B410000000017033F41	2003-06-12 16:00:00+02	\N
471	0101000020430D0000000000007C522B410000000017033F41	2003-06-12 16:00:00+02	\N
472	\N	2003-06-12 20:00:00+02	\N
473	\N	2003-06-12 20:00:00+02	\N
474	\N	2003-06-13 00:00:00+02	\N
475	0101000020430D000000000000284F2B4100000000F8023F41	2003-06-13 00:00:00+02	\N
476	0101000020430D000000000000964F2B41000000004D033F41	2003-06-13 04:00:00+02	\N
477	0101000020430D000000000000964F2B41000000004D033F41	2003-06-13 04:00:00+02	\N
478	0101000020430D000000000000A2512B410000000019033F41	2003-06-13 08:00:00+02	\N
479	0101000020430D000000000000A2512B410000000019033F41	2003-06-13 08:00:00+02	\N
480	0101000020430D0000000000005E522B410000000004033F41	2003-06-13 12:00:00+02	\N
481	0101000020430D0000000000005E522B410000000004033F41	2003-06-13 12:00:00+02	\N
482	0101000020430D000000000000BC542B4100000000C4013F41	2003-06-13 16:00:00+02	\N
483	0101000020430D000000000000BC542B4100000000C4013F41	2003-06-13 16:00:00+02	\N
484	0101000020430D00000000000070542B41000000007BFE3E41	2003-06-13 20:00:00+02	\N
485	0101000020430D00000000000070542B41000000007BFE3E41	2003-06-13 20:00:00+02	\N
486	\N	2003-06-14 00:00:00+02	\N
487	\N	2003-06-14 00:00:00+02	\N
488	\N	2003-06-14 04:00:00+02	\N
489	0101000020430D0000000000008A562B410000000022FE3E41	2003-06-14 04:00:00+02	\N
490	0101000020430D0000000000009A562B41000000001CFE3E41	2003-06-14 08:00:00+02	\N
491	0101000020430D0000000000009A562B41000000001CFE3E41	2003-06-14 08:00:00+02	\N
492	\N	2003-06-14 12:00:00+02	\N
493	\N	2003-06-14 12:00:00+02	\N
494	\N	2003-06-14 16:00:00+02	\N
495	0101000020430D000000000000F2542B4100000000C6FE3E41	2003-06-14 16:00:00+02	\N
496	\N	\N	\N
497	0101000020430D000000000000C0402B410000000038FF3E41	2003-06-01 00:00:00+02	\N
498	0101000020430D000000000000A4402B41000000003FFF3E41	2003-06-01 04:00:00+02	\N
499	0101000020430D000000000000A4402B41000000003FFF3E41	2003-06-01 04:00:00+02	\N
500	0101000020430D000000000000CE3E2B4100000000EFFF3E41	2003-06-01 08:00:00+02	\N
501	0101000020430D000000000000CE3E2B4100000000EFFF3E41	2003-06-01 08:00:00+02	\N
502	0101000020430D000000000000163C2B4100000000E9023F41	2003-06-01 12:00:00+02	\N
503	0101000020430D000000000000163C2B4100000000E9023F41	2003-06-01 12:00:00+02	\N
504	0101000020430D000000000000963A2B4100000000A5FE3E41	2003-06-01 16:00:00+02	\N
505	0101000020430D000000000000963A2B4100000000A5FE3E41	2003-06-01 16:00:00+02	\N
506	0101000020430D000000000000103A2B410000000089FE3E41	2003-06-01 20:00:00+02	\N
507	0101000020430D000000000000103A2B410000000089FE3E41	2003-06-01 20:00:00+02	\N
508	0101000020430D000000000000AE3C2B410000000044FF3E41	2003-06-02 00:00:00+02	\N
509	0101000020430D000000000000AE3C2B410000000044FF3E41	2003-06-02 00:00:00+02	\N
510	0101000020430D0000000000008E3C2B4100000000CDFE3E41	2003-06-02 04:00:00+02	\N
511	0101000020430D0000000000008E3C2B4100000000CDFE3E41	2003-06-02 04:00:00+02	\N
512	0101000020430D000000000000CA372B410000000089003F41	2003-06-02 08:00:00+02	\N
513	0101000020430D000000000000CA372B410000000089003F41	2003-06-02 08:00:00+02	\N
514	\N	2003-06-02 12:00:00+02	\N
515	\N	2003-06-02 12:00:00+02	\N
516	\N	2003-06-02 16:00:00+02	\N
517	0101000020430D000000000000E8382B4100000000CC003F41	2003-06-02 16:00:00+02	\N
518	0101000020430D0000000000004E3C2B41000000000B033F41	2003-06-02 20:00:00+02	\N
519	0101000020430D0000000000004E3C2B41000000000B033F41	2003-06-02 20:00:00+02	\N
520	\N	2003-06-03 00:00:00+02	\N
521	\N	2003-06-03 00:00:00+02	\N
522	\N	2003-06-03 04:00:00+02	\N
523	0101000020430D00000000000058392B41000000005E023F41	2003-06-03 04:00:00+02	\N
524	0101000020430D000000000000A6352B41000000001F023F41	2003-06-03 08:00:00+02	\N
525	0101000020430D000000000000A6352B41000000001F023F41	2003-06-03 08:00:00+02	\N
526	\N	2003-06-03 12:00:00+02	\N
527	\N	2003-06-03 12:00:00+02	\N
528	\N	2003-06-03 16:00:00+02	\N
529	0101000020430D0000000000000E2B2B41000000003A033F41	2003-06-03 16:00:00+02	\N
530	0101000020430D000000000000782E2B410000000061043F41	2003-06-03 20:00:00+02	\N
531	0101000020430D000000000000782E2B410000000061043F41	2003-06-03 20:00:00+02	\N
532	\N	2003-06-04 00:00:00+02	\N
533	\N	2003-06-04 00:00:00+02	\N
534	\N	2003-06-04 04:00:00+02	\N
535	\N	2003-06-04 04:00:00+02	\N
536	\N	2003-06-04 08:00:00+02	\N
537	0101000020430D000000000000A82D2B41000000000E013F41	2003-06-04 08:00:00+02	\N
538	\N	2003-06-04 12:00:00+02	\N
539	\N	2003-06-04 12:00:00+02	\N
540	\N	2003-06-04 16:00:00+02	\N
541	0101000020430D0000000000006E2B2B41000000005A003F41	2003-06-04 16:00:00+02	\N
542	0101000020430D000000000000704B2B410000000011FD3E41	2003-06-04 20:00:00+02	\N
543	0101000020430D000000000000704B2B410000000011FD3E41	2003-06-04 20:00:00+02	\N
544	0101000020430D000000000000022C2B410000000005003F41	2003-06-05 00:00:00+02	\N
545	0101000020430D000000000000022C2B410000000005003F41	2003-06-05 00:00:00+02	\N
546	0101000020430D000000000000002C2B410000000008003F41	2003-06-05 04:00:00+02	\N
547	0101000020430D000000000000002C2B410000000008003F41	2003-06-05 04:00:00+02	\N
548	0101000020430D000000000000362A2B4100000000AAFF3E41	2003-06-05 08:00:00+02	\N
549	0101000020430D000000000000362A2B4100000000AAFF3E41	2003-06-05 08:00:00+02	\N
550	\N	2003-06-05 12:00:00+02	\N
551	\N	2003-06-05 12:00:00+02	\N
552	\N	2003-06-05 16:00:00+02	\N
553	\N	2003-06-05 16:00:00+02	\N
554	\N	2003-06-05 20:00:00+02	\N
555	0101000020430D000000000000262D2B41000000003B013F41	2003-06-05 20:00:00+02	\N
556	0101000020430D0000000000008A2B2B410000000081013F41	2003-06-06 00:00:00+02	\N
557	0101000020430D0000000000008A2B2B410000000081013F41	2003-06-06 00:00:00+02	\N
558	0101000020430D000000000000E42A2B4100000000DD013F41	2003-06-06 04:00:00+02	\N
559	0101000020430D000000000000E42A2B4100000000DD013F41	2003-06-06 04:00:00+02	\N
560	0101000020430D000000000000042D2B41000000009C013F41	2003-06-06 08:00:00+02	\N
561	0101000020430D000000000000042D2B41000000009C013F41	2003-06-06 08:00:00+02	\N
562	\N	2003-06-06 12:00:00+02	\N
563	\N	2003-06-06 12:00:00+02	\N
564	\N	2003-06-06 16:00:00+02	\N
565	0101000020430D000000000000BE2C2B4100000000D2013F41	2003-06-06 16:00:00+02	\N
566	\N	2003-06-06 20:00:00+02	\N
567	\N	2003-06-06 20:00:00+02	\N
568	\N	2003-06-07 00:00:00+02	\N
569	0101000020430D0000000000009E2C2B4100000000D0013F41	2003-06-07 00:00:00+02	\N
570	0101000020430D000000000000EE2C2B4100000000B3013F41	2003-06-07 04:00:00+02	\N
571	0101000020430D000000000000EE2C2B4100000000B3013F41	2003-06-07 04:00:00+02	\N
572	0101000020430D000000000000862D2B4100000000D0023F41	2003-06-07 08:00:00+02	\N
573	0101000020430D000000000000862D2B4100000000D0023F41	2003-06-07 08:00:00+02	\N
574	0101000020430D000000000000D4272B410000000006073F41	2003-06-07 12:00:00+02	\N
575	0101000020430D000000000000D4272B410000000006073F41	2003-06-07 12:00:00+02	\N
576	0101000020430D000000000000822C2B4100000000740B3F41	2003-06-07 16:00:00+02	\N
577	0101000020430D000000000000822C2B4100000000740B3F41	2003-06-07 16:00:00+02	\N
578	0101000020430D0000000000003E2A2B41000000003C0B3F41	2003-06-07 20:00:00+02	\N
579	0101000020430D0000000000003E2A2B41000000003C0B3F41	2003-06-07 20:00:00+02	\N
580	0101000020430D000000000000622A2B4100000000580B3F41	2003-06-08 00:00:00+02	\N
581	0101000020430D000000000000622A2B4100000000580B3F41	2003-06-08 00:00:00+02	\N
582	0101000020430D0000000000005A2A2B41000000004F0B3F41	2003-06-08 04:00:00+02	\N
583	0101000020430D0000000000005A2A2B41000000004F0B3F41	2003-06-08 04:00:00+02	\N
584	\N	2003-06-08 08:00:00+02	\N
585	\N	2003-06-08 08:00:00+02	\N
586	\N	2003-06-08 12:00:00+02	\N
587	0101000020430D000000000000662D2B41000000004A043F41	2003-06-08 12:00:00+02	\N
588	0101000020430D000000000000EC2C2B4100000000E7043F41	2003-06-08 16:00:00+02	\N
589	0101000020430D000000000000EC2C2B4100000000E7043F41	2003-06-08 16:00:00+02	\N
590	0101000020430D0000000000009E2C2B410000000004023F41	2003-06-08 20:00:00+02	\N
591	0101000020430D0000000000009E2C2B410000000004023F41	2003-06-08 20:00:00+02	\N
592	\N	2003-06-09 00:00:00+02	\N
593	\N	2003-06-09 00:00:00+02	\N
594	\N	2003-06-09 04:00:00+02	\N
595	\N	2003-06-09 04:00:00+02	\N
596	\N	2003-06-09 08:00:00+02	\N
597	0101000020430D000000000000702B2B41000000005D033F41	2003-06-09 08:00:00+02	\N
598	\N	2003-06-09 12:00:00+02	\N
599	\N	2003-06-09 12:00:00+02	\N
600	\N	2003-06-09 16:00:00+02	\N
601	\N	2003-06-09 16:00:00+02	\N
602	\N	2003-06-09 20:00:00+02	\N
603	0101000020430D000000000000642C2B4100000000AD013F41	2003-06-09 20:00:00+02	\N
604	\N	2003-06-10 00:00:00+02	\N
605	\N	2003-06-10 00:00:00+02	\N
606	\N	2003-06-10 04:00:00+02	\N
607	0101000020430D0000000000003A2D2B410000000083013F41	2003-06-10 04:00:00+02	\N
608	0101000020430D000000000000CC2D2B4100000000CF023F41	2003-06-10 08:00:00+02	\N
609	0101000020430D000000000000CC2D2B4100000000CF023F41	2003-06-10 08:00:00+02	\N
610	\N	2003-06-10 12:00:00+02	\N
611	\N	2003-06-10 12:00:00+02	\N
612	\N	2003-06-10 16:00:00+02	\N
613	0101000020430D0000000000000C2D2B410000000060013F41	2003-06-10 16:00:00+02	\N
614	\N	2003-06-10 20:00:00+02	\N
615	\N	2003-06-10 20:00:00+02	\N
616	\N	2003-06-11 00:00:00+02	\N
617	0101000020430D0000000000008C342B4100000000900B3F41	2003-06-11 00:00:00+02	\N
618	0101000020430D0000000000008A342B4100000000980B3F41	2003-06-11 04:00:00+02	\N
619	0101000020430D0000000000008A342B4100000000980B3F41	2003-06-11 04:00:00+02	\N
620	0101000020430D0000000000005A342B41000000004B0B3F41	2003-06-11 08:00:00+02	\N
621	0101000020430D0000000000005A342B41000000004B0B3F41	2003-06-11 08:00:00+02	\N
622	0101000020430D000000000000D2332B41000000006D0A3F41	2003-06-11 12:00:00+02	\N
623	0101000020430D000000000000D2332B41000000006D0A3F41	2003-06-11 12:00:00+02	\N
624	\N	2003-06-11 16:00:00+02	\N
625	\N	2003-06-11 16:00:00+02	\N
626	\N	2003-06-11 20:00:00+02	\N
627	\N	2003-06-11 20:00:00+02	\N
628	\N	2003-06-12 00:00:00+02	\N
629	0101000020430D000000000000762D2B4100000000B1053F41	2003-06-12 00:00:00+02	\N
630	0101000020430D000000000000222F2B4100000000B6053F41	2003-06-12 04:00:00+02	\N
631	0101000020430D000000000000222F2B4100000000B6053F41	2003-06-12 04:00:00+02	\N
632	0101000020430D000000000000522F2B4100000000B9053F41	2003-06-12 08:00:00+02	\N
633	0101000020430D000000000000522F2B4100000000B9053F41	2003-06-12 08:00:00+02	\N
634	0101000020430D000000000000862F2B4100000000E1053F41	2003-06-12 12:00:00+02	\N
635	0101000020430D000000000000862F2B4100000000E1053F41	2003-06-12 12:00:00+02	\N
636	0101000020430D000000000000C42E2B410000000000053F41	2003-06-12 16:00:00+02	\N
637	0101000020430D000000000000C42E2B410000000000053F41	2003-06-12 16:00:00+02	\N
638	\N	2003-06-12 20:00:00+02	\N
639	\N	2003-06-12 20:00:00+02	\N
640	\N	2003-06-13 00:00:00+02	\N
641	\N	2003-06-13 00:00:00+02	\N
642	\N	2003-06-13 04:00:00+02	\N
643	\N	2003-06-13 04:00:00+02	\N
644	\N	2003-06-13 08:00:00+02	\N
645	0101000020430D000000000000F62B2B410000000059063F41	2003-06-13 08:00:00+02	\N
646	0101000020430D00000000000008252B4100000000E8043F41	2003-06-13 12:00:00+02	\N
647	0101000020430D00000000000008252B4100000000E8043F41	2003-06-13 12:00:00+02	\N
648	\N	2003-06-13 16:00:00+02	\N
649	\N	2003-06-13 16:00:00+02	\N
650	\N	2003-06-13 20:00:00+02	\N
651	\N	2003-06-13 20:00:00+02	\N
652	\N	2003-06-14 00:00:00+02	\N
653	0101000020430D000000000000E8212B41000000004D063F41	2003-06-14 00:00:00+02	\N
654	0101000020430D00000000000038222B410000000042063F41	2003-06-14 04:00:00+02	\N
655	0101000020430D00000000000038222B410000000042063F41	2003-06-14 04:00:00+02	\N
656	0101000020430D0000000000008E232B410000000037053F41	2003-06-14 08:00:00+02	\N
657	0101000020430D0000000000008E232B410000000037053F41	2003-06-14 08:00:00+02	\N
658	\N	2003-06-14 12:00:00+02	\N
659	\N	2003-06-14 12:00:00+02	\N
660	\N	2003-06-14 16:00:00+02	\N
661	0101000020430D00000000000028242B410000000067043F41	2003-06-14 16:00:00+02	\N
662	0101000020430D000000000000D4212B4100000000B2033F41	2003-06-14 20:00:00+02	\N
663	0101000020430D000000000000D4212B4100000000B2033F41	2003-06-14 20:00:00+02	\N
664	\N	\N	\N
\.


--
-- TOC entry 3703 (class 0 OID 0)
-- Dependencies: 223
-- Name: relocation_id_seq; Type: SEQUENCE SET; Schema: ibex_traj_materialized_bursts; Owner: -
--

SELECT pg_catalog.setval('relocation_id_seq', 664, true);


--
-- TOC entry 3662 (class 0 OID 615795)
-- Dependencies: 227
-- Data for Name: s_b_rel; Type: TABLE DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

COPY s_b_rel (step_id, animal_burst_id) FROM stdin;
84	1
83	1
82	1
81	1
80	1
79	1
78	1
77	1
76	1
75	1
74	1
73	1
72	1
71	1
70	1
69	1
68	1
67	1
66	1
65	1
64	1
63	1
62	1
61	1
60	1
59	1
58	1
57	1
56	1
55	1
54	1
53	1
52	1
51	1
50	1
49	1
48	1
47	1
46	1
45	1
44	1
43	1
42	1
41	1
40	1
39	1
38	1
37	1
36	1
35	1
34	1
33	1
32	1
31	1
30	1
29	1
28	1
27	1
26	1
25	1
24	1
23	1
22	1
21	1
20	1
19	1
18	1
17	1
16	1
15	1
14	1
13	1
12	1
11	1
10	1
9	1
8	1
7	1
6	1
5	1
4	1
3	1
2	1
1	1
165	2
164	2
163	2
162	2
161	2
160	2
159	2
158	2
157	2
156	2
155	2
154	2
153	2
152	2
151	2
150	2
149	2
148	2
147	2
146	2
145	2
144	2
143	2
142	2
141	2
140	2
139	2
138	2
137	2
136	2
135	2
134	2
133	2
132	2
131	2
130	2
129	2
128	2
127	2
126	2
125	2
124	2
123	2
122	2
121	2
120	2
119	2
118	2
117	2
116	2
115	2
114	2
113	2
112	2
111	2
110	2
109	2
108	2
107	2
106	2
105	2
104	2
103	2
102	2
101	2
100	2
99	2
98	2
97	2
96	2
95	2
94	2
93	2
92	2
91	2
90	2
89	2
88	2
87	2
86	2
85	2
248	3
247	3
246	3
245	3
244	3
243	3
242	3
241	3
240	3
239	3
238	3
237	3
236	3
235	3
234	3
233	3
232	3
231	3
230	3
229	3
228	3
227	3
226	3
225	3
224	3
223	3
222	3
221	3
220	3
219	3
218	3
217	3
216	3
215	3
214	3
213	3
212	3
211	3
210	3
209	3
208	3
207	3
206	3
205	3
204	3
203	3
202	3
201	3
200	3
199	3
198	3
197	3
196	3
195	3
194	3
193	3
192	3
191	3
190	3
189	3
188	3
187	3
186	3
185	3
184	3
183	3
182	3
181	3
180	3
179	3
178	3
177	3
176	3
175	3
174	3
173	3
172	3
171	3
170	3
169	3
168	3
167	3
166	3
332	4
331	4
330	4
329	4
328	4
327	4
326	4
325	4
324	4
323	4
322	4
321	4
320	4
319	4
318	4
317	4
316	4
315	4
314	4
313	4
312	4
311	4
310	4
309	4
308	4
307	4
306	4
305	4
304	4
303	4
302	4
301	4
300	4
299	4
298	4
297	4
296	4
295	4
294	4
293	4
292	4
291	4
290	4
289	4
288	4
287	4
286	4
285	4
284	4
283	4
282	4
281	4
280	4
279	4
278	4
277	4
276	4
275	4
274	4
273	4
272	4
271	4
270	4
269	4
268	4
267	4
266	4
265	4
264	4
263	4
262	4
261	4
260	4
259	4
258	4
257	4
256	4
255	4
254	4
253	4
252	4
251	4
250	4
249	4
\.


--
-- TOC entry 3661 (class 0 OID 615776)
-- Dependencies: 226
-- Data for Name: step; Type: TABLE DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

COPY step (id, relocation_id_1, relocation_id_2, dt, r_rowname, r2n, rel_angle) FROM stdin;
1	1	2	04:00:00	1	0	\N
2	3	4	04:00:00	2	1685	\N
3	5	6	04:00:00	3	\N	\N
4	7	8	04:00:00	4	1225649	\N
5	9	10	04:00:00	5	\N	\N
6	11	12	04:00:00	6	1175380	\N
7	13	14	04:00:00	7	716456	-0.271032665149845975
8	15	16	04:00:00	8	707850	3.0420448445855901
9	17	18	04:00:00	9	7707508	-0.649388533799538981
10	19	20	04:00:00	10	22105508	0.0357540404154938971
11	21	22	04:00:00	11	31493309	\N
12	23	24	04:00:00	12	\N	\N
13	25	26	04:00:00	13	\N	\N
14	27	28	04:00:00	14	\N	\N
15	29	30	04:00:00	15	34046082	\N
16	31	32	04:00:00	16	40262557	0.349320679529383005
17	33	34	04:00:00	17	48411817	-1.09526347914859001
18	35	36	04:00:00	18	64601465	\N
19	37	38	04:00:00	19	\N	\N
20	39	40	04:00:00	20	\N	\N
21	41	42	04:00:00	21	69518160	\N
22	43	44	04:00:00	22	\N	\N
23	45	46	04:00:00	23	73715652	\N
24	47	48	04:00:00	24	62073850	2.69381691959618985
25	49	50	04:00:00	25	66127105	-2.55534624816429989
26	51	52	04:00:00	26	38097497	-3.11895374372645984
27	53	54	04:00:00	27	72914036	-0.163496241614267013
28	55	56	04:00:00	28	81193601	-1.46559371562624996
29	57	58	04:00:00	29	85244200	-0.632431156412847972
30	59	60	04:00:00	30	87619817	1.73772588298868991
31	61	62	04:00:00	31	123526720	-2.72017910981981004
32	63	64	04:00:00	32	83596313	2.92075001318446015
33	65	66	04:00:00	33	135212089	2.24817791095841013
34	67	68	04:00:00	34	132860745	2.64304214989748987
35	69	70	04:00:00	35	138624349	-1.3638886987096801
36	71	72	04:00:00	36	136645444	1.75038618303956994
37	73	74	04:00:00	37	140455498	-0.301424471545042982
38	75	76	04:00:00	38	183407993	3.04161744431740022
39	77	78	04:00:00	39	133989776	-1.00275872814990996
40	79	80	04:00:00	40	136704325	-1.06997576683040996
41	81	82	04:00:00	41	152060121	2.02673548114286017
42	83	84	04:00:00	42	128744480	2.95950184023373009
43	85	86	04:00:00	43	138756605	1.01121904298030008
44	87	88	04:00:00	44	158040557	-2.21159396261711994
45	89	90	04:00:00	45	139548573	2.23335918181411008
46	91	92	04:00:00	46	150733337	1.05655380586926007
47	93	94	04:00:00	47	161919316	3.00248519981726991
48	95	96	04:00:00	48	143966953	0.346511926347229993
49	97	98	04:00:00	49	137174165	2.81158672447668012
50	99	100	04:00:00	50	153560628	2.08203229712002003
51	101	102	04:00:00	51	115910825	-2.8822655969187001
52	103	104	04:00:00	52	135535354	3.01583856195016997
53	105	106	04:00:00	53	112497445	1.90158645459350994
54	107	108	04:00:00	54	117329650	\N
55	109	110	04:00:00	55	\N	\N
56	111	112	04:00:00	56	85816936	\N
57	113	114	04:00:00	57	123531865	-2.57606225645738007
58	115	116	04:00:00	58	121096973	-0.869267452233370985
59	117	118	04:00:00	59	100520641	2.70006933501819013
60	119	120	04:00:00	60	133665220	1.28521064912997995
61	121	122	04:00:00	61	140549533	-2.24491244356027009
62	123	124	04:00:00	62	187570994	-2.69503821946240008
63	125	126	04:00:00	63	137323381	\N
64	127	128	04:00:00	64	\N	\N
65	129	130	04:00:00	65	135575348	\N
66	131	132	04:00:00	66	135869474	2.58376197760293014
67	133	134	04:00:00	67	135740125	2.62041584273785988
68	135	136	04:00:00	68	152038697	2.61718495986468014
69	137	138	04:00:00	69	129897332	1.98278611729326992
70	139	140	04:00:00	70	121375673	\N
71	141	142	04:00:00	71	\N	\N
72	143	144	04:00:00	72	135658601	\N
73	145	146	04:00:00	73	\N	\N
74	147	148	04:00:00	74	143118593	\N
75	149	150	04:00:00	75	138149945	-2.03367160940750002
76	151	152	04:00:00	76	165926018	\N
77	153	154	04:00:00	77	\N	\N
78	155	156	04:00:00	78	140839250	\N
79	157	158	04:00:00	79	135599701	3.03190227027157988
80	159	160	04:00:00	80	137063840	2.18739809576208
81	161	162	04:00:00	81	135622345	-0.185337583577361992
82	163	164	04:00:00	82	135539108	0.102372650791117001
83	165	166	04:00:00	83	135047525	-2.81234387171936984
84	167	168	\N	84	142675065	\N
85	169	170	04:00:00	85	0	\N
86	171	172	04:00:00	86	267794	0.386920573891810005
87	173	174	04:00:00	87	4090384	3.10086067261739018
88	175	176	04:00:00	88	2002625	2.29348410814105996
89	177	178	04:00:00	89	11742580	-2.61992514289934997
90	179	180	04:00:00	90	4928481	-1.17975199333078007
91	181	182	04:00:00	91	2718817	\N
92	183	184	04:00:00	92	\N	\N
93	185	186	04:00:00	93	4549717	\N
94	187	188	04:00:00	94	3431930	\N
95	189	190	04:00:00	95	\N	\N
96	191	192	04:00:00	96	\N	\N
97	193	194	04:00:00	97	2938042	\N
98	195	196	04:00:00	98	\N	\N
99	197	198	04:00:00	99	4304420	\N
100	199	200	04:00:00	100	2736136	-1.25366082450681993
101	201	202	04:00:00	101	2947410	-0.282123732142716022
102	203	204	04:00:00	102	2986048	-2.30673989814585001
103	205	206	04:00:00	103	1678861	-1.01897475860965003
104	207	208	04:00:00	104	627898	-1.27853412408682998
105	209	210	04:00:00	105	608725	-1.29073718264196002
106	211	212	04:00:00	106	1166425	-1.13045881899671996
107	213	214	04:00:00	107	1421345	-0.91093569302090005
108	215	216	04:00:00	108	2948900	2.73859168887203985
109	217	218	04:00:00	109	3227330	\N
110	219	220	04:00:00	110	\N	\N
111	221	222	04:00:00	111	11611969	\N
112	223	224	04:00:00	112	6482500	\N
113	225	226	04:00:00	113	\N	\N
114	227	228	04:00:00	114	\N	\N
115	229	230	04:00:00	115	6001097	\N
116	231	232	04:00:00	116	5400226	\N
117	233	234	04:00:00	117	\N	\N
118	235	236	04:00:00	118	\N	\N
119	237	238	04:00:00	119	4123970	\N
120	239	240	04:00:00	120	4233674	2.76993621007824009
121	241	242	04:00:00	121	2842321	\N
122	243	244	04:00:00	122	\N	\N
123	245	246	04:00:00	123	2931381	\N
124	247	248	04:00:00	124	\N	\N
125	249	250	04:00:00	125	2936484	\N
126	251	252	04:00:00	126	\N	\N
127	253	254	04:00:00	127	4081082	\N
128	255	256	04:00:00	128	8721778	\N
129	257	258	04:00:00	129	\N	\N
130	259	260	04:00:00	130	\N	\N
131	261	262	04:00:00	131	\N	\N
132	263	264	04:00:00	132	\N	\N
133	265	266	04:00:00	133	4280930	\N
134	267	268	04:00:00	134	\N	\N
135	269	270	04:00:00	135	475085	\N
136	271	272	04:00:00	136	\N	\N
137	273	274	04:00:00	137	8226562	\N
138	275	276	04:00:00	138	974261	-2.92457996324875991
139	277	278	04:00:00	139	5230325	\N
140	279	280	04:00:00	140	\N	\N
141	281	282	04:00:00	141	5176961	\N
142	283	284	04:00:00	142	\N	\N
143	285	286	04:00:00	143	677002	\N
144	287	288	04:00:00	144	4736269	-1.02314310206914993
145	289	290	04:00:00	145	8460989	-1.58817304705125006
146	291	292	04:00:00	146	4710089	-2.9822054700426599
147	293	294	04:00:00	147	4952317	1.08739600893589006
148	295	296	04:00:00	148	3701556	\N
149	297	298	04:00:00	149	\N	\N
150	299	300	04:00:00	150	3680365	\N
151	301	302	04:00:00	151	4274225	-0.446596013196774999
152	303	304	04:00:00	152	5630873	0.572428676026779049
153	305	306	04:00:00	153	5708320	1.64334320428990011
154	307	308	04:00:00	154	6015904	1.42873379147075008
155	309	310	04:00:00	155	5315600	2.81194389544367995
156	311	312	04:00:00	156	6150482	2.89961759515316997
157	313	314	04:00:00	157	5934772	2.6765148338525302
158	315	316	04:00:00	158	8260052	2.71065413919109988
159	317	318	04:00:00	159	8872805	2.08649148582632993
160	319	320	04:00:00	160	431885	-2.97435935011522012
161	321	322	04:00:00	161	6702973	\N
162	323	324	04:00:00	162	\N	\N
163	325	326	04:00:00	163	7059970	\N
164	327	328	04:00:00	164	5460617	-0.556097594258322947
165	329	330	\N	165	5397773	\N
166	331	332	04:00:00	166	0	\N
167	333	334	04:00:00	167	45882	-0.709302850027502041
168	335	336	04:00:00	168	369205	-2.87958095814791015
169	337	338	04:00:00	169	340	0.75025863496851497
170	339	340	04:00:00	170	421985	-0.949269702298275009
171	341	342	04:00:00	171	627185	-3.01208896312046015
172	343	344	04:00:00	172	393488	2.05449998520008004
173	345	346	04:00:00	173	357136	2.00845915942571995
174	347	348	04:00:00	174	562973	-2.15483673024739986
175	349	350	04:00:00	175	603472	1.07200069674438003
176	351	352	04:00:00	176	1255025	1.23054945037908992
177	353	354	04:00:00	177	1881050	1.70859337948458001
178	355	356	04:00:00	178	1449221	3.09770867030848995
179	357	358	04:00:00	179	1689210	-0.685052069802136954
180	359	360	04:00:00	180	1758781	0.308691451996090993
181	361	362	04:00:00	181	2558385	-0.239891349495167994
182	363	364	04:00:00	182	2752933	2.99437842418087019
183	365	366	04:00:00	183	2640784	\N
184	367	368	04:00:00	184	\N	\N
185	369	370	04:00:00	185	3151265	\N
186	371	372	04:00:00	186	3444040	-0.133055237704273993
187	373	374	04:00:00	187	6611368	0.684260716627939969
188	375	376	04:00:00	188	24213610	-2.27424926699892005
189	377	378	04:00:00	189	23945354	\N
190	379	380	04:00:00	190	\N	\N
191	381	382	04:00:00	191	\N	\N
192	383	384	04:00:00	192	24924346	\N
193	385	386	04:00:00	193	20008132	\N
194	387	388	04:00:00	194	\N	\N
195	389	390	04:00:00	195	\N	\N
196	391	392	04:00:00	196	23393140	\N
197	393	394	04:00:00	197	23409053	\N
198	395	396	04:00:00	198	\N	\N
199	397	398	04:00:00	199	23549653	\N
200	399	400	04:00:00	200	23586624	2.57184251982116008
201	401	402	04:00:00	201	24143762	1.10411210100594004
202	403	404	04:00:00	202	22970305	-0.307063497970144983
203	405	406	04:00:00	203	22772077	-2.43759231007694011
204	407	408	04:00:00	204	24721537	-1.83381511068020009
205	409	410	04:00:00	205	22915594	-0.410940276588715014
206	411	412	04:00:00	206	21669776	-0.374092832333889014
207	413	414	04:00:00	207	11090888	-0.772542702111817969
208	415	416	04:00:00	208	9620000	2.95084151423059993
209	417	418	04:00:00	209	9699920	-2.31257805445916986
210	419	420	04:00:00	210	2917460	\N
211	421	422	04:00:00	211	\N	\N
212	423	424	04:00:00	212	502049	\N
213	425	426	04:00:00	213	554161	2.39720819505886018
214	427	428	04:00:00	214	666845	2.59894997252871018
215	429	430	04:00:00	215	394154	2.09621562210264001
216	431	432	04:00:00	216	559402	\N
217	433	434	04:00:00	217	\N	\N
218	435	436	04:00:00	218	629642	\N
219	437	438	04:00:00	219	738657	-3.03172623303407018
220	439	440	04:00:00	220	640333	0.414962213401310009
221	441	442	04:00:00	221	595985	1.45548009655286004
222	443	444	04:00:00	222	535581	-0.824817935889643028
223	445	446	04:00:00	223	481696	-2.45418893329719001
224	447	448	04:00:00	224	514125	-0.097335973712590701
225	449	450	04:00:00	225	613504	2.5209904671113601
226	451	452	04:00:00	226	432100	-2.89681807209275011
227	453	454	04:00:00	227	508657	\N
228	455	456	04:00:00	228	\N	\N
229	457	458	04:00:00	229	40258	\N
230	459	460	04:00:00	230	\N	\N
231	461	462	04:00:00	231	\N	\N
232	463	464	04:00:00	232	14170	\N
233	465	466	04:00:00	233	\N	\N
234	467	468	04:00:00	234	8081	\N
235	469	470	04:00:00	235	965	-2.92434173388970997
236	471	472	04:00:00	236	14057	\N
237	473	474	04:00:00	237	\N	\N
238	475	476	04:00:00	238	255604	\N
239	477	478	04:00:00	239	220834	-1.19241862874431992
240	479	480	04:00:00	240	42874	-0.0238679393999076984
241	481	482	04:00:00	241	13465	-0.592883641627035995
242	483	484	04:00:00	242	106448	-0.803271205909051988
243	485	486	04:00:00	243	1216197	\N
244	487	488	04:00:00	244	\N	\N
245	489	490	04:00:00	245	1583933	\N
246	491	492	04:00:00	246	1605257	\N
247	493	494	04:00:00	247	\N	\N
248	495	496	\N	248	1085317	\N
249	497	498	04:00:00	249	0	\N
250	499	500	04:00:00	250	245	-0.17917230098776199
251	501	502	04:00:00	251	95490	-0.499570620871131021
252	503	504	04:00:00	252	1249434	2.53914161781186021
253	505	506	04:00:00	253	644130	-1.00090064561474001
254	507	508	04:00:00	254	763361	-3.0283192768483902
255	509	510	04:00:00	255	271585	-2.21357239219091007
256	511	512	04:00:00	256	299818	-2.06633015343917004
257	513	514	04:00:00	257	1429178	\N
258	515	516	04:00:00	258	\N	\N
259	517	518	04:00:00	259	1171232	\N
260	519	520	04:00:00	260	1282202	\N
261	521	522	04:00:00	261	\N	\N
262	523	524	04:00:00	262	1548340	\N
263	525	526	04:00:00	263	2571290	\N
264	527	528	04:00:00	264	\N	\N
265	529	530	04:00:00	265	8764405	\N
266	531	532	04:00:00	266	7220641	\N
267	533	534	04:00:00	267	\N	\N
268	535	536	04:00:00	268	\N	\N
269	537	538	04:00:00	269	6194036	\N
270	539	540	04:00:00	270	\N	\N
271	541	542	04:00:00	271	7531541	\N
272	543	544	04:00:00	272	2175025	-3.12488603255913011
273	545	546	04:00:00	273	7091050	-1.06329263603900004
274	547	548	04:00:00	274	7097600	1.63855415690273998
275	549	550	04:00:00	275	8336221	\N
276	551	552	04:00:00	276	\N	\N
277	553	554	04:00:00	277	\N	\N
278	555	556	04:00:00	278	6560306	\N
279	557	558	04:00:00	279	7713450	-0.509217023157570003
280	559	560	04:00:00	280	8287133	-2.53938259467330019
281	561	562	04:00:00	281	6755220	\N
282	563	564	04:00:00	282	\N	\N
283	565	566	04:00:00	283	7002277	\N
284	567	568	04:00:00	284	\N	\N
285	569	570	04:00:00	285	7081825	\N
286	571	572	04:00:00	286	6839594	1.93750212732331994
287	573	574	04:00:00	287	6902921	0.855211889782927948
288	575	576	04:00:00	288	14168104	-1.08057638587930005
289	577	578	04:00:00	289	16522705	2.24751876583387
290	579	580	04:00:00	290	17761937	-2.33288935782378992
291	581	582	04:00:00	291	17831585	-2.98847950333539991
292	583	584	04:00:00	292	17798714	\N
293	585	586	04:00:00	293	\N	\N
294	587	588	04:00:00	294	7820333	\N
295	589	590	04:00:00	295	8558469	2.71828366624886986
296	591	592	04:00:00	296	7153585	\N
297	593	594	04:00:00	297	\N	\N
298	595	596	04:00:00	298	\N	\N
299	597	598	04:00:00	299	8567705	\N
300	599	600	04:00:00	300	\N	\N
301	601	602	04:00:00	301	\N	\N
302	603	604	04:00:00	302	7186877	\N
303	605	606	04:00:00	303	\N	\N
304	607	608	04:00:00	304	6589570	\N
305	609	610	04:00:00	305	6730037	\N
306	611	612	04:00:00	306	\N	\N
307	613	614	04:00:00	307	6665188	\N
308	615	616	04:00:00	308	\N	\N
309	617	618	04:00:00	309	12425444	\N
310	619	620	04:00:00	310	12479193	2.71509243550358992
311	621	622	04:00:00	311	12072850	0.00491291572174624037
312	623	624	04:00:00	312	10970186	\N
313	625	626	04:00:00	313	\N	\N
314	627	628	04:00:00	314	\N	\N
315	629	630	04:00:00	315	8841610	\N
316	631	632	04:00:00	316	7847269	0.100994758724887002
317	633	634	04:00:00	317	7749586	0.870066111656951025
318	635	636	04:00:00	318	7769050	-2.97225283872269985
319	637	638	04:00:00	319	7489604	\N
320	639	640	04:00:00	320	\N	\N
321	641	642	04:00:00	321	\N	\N
322	643	644	04:00:00	322	\N	\N
323	645	646	04:00:00	323	10411546	\N
324	647	648	04:00:00	324	14708240	\N
325	649	650	04:00:00	325	\N	\N
326	651	652	04:00:00	326	\N	\N
327	653	654	04:00:00	327	18873673	\N
328	655	656	04:00:00	328	18519668	-0.732798148898583968
329	657	658	04:00:00	329	16321394	\N
330	659	660	04:00:00	330	\N	\N
331	661	662	04:00:00	331	15156529	\N
332	663	664	\N	332	16979080	\N
\.


--
-- TOC entry 3704 (class 0 OID 0)
-- Dependencies: 225
-- Name: step_id_seq; Type: SEQUENCE SET; Schema: ibex_traj_materialized_bursts; Owner: -
--

SELECT pg_catalog.setval('step_id_seq', 332, true);


SET search_path = public, pg_catalog;

--
-- TOC entry 3653 (class 0 OID 598920)
-- Dependencies: 214
-- Data for Name: infoloc_test; Type: TABLE DATA; Schema: public; Owner: -
--

COPY infoloc_test (gid, dummy, info_day) FROM stdin;
12782	999	2006-08-19
12783	999	2006-08-19
12784	999	2006-08-19
12785	999	2006-08-19
12786	999	2006-08-19
12787	999	2006-08-20
12788	999	2006-08-20
12789	999	2006-08-20
12790	999	2006-08-21
12791	999	2006-08-21
12792	999	2006-08-21
12793	999	2006-08-21
12794	999	2006-08-21
12795	999	2006-08-21
12796	999	2006-08-21
12797	999	2006-08-21
12798	999	2006-08-21
12799	999	2006-08-21
12800	999	2006-08-21
12801	999	2006-08-21
12802	999	2006-08-21
12803	999	2006-08-21
12804	999	2006-08-22
12805	999	2006-08-22
12806	999	2006-08-22
12807	999	2006-08-22
12808	999	2006-08-22
12809	999	2006-08-22
12810	999	2006-08-22
12811	999	2006-08-22
12812	999	2006-08-22
12813	999	2006-08-22
12814	999	2006-08-22
12815	999	2006-08-22
12816	999	2006-08-22
12817	999	2006-08-23
12818	999	2006-08-23
12819	999	2006-08-23
12820	999	2006-08-23
12821	999	2006-08-23
12822	999	2006-08-23
12823	999	2006-08-23
12824	999	2006-08-23
12825	999	2006-08-23
12826	999	2006-08-23
12827	999	2006-08-23
12828	999	2006-08-23
12829	999	2006-08-23
12830	999	2006-08-24
12831	999	2006-08-24
12832	999	2006-08-24
12833	999	2006-08-24
12834	999	2006-08-24
12835	999	2006-08-24
12836	999	2006-08-24
12837	999	2006-08-24
12838	999	2006-08-24
12839	999	2006-08-24
12840	999	2006-08-24
12841	999	2006-08-24
12842	999	2006-08-24
12843	999	2006-08-24
12844	999	2006-08-24
12845	999	2006-08-25
12846	999	2006-08-25
12847	999	2006-08-25
12848	999	2006-08-25
12849	999	2006-08-25
12850	999	2006-08-25
12851	999	2006-08-25
12852	999	2006-08-25
12853	999	2006-08-25
12854	999	2006-08-25
12855	999	2006-08-25
12856	999	2006-08-25
12857	999	2006-08-25
12858	999	2006-08-25
12859	999	2006-08-25
12860	999	2006-08-25
12861	999	2006-08-26
12862	999	2006-08-26
12863	999	2006-08-26
12864	999	2006-08-26
12865	999	2006-08-26
12866	999	2006-08-26
12867	999	2006-08-26
12868	999	2006-08-26
12869	999	2006-08-26
12870	999	2006-08-26
12871	999	2006-08-26
12872	999	2006-08-26
12873	999	2006-08-26
12874	999	2006-08-26
12875	999	2006-08-26
12876	999	2006-08-26
12877	999	2006-08-27
12878	999	2006-08-27
12879	999	2006-08-27
12880	999	2006-08-27
12881	999	2006-08-27
12882	999	2006-08-27
12883	999	2006-08-27
12884	999	2006-08-27
12885	999	2006-08-27
12886	999	2006-08-27
12887	999	2006-08-27
12888	999	2006-08-27
12889	999	2006-08-27
12890	999	2006-08-27
12891	999	2006-08-27
12892	999	2006-08-27
12893	999	2006-08-28
12894	999	2006-08-28
12895	999	2006-08-28
12896	999	2006-08-28
12897	999	2006-08-28
12898	999	2006-08-28
12899	999	2006-08-28
12900	999	2006-08-28
12901	999	2006-08-28
12902	999	2006-08-28
12903	999	2006-08-28
12904	999	2006-08-28
12905	999	2006-08-28
12906	999	2006-08-28
12907	999	2006-08-28
12908	999	2006-08-28
12909	999	2006-08-29
12910	999	2006-08-29
12911	999	2006-08-29
12912	999	2006-08-29
12913	999	2006-08-29
12914	999	2006-08-29
12915	999	2006-08-29
12916	999	2006-08-29
12917	999	2006-08-29
12918	999	2006-08-29
12919	999	2006-08-29
12920	999	2006-08-29
12921	999	2006-08-29
12922	999	2006-08-30
12923	999	2006-08-30
12924	999	2006-08-30
12925	999	2006-08-30
12926	999	2006-08-30
12927	999	2006-08-30
12928	999	2006-08-30
12929	999	2006-08-30
12930	999	2006-08-30
12931	999	2006-08-30
12932	999	2006-08-30
12933	999	2006-08-30
12934	999	2006-08-30
12935	999	2006-08-30
12936	999	2006-08-30
12937	999	2006-08-30
12938	999	2006-08-31
12939	999	2006-08-31
12940	999	2006-08-31
12941	999	2006-08-31
12942	999	2006-08-31
12943	999	2006-08-31
12944	999	2006-08-31
12945	999	2006-08-31
12946	999	2006-08-31
12947	999	2006-08-31
12948	999	2006-08-31
12949	999	2006-08-31
12950	999	2006-08-31
12951	999	2006-08-31
12952	999	2006-08-31
12953	999	2006-08-31
12954	999	2006-09-01
12955	999	2006-09-01
12956	999	2006-09-01
12957	999	2006-09-01
12958	999	2006-09-01
12959	999	2006-09-01
12960	999	2006-09-01
12961	999	2006-09-01
12962	999	2006-09-01
12963	999	2006-09-01
12964	999	2006-09-01
12965	999	2006-09-01
12966	999	2006-09-01
12967	999	2006-09-01
12968	999	2006-09-01
12969	999	2006-09-02
12970	999	2006-09-02
12971	999	2006-09-02
12972	999	2006-09-02
12973	999	2006-09-02
12974	999	2006-09-02
12975	999	2006-09-02
12976	999	2006-09-02
12977	999	2006-09-02
12978	999	2006-09-02
12979	999	2006-09-02
12980	999	2006-09-02
12981	999	2006-09-02
12982	999	2006-09-03
12983	999	2006-09-03
12984	999	2006-09-03
12985	999	2006-09-03
12986	999	2006-09-03
12987	999	2006-09-03
12988	999	2006-09-03
12989	999	2006-09-03
12990	999	2006-09-03
12991	999	2006-09-03
12992	999	2006-09-03
12993	999	2006-09-03
12994	999	2006-09-03
12995	999	2006-09-03
12996	999	2006-09-03
12997	999	2006-09-03
12998	999	2006-09-04
12999	999	2006-09-04
13000	999	2006-09-04
13001	999	2006-09-04
13002	999	2006-09-04
13003	999	2006-09-04
13004	999	2006-09-04
13005	999	2006-09-04
13006	999	2006-09-04
13007	999	2006-09-04
13008	999	2006-09-05
13009	999	2006-09-05
13010	999	2006-09-05
13011	999	2006-09-05
13012	999	2006-09-05
13013	999	2006-09-05
13014	999	2006-09-05
13015	999	2006-09-05
13016	999	2006-09-05
13017	999	2006-09-05
13018	999	2006-09-05
13019	999	2006-09-05
13020	999	2006-09-05
13021	999	2006-09-05
13022	999	2006-09-05
13023	999	2006-09-05
13024	999	2006-09-06
13025	999	2006-09-06
13026	999	2006-09-06
13027	999	2006-09-06
13028	999	2006-09-06
13029	999	2006-09-06
13030	999	2006-09-06
13031	999	2006-09-06
13032	999	2006-09-06
13033	999	2006-09-06
13034	999	2006-09-06
13035	999	2006-09-06
13036	999	2006-09-06
13037	999	2006-09-06
13038	999	2006-09-06
13039	999	2006-09-06
13040	999	2006-09-07
13041	999	2006-09-07
13042	999	2006-09-07
13043	999	2006-09-07
13044	999	2006-09-07
13045	999	2006-09-07
13046	999	2006-09-07
13047	999	2006-09-07
13048	999	2006-09-07
13049	999	2006-09-07
13050	999	2006-09-07
13051	999	2006-09-07
13052	999	2006-09-07
13053	999	2006-09-07
13054	999	2006-09-07
13055	999	2006-09-07
13056	999	2006-09-08
13057	999	2006-09-08
13058	999	2006-09-08
13059	999	2006-09-08
13060	999	2006-09-08
13061	999	2006-09-08
13062	999	2006-09-08
13063	999	2006-09-08
13064	999	2006-09-08
13065	999	2006-09-08
13066	999	2006-09-08
13067	999	2006-09-08
13068	999	2006-09-08
13069	999	2006-09-08
13070	999	2006-09-08
13071	999	2006-09-08
13072	999	2006-09-09
13073	999	2006-09-09
13074	999	2006-09-09
13075	999	2006-09-09
13076	999	2006-09-09
13077	999	2006-09-09
13078	999	2006-09-09
13079	999	2006-09-09
13080	999	2006-09-09
13081	999	2006-09-09
13082	999	2006-09-09
13083	999	2006-09-09
13084	999	2006-09-09
13085	999	2006-09-09
13086	999	2006-09-09
13087	999	2006-09-09
13088	999	2006-09-10
13089	999	2006-09-10
13090	999	2006-09-10
13091	999	2006-09-10
13092	999	2006-09-10
13093	999	2006-09-10
13094	999	2006-09-10
13095	999	2006-09-10
13096	999	2006-09-10
13097	999	2006-09-10
13098	999	2006-09-10
13099	999	2006-09-10
13100	999	2006-09-10
13101	999	2006-09-10
13102	999	2006-09-10
13103	999	2006-09-10
13104	999	2006-09-11
13105	999	2006-09-11
13106	999	2006-09-11
13107	999	2006-09-11
13108	999	2006-09-11
13109	999	2006-09-11
13110	999	2006-09-11
13111	999	2006-09-11
13112	999	2006-09-11
13113	999	2006-09-11
13114	999	2006-09-11
13115	999	2006-09-11
13116	999	2006-09-11
13117	999	2006-09-11
13118	999	2006-09-11
13119	999	2006-09-11
13120	999	2006-09-12
13121	999	2006-09-12
13122	999	2006-09-12
13123	999	2006-09-12
13124	999	2006-09-12
13125	999	2006-09-12
13126	999	2006-09-12
13127	999	2006-09-12
13128	999	2006-09-12
13129	999	2006-09-12
13130	999	2006-09-12
13131	999	2006-09-12
13132	999	2006-09-12
13133	999	2006-09-13
13134	999	2006-09-13
13135	999	2006-09-13
13136	999	2006-09-13
13137	999	2006-09-13
13138	999	2006-09-13
13139	999	2006-09-13
13140	999	2006-09-13
13141	999	2006-09-13
13142	999	2006-09-13
13143	999	2006-09-13
13144	999	2006-09-13
13145	999	2006-09-13
13146	999	2006-09-13
13147	999	2006-09-13
13148	999	2006-09-13
13149	999	2006-09-14
13150	999	2006-09-14
13151	999	2006-09-14
13152	999	2006-09-14
13153	999	2006-09-14
13154	999	2006-09-14
13155	999	2006-09-14
13156	999	2006-09-14
13157	999	2006-09-14
13158	999	2006-09-14
13159	999	2006-09-14
13160	999	2006-09-14
13161	999	2006-09-14
13162	999	2006-09-14
13163	999	2006-09-14
13164	999	2006-09-14
13165	999	2006-09-15
13166	999	2006-09-15
13167	999	2006-09-15
13168	999	2006-09-15
13169	999	2006-09-15
13170	999	2006-09-15
13171	999	2006-09-15
13172	999	2006-09-15
13173	999	2006-09-15
13174	999	2006-09-15
13175	999	2006-09-15
13176	999	2006-09-15
13177	999	2006-09-15
13178	999	2006-09-15
13179	999	2006-09-15
13180	999	2006-09-15
13181	999	2006-09-16
13182	999	2006-09-16
13183	999	2006-09-16
13184	999	2006-09-16
13185	999	2006-09-16
13186	999	2006-09-16
13187	999	2006-09-16
13188	999	2006-09-16
13189	999	2006-09-16
13190	999	2006-09-16
13191	999	2006-09-16
13192	999	2006-09-16
13193	999	2006-09-16
13194	999	2006-09-17
13195	999	2006-09-17
13196	999	2006-09-17
13197	999	2006-09-17
13198	999	2006-09-17
13199	999	2006-09-17
13200	999	2006-09-17
13201	999	2006-09-17
13202	999	2006-09-17
13203	999	2006-09-17
13204	999	2006-09-17
13205	999	2006-09-17
13206	999	2006-09-17
13207	999	2006-09-17
13208	999	2006-09-17
13209	999	2006-09-17
13210	999	2006-09-18
13211	999	2006-09-18
13212	999	2006-09-18
13213	999	2006-09-18
13214	999	2006-09-18
13215	999	2006-09-18
13216	999	2006-09-18
13217	999	2006-09-18
13218	999	2006-09-18
13219	999	2006-09-18
13220	999	2006-09-18
13221	999	2006-09-18
13222	999	2006-09-18
13223	999	2006-09-18
13224	999	2006-09-18
13225	999	2006-09-18
13226	999	2006-09-19
13227	999	2006-09-19
13228	999	2006-09-19
13229	999	2006-09-19
13230	999	2006-09-19
13231	999	2006-09-19
13232	999	2006-09-19
13233	999	2006-09-19
13234	999	2006-09-19
13235	999	2006-09-19
13236	999	2006-09-19
13237	999	2006-09-19
13238	999	2006-09-19
13239	999	2006-09-19
13240	999	2006-09-19
13241	999	2006-09-19
13242	999	2006-09-20
13243	999	2006-09-20
13244	999	2006-09-20
13245	999	2006-09-20
13246	999	2006-09-20
13247	999	2006-09-20
13248	999	2006-09-20
13249	999	2006-09-20
13250	999	2006-09-20
13251	999	2006-09-20
13252	999	2006-09-20
13253	999	2006-09-20
13254	999	2006-09-20
13255	999	2006-09-20
13256	999	2006-09-20
13257	999	2006-09-20
13258	999	2006-09-21
13259	999	2006-09-21
13260	999	2006-09-21
13261	999	2006-09-21
13262	999	2006-09-21
13263	999	2006-09-21
13264	999	2006-09-21
13265	999	2006-09-21
13266	999	2006-09-21
13267	999	2006-09-21
13268	999	2006-09-21
13269	999	2006-09-21
13270	999	2006-09-21
13271	999	2006-09-22
13272	999	2006-09-22
13273	999	2006-09-22
13274	999	2006-09-22
13275	999	2006-09-22
13276	999	2006-09-22
13277	999	2006-09-22
13278	999	2006-09-22
13279	999	2006-09-22
13280	999	2006-09-22
13281	999	2006-09-22
13282	999	2006-09-22
13283	999	2006-09-22
13284	999	2006-09-23
13285	999	2006-09-23
13286	999	2006-09-23
13287	999	2006-09-23
13288	999	2006-09-23
13289	999	2006-09-23
13290	999	2006-09-23
13291	999	2006-09-23
13292	999	2006-09-24
13293	999	2006-09-24
13294	999	2006-09-24
13295	999	2006-09-24
13296	999	2006-09-24
13297	999	2006-09-24
13298	999	2006-09-24
13299	999	2006-09-24
13300	999	2006-09-24
13301	999	2006-09-24
13302	999	2006-09-24
13303	999	2006-09-24
13304	999	2006-09-24
13305	999	2006-09-24
13306	999	2006-09-24
13307	999	2006-09-24
13308	999	2006-09-25
13309	999	2006-09-25
13310	999	2006-09-25
13311	999	2006-09-25
13312	999	2006-09-25
13313	999	2006-09-25
13314	999	2006-09-25
13315	999	2006-09-25
13316	999	2006-09-25
13317	999	2006-09-25
13318	999	2006-09-25
13319	999	2006-09-25
13320	999	2006-09-25
13321	999	2006-09-25
13322	999	2006-09-25
13323	999	2006-09-25
13324	999	2006-09-26
13325	999	2006-09-26
13326	999	2006-09-26
13327	999	2006-09-26
13328	999	2006-09-26
13329	999	2006-09-26
13330	999	2006-09-26
13331	999	2006-09-26
13332	999	2006-09-26
13333	999	2006-09-26
13334	999	2006-09-26
13335	999	2006-09-26
13336	999	2006-09-26
13337	999	2006-09-26
13338	999	2006-09-26
13339	999	2006-09-26
13340	999	2006-09-27
13341	999	2006-09-27
13342	999	2006-09-27
13343	999	2006-09-27
13344	999	2006-09-27
13345	999	2006-09-27
13346	999	2006-09-27
13347	999	2006-09-27
13348	999	2006-09-27
13349	999	2006-09-27
13350	999	2006-09-27
13351	999	2006-09-27
13352	999	2006-09-27
13353	999	2006-09-27
13354	999	2006-09-27
13355	999	2006-09-27
13356	999	2006-09-28
13357	999	2006-09-28
13358	999	2006-09-28
13359	999	2006-09-28
13360	999	2006-09-28
13361	999	2006-09-28
13362	999	2006-09-28
13363	999	2006-09-28
13364	999	2006-09-28
13365	999	2006-09-28
13366	999	2006-09-28
13367	999	2006-09-28
13368	999	2006-09-28
13369	999	2006-09-29
13370	999	2006-09-29
13371	999	2006-09-29
13372	999	2006-09-29
13373	999	2006-09-29
13374	999	2006-09-29
13375	999	2006-09-29
13376	999	2006-09-29
13377	999	2006-09-29
13378	999	2006-09-29
13379	999	2006-09-29
13380	999	2006-09-29
13381	999	2006-09-29
13382	999	2006-09-29
13383	999	2006-09-29
13384	999	2006-09-29
13385	999	2006-09-29
13386	999	2006-09-30
13387	999	2006-09-30
13388	999	2006-09-30
13389	999	2006-09-30
13390	999	2006-09-30
13391	999	2006-09-30
13392	999	2006-09-30
13393	999	2006-09-30
13394	999	2006-09-30
13395	999	2006-09-30
13396	999	2006-09-30
13397	999	2006-09-30
13398	999	2006-09-30
13399	999	2006-09-30
13400	999	2006-09-30
13401	999	2006-09-30
13402	999	2006-10-01
13403	999	2006-10-01
13404	999	2006-10-01
13405	999	2006-10-01
13406	999	2006-10-01
13407	999	2006-10-01
13408	999	2006-10-01
13409	999	2006-10-01
13410	999	2006-10-01
13411	999	2006-10-01
13412	999	2006-10-01
13413	999	2006-10-01
13414	999	2006-10-01
13415	999	2006-10-02
13416	999	2006-10-02
13417	999	2006-10-02
13418	999	2006-10-02
13419	999	2006-10-02
13420	999	2006-10-02
13421	999	2006-10-02
13422	999	2006-10-02
13423	999	2006-10-02
13424	999	2006-10-02
13425	999	2006-10-02
13426	999	2006-10-02
13427	999	2006-10-02
13428	999	2006-10-02
13429	999	2006-10-02
13430	999	2006-10-02
13431	999	2006-10-03
13432	999	2006-10-03
13433	999	2006-10-03
13434	999	2006-10-03
13435	999	2006-10-03
13436	999	2006-10-03
13437	999	2006-10-03
13438	999	2006-10-03
13439	999	2006-10-03
13440	999	2006-10-03
13441	999	2006-10-03
13442	999	2006-10-03
13443	999	2006-10-03
13444	999	2006-10-03
13445	999	2006-10-03
13446	999	2006-10-03
13447	999	2006-10-04
13448	999	2006-10-04
13449	999	2006-10-04
13450	999	2006-10-04
13451	999	2006-10-04
13452	999	2006-10-04
13453	999	2006-10-04
13454	999	2006-10-04
13455	999	2006-10-04
13456	999	2006-10-04
13457	999	2006-10-04
13458	999	2006-10-04
13459	999	2006-10-04
13460	999	2006-10-04
13461	999	2006-10-04
13462	999	2006-10-04
13463	999	2006-10-05
13464	999	2006-10-05
13465	999	2006-10-05
13466	999	2006-10-05
13467	999	2006-10-05
13468	999	2006-10-05
13469	999	2006-10-05
13470	999	2006-10-05
13471	999	2006-10-05
13472	999	2006-10-05
13473	999	2006-10-05
13474	999	2006-10-05
13475	999	2006-10-05
13476	999	2006-10-05
13477	999	2006-10-05
13478	999	2006-10-05
13479	999	2006-10-06
13480	999	2006-10-06
13481	999	2006-10-06
13482	999	2006-10-06
13483	999	2006-10-06
13484	999	2006-10-06
13485	999	2006-10-06
13486	999	2006-10-06
13487	999	2006-10-06
13488	999	2006-10-06
13489	999	2006-10-06
13490	999	2006-10-06
13491	999	2006-10-06
13492	999	2006-10-06
13493	999	2006-10-06
13494	999	2006-10-06
13495	999	2006-10-07
13496	999	2006-10-07
13497	999	2006-10-07
13498	999	2006-10-07
13499	999	2006-10-07
13500	999	2006-10-07
13501	999	2006-10-07
13502	999	2006-10-07
13503	999	2006-10-07
13504	999	2006-10-07
13505	999	2006-10-07
13506	999	2006-10-07
13507	999	2006-10-07
13508	999	2006-10-07
13509	999	2006-10-07
13510	999	2006-10-07
13511	999	2006-10-08
13512	999	2006-10-08
13513	999	2006-10-08
13514	999	2006-10-08
13515	999	2006-10-08
13516	999	2006-10-08
13517	999	2006-10-08
13518	999	2006-10-08
13519	999	2006-10-08
13520	999	2006-10-08
13521	999	2006-10-08
13522	999	2006-10-08
13523	999	2006-10-08
13524	999	2006-10-08
13525	999	2006-10-08
13526	999	2006-10-08
13527	999	2006-10-09
13528	999	2006-10-09
13529	999	2006-10-09
13530	999	2006-10-09
13531	999	2006-10-09
13532	999	2006-10-09
13533	999	2006-10-09
13534	999	2006-10-09
13535	999	2006-10-09
13536	999	2006-10-09
13537	999	2006-10-09
13538	999	2006-10-09
13539	999	2006-10-09
13540	999	2006-10-09
13541	999	2006-10-09
13542	999	2006-10-09
13543	999	2006-10-10
13544	999	2006-10-10
13545	999	2006-10-10
13546	999	2006-10-10
13547	999	2006-10-10
13548	999	2006-10-11
13549	999	2006-10-11
13550	999	2006-10-11
13551	999	2006-10-11
13552	999	2006-10-11
13553	999	2006-10-11
13554	999	2006-10-11
13555	999	2006-10-11
13556	999	2006-10-11
13557	999	2006-10-11
13558	999	2006-10-11
13559	999	2006-10-11
13560	999	2006-10-11
13561	999	2006-10-11
13562	999	2006-10-11
13563	999	2006-10-12
13564	999	2006-10-12
13565	999	2006-10-12
13566	999	2006-10-12
13567	999	2006-10-12
13568	999	2006-10-12
13569	999	2006-10-12
13570	999	2006-10-12
13571	999	2006-10-12
13572	999	2006-10-12
13573	999	2006-10-12
13574	999	2006-10-12
13575	999	2006-10-12
13576	999	2006-10-12
13577	999	2006-10-12
13578	999	2006-10-13
13579	999	2006-10-13
13580	999	2006-10-13
13581	999	2006-10-13
13582	999	2006-10-13
13583	999	2006-10-13
13584	999	2006-10-13
13585	999	2006-10-13
13586	999	2006-10-13
13587	999	2006-10-13
13588	999	2006-10-13
13589	999	2006-10-13
13590	999	2006-10-13
13591	999	2006-10-14
13592	999	2006-10-14
13593	999	2006-10-14
13594	999	2006-10-14
13595	999	2006-10-14
13596	999	2006-10-14
13597	999	2006-10-14
13598	999	2006-10-14
13599	999	2006-10-15
13600	999	2006-10-15
13601	999	2006-10-15
13602	999	2006-10-15
13603	999	2006-10-15
13604	999	2006-10-15
13605	999	2006-10-15
13606	999	2006-10-15
13607	999	2006-10-15
13608	999	2006-10-15
13609	999	2006-10-15
13610	999	2006-10-15
13611	999	2006-10-15
13612	999	2006-10-15
13613	999	2006-10-15
13614	999	2006-10-15
13615	999	2006-10-16
13616	999	2006-10-16
13617	999	2006-10-16
13618	999	2006-10-16
13619	999	2006-10-16
13620	999	2006-10-16
13621	999	2006-10-16
13622	999	2006-10-16
13623	999	2006-10-16
13624	999	2006-10-16
13625	999	2006-10-16
13626	999	2006-10-16
13627	999	2006-10-16
13628	999	2006-10-17
13629	999	2006-10-17
13630	999	2006-10-17
13631	999	2006-10-17
13632	999	2006-10-17
13633	999	2006-10-17
13634	999	2006-10-17
13635	999	2006-10-17
13636	999	2006-10-17
13637	999	2006-10-17
13638	999	2006-10-18
13639	999	2006-10-18
13640	999	2006-10-18
13641	999	2006-10-18
13642	999	2006-10-18
13643	999	2006-10-18
13644	999	2006-10-18
13645	999	2006-10-18
13646	999	2006-10-18
13647	999	2006-10-18
13648	999	2006-10-18
13649	999	2006-10-18
13650	999	2006-10-18
13651	999	2006-10-18
13652	999	2006-10-18
13653	999	2006-10-18
13654	999	2006-10-19
13655	999	2006-10-19
13656	999	2006-10-19
13657	999	2006-10-19
13658	999	2006-10-19
13659	999	2006-10-19
13660	999	2006-10-19
13661	999	2006-10-19
13662	999	2006-10-19
13663	999	2006-10-19
13664	999	2006-10-19
13665	999	2006-10-19
13666	999	2006-10-19
13667	999	2006-10-20
13668	999	2006-10-20
13669	999	2006-10-20
13670	999	2006-10-20
13671	999	2006-10-20
13672	999	2006-10-20
13673	999	2006-10-20
13674	999	2006-10-20
13675	999	2006-10-20
13676	999	2006-10-20
13677	999	2006-10-20
13678	999	2006-10-20
13679	999	2006-10-20
13680	999	2006-10-20
13681	999	2006-10-20
13682	999	2006-10-21
13683	999	2006-10-21
13684	999	2006-10-21
13685	999	2006-10-21
13686	999	2006-10-21
13687	999	2006-10-21
13688	999	2006-10-21
13689	999	2006-10-21
13690	999	2006-10-21
13691	999	2006-10-21
13692	999	2006-10-21
13693	999	2006-10-21
13694	999	2006-10-21
13695	999	2006-10-21
13696	999	2006-10-21
13697	999	2006-10-22
13698	999	2006-10-22
13699	999	2006-10-22
13700	999	2006-10-22
13701	999	2006-10-22
13702	999	2006-10-22
13703	999	2006-10-22
13704	999	2006-10-22
13705	999	2006-10-22
13706	999	2006-10-22
13707	999	2006-10-22
13708	999	2006-10-22
13709	999	2006-10-22
13710	999	2006-10-23
13711	999	2006-10-23
13712	999	2006-10-23
13713	999	2006-10-23
13714	999	2006-10-23
13715	999	2006-10-23
13716	999	2006-10-23
13717	999	2006-10-23
13718	999	2006-10-23
13719	999	2006-10-23
13720	999	2006-10-23
13721	999	2006-10-23
13722	999	2006-10-23
13723	999	2006-10-23
13724	999	2006-10-23
13725	999	2006-10-23
13726	999	2006-10-24
13727	999	2006-10-24
13728	999	2006-10-24
13729	999	2006-10-24
13730	999	2006-10-24
13731	999	2006-10-24
13732	999	2006-10-24
13733	999	2006-10-24
13734	999	2006-10-24
13735	999	2006-10-24
13736	999	2006-10-24
13737	999	2006-10-24
13738	999	2006-10-25
13739	999	2006-10-25
13740	999	2006-10-25
13741	999	2006-10-25
13742	999	2006-10-25
13743	999	2006-10-25
13744	999	2006-10-25
13745	999	2006-10-25
13746	999	2006-10-25
13747	999	2006-10-25
13748	999	2006-10-25
13749	999	2006-10-25
13750	999	2006-10-25
13751	999	2006-10-26
13752	999	2006-10-26
13753	999	2006-10-26
13754	999	2006-10-26
13755	999	2006-10-26
13756	999	2006-10-26
13757	999	2006-10-26
13758	999	2006-10-26
13759	999	2006-10-27
13760	999	2006-10-27
13761	999	2006-10-27
13762	999	2006-10-27
13763	999	2006-10-27
13764	999	2006-10-27
13765	999	2006-10-27
13766	999	2006-10-27
13767	999	2006-10-27
13768	999	2006-10-27
13769	999	2006-10-27
13770	999	2006-10-27
13771	999	2006-10-28
13772	999	2006-10-28
13773	999	2006-10-28
13774	999	2006-10-28
13775	999	2006-10-28
13776	999	2006-10-29
13777	999	2006-10-29
13778	999	2006-10-29
13779	999	2006-10-29
13780	999	2006-10-29
13781	999	2006-10-29
13782	999	2006-10-29
13783	999	2006-10-29
13784	999	2006-10-29
13785	999	2006-10-29
13786	999	2006-10-29
13787	999	2006-10-29
13788	999	2006-10-30
13789	999	2006-10-30
13790	999	2006-10-30
13791	999	2006-10-30
13792	999	2006-10-30
13793	999	2006-10-30
13794	999	2006-10-31
13795	999	2006-10-31
13796	999	2006-10-31
13797	999	2006-10-31
13798	999	2006-10-31
13799	999	2006-10-31
13800	999	2006-10-31
13801	999	2006-10-31
13802	999	2006-10-31
13803	999	2006-10-31
13804	999	2006-10-31
13805	999	2006-10-31
13806	999	2006-10-31
13807	999	2006-11-01
13808	999	2006-11-01
13809	999	2006-11-01
13810	999	2006-11-01
13811	999	2006-11-01
13812	999	2006-11-01
13813	999	2006-11-01
13814	999	2006-11-01
13815	999	2006-11-01
13816	999	2006-11-01
13817	999	2006-11-01
13818	999	2006-11-01
13819	999	2006-11-01
13820	999	2006-11-02
13821	999	2006-11-02
13822	999	2006-11-02
13823	999	2006-11-02
13824	999	2006-11-02
13825	999	2006-11-02
13826	999	2006-11-02
13827	999	2006-11-02
13828	999	2006-11-02
13829	999	2006-11-02
13830	999	2006-11-02
13831	999	2006-11-02
13832	999	2006-11-02
13833	999	2006-11-02
13834	999	2006-11-03
13835	999	2006-11-03
13836	999	2006-11-03
13837	999	2006-11-03
13838	999	2006-11-03
13839	999	2006-11-03
13840	999	2006-11-04
13841	999	2006-11-04
13842	999	2006-11-04
13843	999	2006-11-04
13844	999	2006-11-07
13845	999	2006-11-07
13846	999	2006-11-07
13847	999	2006-11-07
13848	999	2006-11-07
13849	999	2006-11-07
13850	999	2006-11-07
13851	999	2006-11-07
13852	999	2006-11-07
13853	999	2006-11-07
13854	999	2006-11-07
13855	999	2006-11-07
13856	999	2006-11-07
13857	999	2006-11-07
13858	999	2006-11-08
13859	999	2006-11-08
13860	999	2006-11-08
13861	999	2006-11-08
13862	999	2006-11-08
13863	999	2006-11-08
13864	999	2006-11-08
13865	999	2006-11-08
13866	999	2006-11-08
13867	999	2006-11-08
13868	999	2006-11-08
13869	999	2006-11-08
13870	999	2006-11-08
13871	999	2006-11-09
13872	999	2006-11-09
13873	999	2006-11-09
13874	999	2006-11-09
13875	999	2006-11-09
13876	999	2006-11-09
13877	999	2006-11-10
13878	999	2006-11-10
13879	999	2006-11-10
13880	999	2006-11-10
13881	999	2006-11-10
13882	999	2006-11-10
13883	999	2006-11-10
13884	999	2006-11-10
13885	999	2006-11-10
13886	999	2006-11-10
13887	999	2006-11-10
13888	999	2006-11-10
13889	999	2006-11-10
13890	999	2006-11-10
13891	999	2006-11-10
13892	999	2006-11-11
13893	999	2006-11-11
13894	999	2006-11-11
13895	999	2006-11-11
13896	999	2006-11-11
13897	999	2006-11-11
13898	999	2006-11-11
13899	999	2006-11-11
13900	999	2006-11-11
13901	999	2006-11-11
13902	999	2006-11-11
13903	999	2006-11-11
13904	999	2006-11-11
13905	999	2006-11-11
13906	999	2006-11-11
13907	999	2006-11-11
13908	999	2006-11-12
13909	999	2006-11-12
13910	999	2006-11-12
13911	999	2006-11-12
13912	999	2006-11-12
13913	999	2006-11-12
13914	999	2006-11-12
13915	999	2006-11-12
13916	999	2006-11-12
13917	999	2006-11-12
13918	999	2006-11-12
13919	999	2006-11-12
13920	999	2006-11-12
13921	999	2006-11-12
13922	999	2006-11-12
13923	999	2006-11-12
13924	999	2006-11-13
13925	999	2006-11-13
13926	999	2006-11-13
13927	999	2006-11-13
13928	999	2006-11-13
13929	999	2006-11-13
13930	999	2006-11-13
13931	999	2006-11-13
13932	999	2006-11-13
13933	999	2006-11-13
13934	999	2006-11-13
13935	999	2006-11-13
13936	999	2006-11-13
13937	999	2006-11-13
13938	999	2006-11-13
13939	999	2006-11-14
13940	999	2006-11-14
13941	999	2006-11-14
13942	999	2006-11-14
13943	999	2006-11-14
13944	999	2006-11-14
13945	999	2006-11-14
13946	999	2006-11-14
13947	999	2006-11-14
13948	999	2006-11-14
13949	999	2006-11-14
13950	999	2006-11-14
13951	999	2006-11-14
13952	999	2006-11-14
13953	999	2006-11-14
13954	999	2006-11-14
13955	999	2006-11-15
13956	999	2006-11-15
13957	999	2006-11-15
13958	999	2006-11-15
13959	999	2006-11-15
13960	999	2006-11-15
13961	999	2006-11-15
13962	999	2006-11-15
13963	999	2006-11-15
13964	999	2006-11-15
13965	999	2006-11-15
13966	999	2006-11-15
13967	999	2006-11-15
13968	999	2006-11-16
13969	999	2006-11-16
13970	999	2006-11-16
13971	999	2006-11-16
13972	999	2006-11-16
13973	999	2006-11-16
13974	999	2006-11-16
13975	999	2006-11-16
13976	999	2006-11-16
13977	999	2006-11-16
13978	999	2006-11-16
13979	999	2006-11-16
13980	999	2006-11-16
13981	999	2006-11-16
13982	999	2006-11-16
13983	999	2006-11-16
13984	999	2006-11-17
13985	999	2006-11-17
13986	999	2006-11-17
13987	999	2006-11-17
13988	999	2006-11-17
13989	999	2006-11-17
13990	999	2006-11-17
13991	999	2006-11-17
13992	999	2006-11-17
13993	999	2006-11-17
13994	999	2006-11-17
13995	999	2006-11-17
13996	999	2006-11-17
13997	999	2006-11-17
13998	999	2006-11-17
13999	999	2006-11-17
14000	999	2006-11-18
14001	999	2006-11-18
14002	999	2006-11-18
14003	999	2006-11-18
14004	999	2006-11-18
14005	999	2006-11-18
14006	999	2006-11-18
14007	999	2006-11-18
14008	999	2006-11-19
14009	999	2006-11-19
14010	999	2006-11-19
14011	999	2006-11-19
14012	999	2006-11-19
14013	999	2006-11-19
14014	999	2006-11-19
14015	999	2006-11-19
14016	999	2006-11-19
14017	999	2006-11-20
14018	999	2006-11-20
14019	999	2006-11-20
14020	999	2006-11-20
14021	999	2006-11-20
14022	999	2006-11-20
14023	999	2006-11-20
14024	999	2006-11-20
14025	999	2006-11-20
14026	999	2006-11-20
14027	999	2006-11-20
14028	999	2006-11-20
14029	999	2006-11-20
14030	999	2006-11-20
14031	999	2006-11-20
14032	999	2006-11-20
14033	999	2006-11-21
14034	999	2006-11-21
14035	999	2006-11-21
14036	999	2006-11-21
14037	999	2006-11-21
14038	999	2006-11-21
14039	999	2006-11-21
14040	999	2006-11-21
14041	999	2006-11-21
14042	999	2006-11-21
14043	999	2006-11-21
14044	999	2006-11-21
14045	999	2006-11-21
14046	999	2006-11-21
14047	999	2006-11-21
14048	999	2006-11-21
14049	999	2006-11-22
14050	999	2006-11-22
14051	999	2006-11-22
14052	999	2006-11-22
14053	999	2006-11-22
14054	999	2006-11-22
14055	999	2006-11-22
14056	999	2006-11-22
14057	999	2006-11-22
14058	999	2006-11-22
14059	999	2006-11-22
14060	999	2006-11-22
14061	999	2006-11-22
14062	999	2006-11-22
14063	999	2006-11-22
14064	999	2006-11-22
14065	999	2006-11-23
14066	999	2006-11-23
14067	999	2006-11-23
14068	999	2006-11-23
14069	999	2006-11-23
14070	999	2006-11-23
14071	999	2006-11-23
14072	999	2006-11-23
14073	999	2006-11-23
14074	999	2006-11-23
14075	999	2006-11-23
14076	999	2006-11-23
14077	999	2006-11-23
14078	999	2006-11-23
14079	999	2006-11-23
14080	999	2006-11-24
14081	999	2006-11-24
14082	999	2006-11-24
14083	999	2006-11-24
14084	999	2006-11-24
14085	999	2006-11-24
14086	999	2006-11-24
14087	999	2006-11-24
14088	999	2006-11-24
14089	999	2006-11-24
14090	999	2006-11-24
14091	999	2006-11-24
14092	999	2006-11-24
14093	999	2006-11-24
14094	999	2006-11-24
14095	999	2006-11-24
14096	999	2006-11-25
14097	999	2006-11-25
14098	999	2006-11-25
14099	999	2006-11-25
14100	999	2006-11-25
14101	999	2006-11-25
14102	999	2006-11-25
14103	999	2006-11-25
14104	999	2006-11-25
14105	999	2006-11-25
14106	999	2006-11-25
14107	999	2006-11-25
14108	999	2006-11-25
14109	999	2006-11-25
14110	999	2006-11-25
14111	999	2006-11-25
14112	999	2006-11-26
14113	999	2006-11-26
14114	999	2006-11-26
14115	999	2006-11-26
14116	999	2006-11-26
14117	999	2006-11-26
14118	999	2006-11-26
14119	999	2006-11-26
14120	999	2006-11-26
14121	999	2006-11-26
14122	999	2006-11-26
14123	999	2006-11-26
14124	999	2006-11-26
14125	999	2006-11-26
14126	999	2006-11-26
14127	999	2006-11-27
14128	999	2006-11-27
14129	999	2006-11-27
14130	999	2006-11-27
14131	999	2006-11-27
14132	999	2006-11-27
14133	999	2006-11-27
14134	999	2006-11-27
14135	999	2006-11-27
14136	999	2006-11-27
14137	999	2006-11-27
14138	999	2006-11-27
14139	999	2006-11-27
14140	999	2006-11-27
14141	999	2006-11-27
14142	999	2006-11-27
14143	999	2007-03-09
14144	999	2007-03-09
14145	999	2007-03-09
14146	999	2007-03-09
14147	999	2007-03-08
14148	999	2007-03-08
14149	999	2007-03-08
14150	999	2007-03-08
14151	999	2007-03-08
14152	999	2007-03-08
14153	999	2007-03-08
14154	999	2007-03-08
14155	999	2007-03-08
14156	999	2007-03-08
14157	999	2007-03-08
14158	999	2007-03-08
14159	999	2007-03-08
14160	999	2007-03-08
14161	999	2007-03-07
14162	999	2007-03-07
14163	999	2007-03-07
14164	999	2007-03-06
14165	999	2007-03-06
14166	999	2007-03-06
14167	999	2007-03-06
14168	999	2007-03-06
14169	999	2007-03-06
14170	999	2007-03-06
14171	999	2007-03-06
14172	999	2007-03-06
14173	999	2007-03-06
14174	999	2007-03-06
14175	999	2007-03-06
14176	999	2007-03-06
14177	999	2007-03-06
14178	999	2007-03-05
14179	999	2007-03-05
14180	999	2007-03-05
14181	999	2007-03-05
14182	999	2007-03-05
14183	999	2007-03-05
14184	999	2007-03-05
14185	999	2007-03-05
14186	999	2007-03-05
14187	999	2007-03-05
14188	999	2007-03-05
14189	999	2007-03-05
14190	999	2007-03-05
14191	999	2007-03-04
14192	999	2007-03-04
14193	999	2007-03-04
14194	999	2007-03-04
14195	999	2007-03-04
14196	999	2007-03-04
14197	999	2007-03-04
14198	999	2007-03-04
14199	999	2007-03-04
14200	999	2007-03-04
14201	999	2007-03-04
14202	999	2007-03-04
14203	999	2007-03-04
14204	999	2007-03-03
14205	999	2007-03-03
14206	999	2007-03-03
14207	999	2007-03-03
14208	999	2007-03-03
14209	999	2007-03-03
14210	999	2007-03-03
14211	999	2007-03-03
14212	999	2007-03-03
14213	999	2007-03-03
14214	999	2007-03-03
14215	999	2007-03-03
14216	999	2007-03-03
14217	999	2007-03-03
14218	999	2007-03-03
14219	999	2007-03-02
14220	999	2007-03-02
14221	999	2007-03-02
14222	999	2007-03-02
14223	999	2007-03-02
14224	999	2007-03-02
14225	999	2007-03-02
14226	999	2007-03-02
14227	999	2007-03-02
14228	999	2007-03-02
14229	999	2007-03-02
14230	999	2007-03-02
14231	999	2007-03-02
14232	999	2007-03-02
14233	999	2007-03-02
14234	999	2007-03-02
14235	999	2007-03-01
14236	999	2007-03-01
14237	999	2007-03-01
14238	999	2007-03-01
14239	999	2007-03-01
14240	999	2007-03-01
14241	999	2007-03-01
14242	999	2007-03-01
14243	999	2007-03-01
14244	999	2007-03-01
14245	999	2007-03-01
14246	999	2007-03-01
14247	999	2007-03-01
14248	999	2007-03-01
14249	999	2007-03-01
14250	999	2007-03-01
14251	999	2007-02-28
14252	999	2007-02-28
14253	999	2007-02-28
14254	999	2007-02-28
14255	999	2007-02-28
14256	999	2007-02-28
14257	999	2007-02-28
14258	999	2007-02-28
14259	999	2007-02-28
14260	999	2007-02-28
14261	999	2007-02-28
14262	999	2007-02-28
14263	999	2007-02-28
14264	999	2007-02-28
14265	999	2007-02-28
14266	999	2007-02-28
14267	999	2007-02-27
14268	999	2007-02-27
14269	999	2007-02-27
14270	999	2007-02-27
14271	999	2007-02-27
14272	999	2007-02-27
14273	999	2007-02-27
14274	999	2007-02-27
14275	999	2007-02-27
14276	999	2007-02-27
14277	999	2007-02-27
14278	999	2007-02-27
14279	999	2007-02-27
14280	999	2007-02-27
14281	999	2007-02-27
14282	999	2007-02-27
14283	999	2007-02-26
14284	999	2007-02-26
14285	999	2007-02-26
14286	999	2007-02-26
14287	999	2007-02-26
14288	999	2007-02-26
14289	999	2007-02-26
14290	999	2007-02-26
14291	999	2007-02-26
14292	999	2007-02-26
14293	999	2007-02-26
14294	999	2007-02-26
14295	999	2007-02-26
14296	999	2007-02-25
14297	999	2007-02-25
14298	999	2007-02-25
14299	999	2007-02-25
14300	999	2007-02-25
14301	999	2007-02-25
14302	999	2007-02-25
14303	999	2007-02-25
14304	999	2007-02-25
14305	999	2007-02-25
14306	999	2007-02-25
14307	999	2007-02-25
14308	999	2007-02-25
14309	999	2007-02-25
14310	999	2007-02-25
14311	999	2007-02-25
14312	999	2007-02-24
14313	999	2007-02-24
14314	999	2007-02-24
14315	999	2007-02-24
14316	999	2007-02-24
14317	999	2007-02-24
14318	999	2007-02-24
14319	999	2007-02-24
14320	999	2007-02-24
14321	999	2007-02-24
14322	999	2007-02-24
14323	999	2007-02-24
14324	999	2007-02-24
14325	999	2007-02-24
14326	999	2007-02-24
14327	999	2007-02-24
14328	999	2007-02-23
14329	999	2007-02-23
14330	999	2007-02-23
14331	999	2007-02-23
14332	999	2007-02-23
14333	999	2007-02-23
14334	999	2007-02-23
14335	999	2007-02-23
14336	999	2007-02-23
14337	999	2007-02-23
14338	999	2007-02-23
14339	999	2007-02-23
14340	999	2007-02-23
14341	999	2007-02-23
14342	999	2007-02-23
14343	999	2007-02-22
14344	999	2007-02-22
14345	999	2007-02-22
14346	999	2007-02-22
14347	999	2007-02-22
14348	999	2007-02-22
14349	999	2007-02-22
14350	999	2007-02-22
14351	999	2007-02-22
14352	999	2007-02-22
14353	999	2007-02-22
14354	999	2007-02-22
14355	999	2007-02-22
14356	999	2007-02-21
14357	999	2007-02-21
14358	999	2007-02-21
14359	999	2007-02-21
14360	999	2007-02-21
14361	999	2007-02-21
14362	999	2007-02-21
14363	999	2007-02-21
14364	999	2007-02-21
14365	999	2007-02-21
14366	999	2007-02-21
14367	999	2007-02-21
14368	999	2007-02-21
14369	999	2007-02-21
14370	999	2007-02-21
14371	999	2007-02-21
14372	999	2007-02-20
14373	999	2007-02-20
14374	999	2007-02-20
14375	999	2007-02-20
14376	999	2007-02-20
14377	999	2007-02-20
14378	999	2007-02-20
14379	999	2007-02-20
14380	999	2007-02-20
14381	999	2007-02-20
14382	999	2007-02-19
14383	999	2007-02-19
14384	999	2007-02-19
14385	999	2007-02-19
14386	999	2007-02-19
14387	999	2007-02-19
14388	999	2007-02-19
14389	999	2007-02-19
14390	999	2007-02-19
14391	999	2007-02-19
14392	999	2007-02-19
14393	999	2007-02-19
14394	999	2007-02-19
14395	999	2007-02-19
14396	999	2007-02-19
14397	999	2007-02-19
14398	999	2007-02-18
14399	999	2007-02-18
14400	999	2007-02-18
14401	999	2007-02-18
14402	999	2007-02-18
14403	999	2007-02-18
14404	999	2007-02-18
14405	999	2007-02-18
14406	999	2007-02-18
14407	999	2007-02-18
14408	999	2007-02-18
14409	999	2007-02-18
14410	999	2007-02-18
14411	999	2007-02-18
14412	999	2007-02-18
14413	999	2007-02-18
14414	999	2007-02-17
14415	999	2007-02-17
14416	999	2007-02-17
14417	999	2007-02-17
14418	999	2007-02-17
14419	999	2007-02-17
14420	999	2007-02-17
14421	999	2007-02-17
14422	999	2007-02-17
14423	999	2007-02-17
14424	999	2007-02-17
14425	999	2007-02-17
14426	999	2007-02-17
14427	999	2007-02-17
14428	999	2007-02-17
14429	999	2007-02-17
14430	999	2007-02-16
14431	999	2007-02-16
14432	999	2007-02-16
14433	999	2007-02-16
14434	999	2007-02-16
14435	999	2007-02-16
14436	999	2007-02-16
14437	999	2007-02-16
14438	999	2007-02-16
14439	999	2007-02-16
14440	999	2007-02-16
14441	999	2007-02-16
14442	999	2007-02-16
14443	999	2007-02-16
14444	999	2007-02-16
14445	999	2007-02-16
14446	999	2007-02-15
14447	999	2007-02-15
14448	999	2007-02-15
14449	999	2007-02-15
14450	999	2007-02-15
14451	999	2007-02-15
14452	999	2007-02-15
14453	999	2007-02-15
14454	999	2007-02-15
14455	999	2007-02-15
14456	999	2007-02-15
14457	999	2007-02-15
14458	999	2007-02-15
14459	999	2007-02-15
14460	999	2007-02-15
14461	999	2007-02-15
14462	999	2007-02-14
14463	999	2007-02-14
14464	999	2007-02-14
14465	999	2007-02-14
14466	999	2007-02-14
14467	999	2007-02-14
14468	999	2007-02-14
14469	999	2007-02-14
14470	999	2007-02-14
14471	999	2007-02-14
14472	999	2007-02-14
14473	999	2007-02-14
14474	999	2007-02-14
14475	999	2007-02-14
14476	999	2007-02-14
14477	999	2007-02-14
14478	999	2007-02-13
14479	999	2007-02-13
14480	999	2007-02-13
14481	999	2007-02-13
14482	999	2007-02-13
14483	999	2007-02-13
14484	999	2007-02-13
14485	999	2007-02-13
14486	999	2007-02-13
14487	999	2007-02-13
14488	999	2007-02-13
14489	999	2007-02-13
14490	999	2007-02-13
14491	999	2007-02-13
14492	999	2007-02-13
14493	999	2007-02-13
14494	999	2007-02-12
14495	999	2007-02-12
14496	999	2007-02-12
14497	999	2007-02-12
14498	999	2007-02-12
14499	999	2007-02-12
14500	999	2007-02-12
14501	999	2007-02-12
14502	999	2007-02-12
14503	999	2007-02-12
14504	999	2007-02-12
14505	999	2007-02-12
14506	999	2007-02-12
14507	999	2007-02-11
14508	999	2007-02-11
14509	999	2007-02-11
14510	999	2007-02-11
14511	999	2007-02-11
14512	999	2007-02-11
14513	999	2007-02-11
14514	999	2007-02-11
14515	999	2007-02-11
14516	999	2007-02-11
14517	999	2007-02-11
14518	999	2007-02-11
14519	999	2007-02-11
14520	999	2007-02-11
14521	999	2007-02-11
14522	999	2007-02-11
14523	999	2007-02-10
14524	999	2007-02-10
14525	999	2007-02-10
14526	999	2007-02-10
14527	999	2007-02-10
14528	999	2007-02-10
14529	999	2007-02-10
14530	999	2007-02-10
14531	999	2007-02-10
14532	999	2007-02-10
14533	999	2007-02-10
14534	999	2007-02-10
14535	999	2007-02-10
14536	999	2007-02-10
14537	999	2007-02-10
14538	999	2007-02-10
14539	999	2007-02-09
14540	999	2007-02-09
14541	999	2007-02-09
14542	999	2007-02-09
14543	999	2007-02-09
14544	999	2007-02-09
14545	999	2007-02-09
14546	999	2007-02-09
14547	999	2007-02-09
14548	999	2007-02-09
14549	999	2007-02-09
14550	999	2007-02-09
14551	999	2007-02-09
14552	999	2007-02-09
14553	999	2007-02-09
14554	999	2007-02-09
14555	999	2007-02-08
14556	999	2007-02-08
14557	999	2007-02-08
14558	999	2007-02-08
14559	999	2007-02-08
14560	999	2007-02-08
14561	999	2007-02-08
14562	999	2007-02-08
14563	999	2007-02-08
14564	999	2007-02-08
14565	999	2007-02-08
14566	999	2007-02-08
14567	999	2007-02-08
14568	999	2007-02-07
14569	999	2007-02-07
14570	999	2007-02-07
14571	999	2007-02-07
14572	999	2007-02-07
14573	999	2007-02-07
14574	999	2007-02-07
14575	999	2007-02-07
14576	999	2007-02-07
14577	999	2007-02-07
14578	999	2007-02-07
14579	999	2007-02-07
14580	999	2007-02-07
14581	999	2007-02-07
14582	999	2007-02-07
14583	999	2007-02-07
14584	999	2007-02-06
14585	999	2007-02-06
14586	999	2007-02-06
14587	999	2007-02-06
14588	999	2007-02-06
14589	999	2007-02-06
14590	999	2007-02-06
14591	999	2007-02-06
14592	999	2007-02-06
14593	999	2007-02-06
14594	999	2007-02-06
14595	999	2007-02-06
14596	999	2007-02-06
14597	999	2007-02-06
14598	999	2007-02-06
14599	999	2007-02-06
14600	999	2007-02-05
14601	999	2007-02-05
14602	999	2007-02-05
14603	999	2007-02-05
14604	999	2007-02-05
14605	999	2007-02-05
14606	999	2007-02-05
14607	999	2007-02-05
14608	999	2007-02-05
14609	999	2007-02-05
14610	999	2007-02-05
14611	999	2007-02-05
14612	999	2007-02-05
14613	999	2007-02-05
14614	999	2007-02-05
14615	999	2007-02-05
14616	999	2007-02-04
14617	999	2007-02-04
14618	999	2007-02-04
14619	999	2007-02-04
14620	999	2007-02-04
14621	999	2007-02-04
14622	999	2007-02-04
14623	999	2007-02-04
14624	999	2007-02-04
14625	999	2007-02-04
14626	999	2007-02-04
14627	999	2007-02-04
14628	999	2007-02-04
14629	999	2007-02-04
14630	999	2007-02-04
14631	999	2007-02-04
14632	999	2007-02-03
14633	999	2007-02-03
14634	999	2007-02-03
14635	999	2007-02-03
14636	999	2007-02-03
14637	999	2007-02-03
14638	999	2007-02-03
14639	999	2007-02-03
14640	999	2007-02-03
14641	999	2007-02-03
14642	999	2007-02-03
14643	999	2007-02-03
14644	999	2007-02-03
14645	999	2007-02-02
14646	999	2007-02-02
14647	999	2007-02-02
14648	999	2007-02-02
14649	999	2007-02-02
14650	999	2007-02-02
14651	999	2007-02-02
14652	999	2007-02-02
14653	999	2007-02-02
14654	999	2007-02-02
14655	999	2007-02-02
14656	999	2007-02-02
14657	999	2007-02-02
14658	999	2007-02-01
14659	999	2007-02-01
14660	999	2007-02-01
14661	999	2007-02-01
14662	999	2007-02-01
14663	999	2007-02-01
14664	999	2007-02-01
14665	999	2007-02-01
14666	999	2007-01-31
14667	999	2007-01-31
14668	999	2007-01-31
14669	999	2007-01-31
14670	999	2007-01-31
14671	999	2007-01-31
14672	999	2007-01-31
14673	999	2007-01-31
14674	999	2007-01-31
14675	999	2007-01-31
14676	999	2007-01-31
14677	999	2007-01-31
14678	999	2007-01-31
14679	999	2007-01-31
14680	999	2007-01-31
14681	999	2007-01-31
14682	999	2007-01-30
14683	999	2007-01-30
14684	999	2007-01-30
14685	999	2007-01-30
14686	999	2007-01-30
14687	999	2007-01-30
14688	999	2007-01-30
14689	999	2007-01-30
14690	999	2007-01-30
14691	999	2007-01-30
14692	999	2007-01-30
14693	999	2007-01-30
14694	999	2007-01-30
14695	999	2007-01-30
14696	999	2007-01-30
14697	999	2007-01-30
14698	999	2007-01-29
14699	999	2007-01-29
14700	999	2007-01-29
14701	999	2007-01-29
14702	999	2007-01-29
14703	999	2007-01-29
14704	999	2007-01-29
14705	999	2007-01-29
14706	999	2007-01-29
14707	999	2007-01-29
14708	999	2007-01-29
14709	999	2007-01-29
14710	999	2007-01-29
14711	999	2007-01-29
14712	999	2007-01-29
14713	999	2007-01-29
14714	999	2007-01-28
14715	999	2007-01-28
14716	999	2007-01-28
14717	999	2007-01-28
14718	999	2007-01-28
14719	999	2007-01-28
14720	999	2007-01-28
14721	999	2007-01-28
14722	999	2007-01-28
14723	999	2007-01-28
14724	999	2007-01-28
14725	999	2007-01-28
14726	999	2007-01-28
14727	999	2007-01-28
14728	999	2007-01-28
14729	999	2007-01-28
14730	999	2007-01-27
14731	999	2007-01-27
14732	999	2007-01-27
14733	999	2007-01-27
14734	999	2007-01-27
14735	999	2007-01-27
14736	999	2007-01-27
14737	999	2007-01-27
14738	999	2007-01-27
14739	999	2007-01-27
14740	999	2007-01-27
14741	999	2007-01-27
14742	999	2007-01-27
14743	999	2007-01-26
14744	999	2007-01-26
14745	999	2007-01-26
14746	999	2007-01-26
14747	999	2007-01-26
14748	999	2007-01-26
14749	999	2007-01-26
14750	999	2007-01-26
14751	999	2007-01-26
14752	999	2007-01-26
14753	999	2007-01-26
14754	999	2007-01-26
14755	999	2007-01-26
14756	999	2007-01-26
14757	999	2007-01-26
14758	999	2007-01-26
14759	999	2007-01-25
14760	999	2007-01-25
14761	999	2007-01-25
14762	999	2007-01-25
14763	999	2007-01-25
14764	999	2007-01-25
14765	999	2007-01-25
14766	999	2007-01-25
14767	999	2007-01-25
14768	999	2007-01-25
14769	999	2007-01-25
14770	999	2007-01-25
14771	999	2007-01-25
14772	999	2007-01-25
14773	999	2007-01-25
14774	999	2007-01-25
14775	999	2007-01-24
14776	999	2007-01-24
14777	999	2007-01-24
14778	999	2007-01-24
14779	999	2007-01-24
14780	999	2007-01-24
14781	999	2007-01-24
14782	999	2007-01-24
14783	999	2007-01-24
14784	999	2007-01-24
14785	999	2007-01-24
14786	999	2007-01-24
14787	999	2007-01-24
14788	999	2007-01-23
14789	999	2007-01-23
14790	999	2007-01-23
14791	999	2007-01-23
14792	999	2007-01-23
14793	999	2007-01-23
14794	999	2007-01-23
14795	999	2007-01-23
14796	999	2007-01-23
14797	999	2007-01-23
14798	999	2007-01-23
14799	999	2007-01-23
14800	999	2007-01-23
14801	999	2007-01-23
14802	999	2007-01-23
14803	999	2007-01-23
14804	999	2007-01-22
14805	999	2007-01-22
14806	999	2007-01-22
14807	999	2007-01-22
14808	999	2007-01-22
14809	999	2007-01-22
14810	999	2007-01-22
14811	999	2007-01-22
14812	999	2007-01-22
14813	999	2007-01-22
14814	999	2007-01-22
14815	999	2007-01-22
14816	999	2007-01-22
14817	999	2007-01-22
14818	999	2007-01-22
14819	999	2007-01-22
14820	999	2007-01-21
14821	999	2007-01-21
14822	999	2007-01-21
14823	999	2007-01-21
14824	999	2007-01-21
14825	999	2007-01-21
14826	999	2007-01-21
14827	999	2007-01-21
14828	999	2007-01-21
14829	999	2007-01-21
14830	999	2007-01-21
14831	999	2007-01-21
14832	999	2007-01-21
14833	999	2007-01-21
14834	999	2007-01-21
14835	999	2007-01-21
14836	999	2007-01-20
14837	999	2007-01-20
14838	999	2007-01-20
14839	999	2007-01-20
14840	999	2007-01-20
14841	999	2007-01-20
14842	999	2007-01-20
14843	999	2007-01-20
14844	999	2007-01-20
14845	999	2007-01-20
14846	999	2007-01-20
14847	999	2007-01-20
14848	999	2007-01-20
14849	999	2007-01-20
14850	999	2007-01-20
14851	999	2007-01-20
14852	999	2007-01-19
14853	999	2007-01-19
14854	999	2007-01-19
14855	999	2007-01-19
14856	999	2007-01-19
14857	999	2007-01-19
14858	999	2007-01-19
14859	999	2007-01-19
14860	999	2007-01-19
14861	999	2007-01-19
14862	999	2007-01-19
14863	999	2007-01-19
14864	999	2007-01-19
14865	999	2007-01-19
14866	999	2007-01-19
14867	999	2007-01-19
14868	999	2007-01-18
14869	999	2007-01-18
14870	999	2007-01-18
14871	999	2007-01-18
14872	999	2007-01-18
14873	999	2007-01-18
14874	999	2007-01-18
14875	999	2007-01-18
14876	999	2007-01-18
14877	999	2007-01-18
14878	999	2007-01-18
14879	999	2007-01-18
14880	999	2007-01-18
14881	999	2007-01-18
14882	999	2007-01-18
14883	999	2007-01-18
14884	999	2007-01-17
14885	999	2007-01-17
14886	999	2007-01-17
14887	999	2007-01-17
14888	999	2007-01-17
14889	999	2007-01-17
14890	999	2007-01-17
14891	999	2007-01-17
14892	999	2007-01-17
14893	999	2007-01-17
14894	999	2007-01-17
14895	999	2007-01-17
14896	999	2007-01-17
14897	999	2007-01-17
14898	999	2007-01-17
14899	999	2007-01-17
14900	999	2007-01-16
14901	999	2007-01-16
14902	999	2007-01-16
14903	999	2007-01-16
14904	999	2007-01-16
14905	999	2007-01-16
14906	999	2007-01-16
14907	999	2007-01-16
14908	999	2007-01-16
14909	999	2007-01-16
14910	999	2007-01-16
14911	999	2007-01-16
14912	999	2007-01-16
14913	999	2007-01-16
14914	999	2007-01-16
14915	999	2007-01-16
14916	999	2007-01-15
14917	999	2007-01-15
14918	999	2007-01-15
14919	999	2007-01-15
14920	999	2007-01-15
14921	999	2007-01-15
14922	999	2007-01-14
14923	999	2007-01-14
14924	999	2007-01-14
14925	999	2007-01-14
14926	999	2007-01-14
14927	999	2007-01-14
14928	999	2007-01-14
14929	999	2007-01-14
14930	999	2007-01-14
14931	999	2007-01-14
14932	999	2007-01-14
14933	999	2007-01-14
14934	999	2007-01-14
14935	999	2007-01-14
14936	999	2007-01-13
14937	999	2007-01-13
14938	999	2007-01-13
14939	999	2007-01-13
14940	999	2007-01-13
14941	999	2007-01-13
14942	999	2007-01-13
14943	999	2007-01-13
14944	999	2007-01-13
14945	999	2007-01-13
14946	999	2007-01-13
14947	999	2007-01-13
14948	999	2007-01-13
14949	999	2007-01-13
14950	999	2007-01-13
14951	999	2007-01-12
14952	999	2007-01-12
14953	999	2007-01-12
14954	999	2007-01-12
14955	999	2007-01-12
14956	999	2007-01-12
14957	999	2007-01-12
14958	999	2007-01-12
14959	999	2007-01-12
14960	999	2007-01-12
14961	999	2007-01-12
14962	999	2007-01-12
14963	999	2007-01-12
14964	999	2007-01-12
14965	999	2007-01-11
14966	999	2007-01-11
14967	999	2007-01-11
14968	999	2007-01-11
14969	999	2007-01-11
14970	999	2007-01-11
14971	999	2007-01-11
14972	999	2007-01-10
14973	999	2007-01-10
14974	999	2007-01-10
14975	999	2007-01-10
14976	999	2007-01-10
14977	999	2007-01-10
14978	999	2007-01-10
14979	999	2007-01-10
14980	999	2007-01-10
14981	999	2007-01-10
14982	999	2007-01-10
14983	999	2007-01-10
14984	999	2007-01-10
14985	999	2007-01-10
14986	999	2007-01-10
14987	999	2007-01-10
14988	999	2007-01-09
14989	999	2007-01-09
14990	999	2007-01-09
14991	999	2007-01-09
14992	999	2007-01-09
14993	999	2007-01-09
14994	999	2007-01-09
14995	999	2007-01-09
14996	999	2007-01-09
14997	999	2007-01-09
14998	999	2007-01-09
14999	999	2007-01-09
15000	999	2007-01-09
15001	999	2007-01-08
15002	999	2007-01-08
15003	999	2007-01-08
15004	999	2007-01-08
15005	999	2007-01-08
15006	999	2007-01-08
15007	999	2007-01-08
15008	999	2007-01-08
15009	999	2007-01-08
15010	999	2007-01-08
15011	999	2007-01-07
15012	999	2007-01-07
15013	999	2007-01-07
15014	999	2007-01-07
15015	999	2007-01-07
15016	999	2007-01-07
15017	999	2007-01-07
15018	999	2007-01-07
15019	999	2007-01-07
15020	999	2007-01-07
15021	999	2007-01-07
15022	999	2007-01-07
15023	999	2007-01-07
15024	999	2007-01-07
15025	999	2007-01-07
15026	999	2007-01-07
15027	999	2007-01-06
15028	999	2007-01-06
15029	999	2007-01-06
15030	999	2007-01-06
15031	999	2007-01-06
15032	999	2007-01-06
15033	999	2007-01-06
15034	999	2007-01-06
15035	999	2007-01-06
15036	999	2007-01-06
15037	999	2007-01-06
15038	999	2007-01-06
15039	999	2007-01-06
15040	999	2007-01-05
15041	999	2007-01-05
15042	999	2007-01-05
15043	999	2007-01-05
15044	999	2007-01-05
15045	999	2007-01-05
15046	999	2007-01-05
15047	999	2007-01-05
15048	999	2007-01-05
15049	999	2007-01-05
15050	999	2007-01-05
15051	999	2007-01-05
15052	999	2007-01-05
15053	999	2007-01-05
15054	999	2007-01-05
15055	999	2007-01-04
15056	999	2007-01-04
15057	999	2007-01-04
15058	999	2007-01-04
15059	999	2007-01-04
15060	999	2007-01-04
15061	999	2007-01-04
15062	999	2007-01-04
15063	999	2007-01-04
15064	999	2007-01-04
15065	999	2007-01-04
15066	999	2007-01-04
15067	999	2007-01-04
15068	999	2007-01-04
15069	999	2007-01-04
15070	999	2007-01-03
15071	999	2007-01-03
15072	999	2007-01-03
15073	999	2007-01-03
15074	999	2007-01-03
15075	999	2007-01-03
15076	999	2007-01-03
15077	999	2007-01-03
15078	999	2007-01-03
15079	999	2007-01-03
15080	999	2007-01-03
15081	999	2007-01-03
15082	999	2007-01-03
15083	999	2007-01-02
15084	999	2007-01-02
15085	999	2007-01-02
15086	999	2007-01-02
15087	999	2007-01-02
15088	999	2007-01-02
15089	999	2007-01-02
15090	999	2007-01-02
15091	999	2007-01-02
15092	999	2007-01-02
15093	999	2007-01-02
15094	999	2007-01-02
15095	999	2007-01-02
15096	999	2007-01-02
15097	999	2007-01-02
15098	999	2007-01-02
15099	999	2007-01-01
15100	999	2007-01-01
15101	999	2007-01-01
15102	999	2007-01-01
15103	999	2007-01-01
15104	999	2007-01-01
15105	999	2007-01-01
15106	999	2007-01-01
15107	999	2007-01-01
15108	999	2007-01-01
15109	999	2007-01-01
15110	999	2007-01-01
15111	999	2007-01-01
15112	999	2006-12-31
15113	999	2006-12-31
15114	999	2006-12-31
15115	999	2006-12-31
15116	999	2006-12-31
15117	999	2006-12-31
15118	999	2006-12-31
15119	999	2006-12-31
15120	999	2006-12-31
15121	999	2006-12-31
15122	999	2006-12-31
15123	999	2006-12-31
15124	999	2006-12-30
15125	999	2006-12-30
15126	999	2006-12-30
15127	999	2006-12-30
15128	999	2006-12-30
15129	999	2006-12-30
15130	999	2006-12-30
15131	999	2006-12-30
15132	999	2006-12-29
15133	999	2006-12-29
15134	999	2006-12-29
15135	999	2006-12-29
15136	999	2006-12-29
15137	999	2006-12-29
15138	999	2006-12-29
15139	999	2006-12-29
15140	999	2006-12-29
15141	999	2006-12-29
15142	999	2006-12-29
15143	999	2006-12-29
15144	999	2006-12-29
15145	999	2006-12-28
15146	999	2006-12-28
15147	999	2006-12-28
15148	999	2006-12-28
15149	999	2006-12-27
15150	999	2006-12-27
15151	999	2006-12-27
15152	999	2006-12-27
15153	999	2006-12-27
15154	999	2006-12-27
15155	999	2006-12-27
15156	999	2006-12-27
15157	999	2006-12-27
15158	999	2006-12-27
15159	999	2006-12-27
15160	999	2006-12-26
15161	999	2006-12-26
15162	999	2006-12-26
15163	999	2006-12-26
15164	999	2006-12-26
15165	999	2006-12-26
15166	999	2006-12-25
15167	999	2006-12-25
15168	999	2006-12-25
15169	999	2006-12-25
15170	999	2006-12-25
15171	999	2006-12-25
15172	999	2006-12-25
15173	999	2006-12-25
15174	999	2006-12-25
15175	999	2006-12-25
15176	999	2006-12-25
15177	999	2006-12-25
15178	999	2006-12-25
15179	999	2006-12-24
15180	999	2006-12-24
15181	999	2006-12-24
15182	999	2006-12-24
15183	999	2006-12-24
15184	999	2006-12-24
15185	999	2006-12-24
15186	999	2006-12-24
15187	999	2006-12-24
15188	999	2006-12-24
15189	999	2006-12-24
15190	999	2006-12-24
15191	999	2006-12-24
15192	999	2006-12-23
15193	999	2006-12-23
15194	999	2006-12-23
15195	999	2006-12-23
15196	999	2006-12-23
15197	999	2006-12-23
15198	999	2006-12-23
15199	999	2006-12-23
15200	999	2006-12-23
15201	999	2006-12-23
15202	999	2006-12-23
15203	999	2006-12-23
15204	999	2006-12-23
15205	999	2006-12-23
15206	999	2006-12-22
15207	999	2006-12-22
15208	999	2006-12-22
15209	999	2006-12-22
15210	999	2006-12-22
15211	999	2006-12-22
15212	999	2006-12-21
15213	999	2006-12-21
15214	999	2006-12-21
15215	999	2006-12-21
15216	999	2006-12-21
15217	999	2006-12-21
15218	999	2006-12-18
15219	999	2006-12-18
15220	999	2006-12-18
15221	999	2006-12-18
15222	999	2006-12-18
15223	999	2006-12-18
15224	999	2006-12-18
15225	999	2006-12-18
15226	999	2006-12-18
15227	999	2006-12-18
15228	999	2006-12-18
15229	999	2006-12-18
15230	999	2006-12-17
15231	999	2006-12-17
15232	999	2006-12-17
15233	999	2006-12-17
15234	999	2006-12-17
15235	999	2006-12-17
15236	999	2006-12-17
15237	999	2006-12-17
15238	999	2006-12-17
15239	999	2006-12-17
15240	999	2006-12-17
15241	999	2006-12-17
15242	999	2006-12-17
15243	999	2006-12-17
15244	999	2006-12-16
15245	999	2006-12-16
15246	999	2006-12-16
15247	999	2006-12-16
15248	999	2006-12-16
15249	999	2006-12-16
15250	999	2006-12-16
15251	999	2006-12-15
15252	999	2006-12-15
15253	999	2006-12-15
15254	999	2006-12-15
15255	999	2006-12-15
15256	999	2006-12-15
15257	999	2006-12-15
15258	999	2006-12-15
15259	999	2006-12-15
15260	999	2006-12-15
15261	999	2006-12-15
15262	999	2006-12-15
15263	999	2006-12-15
15264	999	2006-12-14
15265	999	2006-12-14
15266	999	2006-12-14
15267	999	2006-12-14
15268	999	2006-12-14
15269	999	2006-12-14
15270	999	2006-12-14
15271	999	2006-12-14
15272	999	2006-12-14
15273	999	2006-12-14
15274	999	2006-12-14
15275	999	2006-12-14
15276	999	2006-12-14
15277	999	2006-12-14
15278	999	2006-12-14
15279	999	2006-12-14
15280	999	2006-12-13
15281	999	2006-12-13
15282	999	2006-12-13
15283	999	2006-12-13
15284	999	2006-12-13
15285	999	2006-12-13
15286	999	2006-12-13
15287	999	2006-12-13
15288	999	2006-12-13
15289	999	2006-12-13
15290	999	2006-12-13
15291	999	2006-12-13
15292	999	2006-12-13
15293	999	2006-12-13
15294	999	2006-12-13
15295	999	2006-12-13
15296	999	2006-12-12
15297	999	2006-12-12
15298	999	2006-12-12
15299	999	2006-12-12
15300	999	2006-12-12
15301	999	2006-12-12
15302	999	2006-12-12
15303	999	2006-12-12
15304	999	2006-12-12
15305	999	2006-12-12
15306	999	2006-12-12
15307	999	2006-12-12
15308	999	2006-12-12
15309	999	2006-12-12
15310	999	2006-12-12
15311	999	2006-12-11
15312	999	2006-12-11
15313	999	2006-12-11
15314	999	2006-12-11
15315	999	2006-12-11
15316	999	2006-12-11
15317	999	2006-12-11
15318	999	2006-12-11
15319	999	2006-12-11
15320	999	2006-12-11
15321	999	2006-12-11
15322	999	2006-12-11
15323	999	2006-12-11
15324	999	2006-12-11
15325	999	2006-12-11
15326	999	2006-12-11
15327	999	2006-12-10
15328	999	2006-12-10
15329	999	2006-12-10
15330	999	2006-12-10
15331	999	2006-12-10
15332	999	2006-12-10
15333	999	2006-12-10
15334	999	2006-12-10
15335	999	2006-12-10
15336	999	2006-12-10
15337	999	2006-12-10
15338	999	2006-12-10
15339	999	2006-12-10
15340	999	2006-12-09
15341	999	2006-12-09
15342	999	2006-12-09
15343	999	2006-12-09
15344	999	2006-12-09
15345	999	2006-12-09
15346	999	2006-12-09
15347	999	2006-12-09
15348	999	2006-12-09
15349	999	2006-12-09
15350	999	2006-12-09
15351	999	2006-12-09
15352	999	2006-12-09
15353	999	2006-12-09
15354	999	2006-12-09
15355	999	2006-12-09
15356	999	2006-12-08
15357	999	2006-12-08
15358	999	2006-12-08
15359	999	2006-12-08
15360	999	2006-12-08
15361	999	2006-12-08
15362	999	2006-12-08
15363	999	2006-12-08
15364	999	2006-12-08
15365	999	2006-12-08
15366	999	2006-12-08
15367	999	2006-12-08
15368	999	2006-12-08
15369	999	2006-12-08
15370	999	2006-12-08
15371	999	2006-12-08
15372	999	2006-12-07
15373	999	2006-12-07
15374	999	2006-12-07
15375	999	2006-12-07
15376	999	2006-12-07
15377	999	2006-12-07
15378	999	2006-12-07
15379	999	2006-12-07
15380	999	2006-12-07
15381	999	2006-12-07
15382	999	2006-12-06
15383	999	2006-12-06
15384	999	2006-12-06
15385	999	2006-12-06
15386	999	2006-12-06
15387	999	2006-12-06
15388	999	2006-12-06
15389	999	2006-12-05
15390	999	2006-12-05
15391	999	2006-12-05
15392	999	2006-12-05
15393	999	2006-12-05
15394	999	2006-12-05
15395	999	2006-12-05
15396	999	2006-12-05
15397	999	2006-12-05
15398	999	2006-12-05
15399	999	2006-12-05
15400	999	2006-12-05
15401	999	2006-12-05
15402	999	2006-12-05
15403	999	2006-12-05
15404	999	2006-12-05
15405	999	2006-12-04
15406	999	2006-12-04
15407	999	2006-12-04
15408	999	2006-12-04
15409	999	2006-12-04
15410	999	2006-12-04
15411	999	2006-12-04
15412	999	2006-12-04
15413	999	2006-12-04
15414	999	2006-12-04
15415	999	2006-12-04
15416	999	2006-12-04
15417	999	2006-12-04
15418	999	2006-12-04
15419	999	2006-12-04
15420	999	2006-12-04
15421	999	2006-12-03
15422	999	2006-12-03
15423	999	2006-12-03
15424	999	2006-12-03
15425	999	2006-12-03
15426	999	2006-12-03
15427	999	2006-12-03
15428	999	2006-12-03
15429	999	2006-12-03
15430	999	2006-12-03
15431	999	2006-12-03
15432	999	2006-12-03
15433	999	2006-12-03
15434	999	2006-12-03
15435	999	2006-12-03
15436	999	2006-12-03
15437	999	2006-12-02
15438	999	2006-12-02
15439	999	2006-12-02
15440	999	2006-12-02
15441	999	2006-12-02
15442	999	2006-12-02
15443	999	2006-12-02
15444	999	2006-12-02
15445	999	2006-12-02
15446	999	2006-12-02
15447	999	2006-12-02
15448	999	2006-12-02
15449	999	2006-12-02
15450	999	2006-12-02
15451	999	2006-12-02
15452	999	2006-12-01
15453	999	2006-12-01
15454	999	2006-12-01
15455	999	2006-12-01
15456	999	2006-12-01
15457	999	2006-12-01
15458	999	2006-12-01
15459	999	2006-12-01
15460	999	2006-12-01
15461	999	2006-12-01
15462	999	2006-12-01
15463	999	2006-12-01
15464	999	2006-12-01
15465	999	2006-12-01
15466	999	2006-12-01
15467	999	2006-12-01
15468	999	2006-11-30
15469	999	2006-11-30
15470	999	2006-11-30
15471	999	2006-11-30
15472	999	2006-11-30
15473	999	2006-11-30
15474	999	2006-11-30
15475	999	2006-11-30
15476	999	2006-11-30
15477	999	2006-11-30
15478	999	2006-11-30
15479	999	2006-11-30
15480	999	2006-11-30
15481	999	2006-11-30
15482	999	2006-11-30
15483	999	2006-11-30
15484	999	2006-11-29
15485	999	2006-11-29
15486	999	2006-11-29
15487	999	2006-11-29
15488	999	2006-11-29
15489	999	2006-11-29
15490	999	2006-11-29
15491	999	2006-11-29
15492	999	2006-11-29
15493	999	2006-11-29
15494	999	2006-11-29
15495	999	2006-11-29
15496	999	2006-11-29
15497	999	2006-11-29
15498	999	2006-11-29
15499	999	2006-11-28
15500	999	2006-11-28
15501	999	2006-11-28
15502	999	2006-11-28
15503	999	2006-11-28
15504	999	2006-11-28
15505	999	2006-11-28
15506	999	2006-11-28
15507	999	2006-11-28
15508	999	2006-11-28
15509	999	2006-11-28
15510	999	2006-11-28
15511	999	2006-11-28
15512	999	2006-11-28
15513	999	2006-11-28
15514	999	2006-11-28
15515	999	2006-11-27
15516	999	2006-11-27
111	999	2006-08-27
112	999	2006-08-27
113	999	2006-08-27
114	999	2006-08-27
115	999	2006-08-27
116	999	2006-08-27
117	999	2006-08-27
118	999	2006-08-27
119	999	2006-08-27
120	999	2006-08-27
121	999	2006-08-27
122	999	2006-08-27
123	999	2006-08-27
124	999	2006-08-27
125	999	2006-08-28
126	999	2006-08-28
129	999	2006-08-28
130	999	2006-08-28
131	999	2006-08-28
132	999	2006-08-28
133	999	2006-08-28
134	999	2006-08-28
135	999	2006-08-28
136	999	2006-08-28
137	999	2006-08-28
138	999	2006-08-28
139	999	2006-08-28
140	999	2006-08-28
141	999	2006-08-29
142	999	2006-08-29
143	999	2006-08-29
144	999	2006-08-29
145	999	2006-08-29
146	999	2006-08-29
147	999	2006-08-29
148	999	2006-08-29
149	999	2006-08-29
150	999	2006-08-29
151	999	2006-08-29
152	999	2006-08-29
153	999	2006-08-29
154	999	2006-08-30
155	999	2006-08-30
156	999	2006-08-30
157	999	2006-08-30
158	999	2006-08-30
159	999	2006-08-30
160	999	2006-08-30
161	999	2006-08-30
162	999	2006-08-30
163	999	2006-08-30
164	999	2006-08-30
165	999	2006-08-30
166	999	2006-08-30
167	999	2006-08-30
168	999	2006-08-30
169	999	2006-08-30
170	999	2006-08-31
171	999	2006-08-31
172	999	2006-08-31
173	999	2006-08-31
174	999	2006-08-31
175	999	2006-08-31
176	999	2006-08-31
179	999	2006-08-31
180	999	2006-08-31
181	999	2006-08-31
182	999	2006-08-31
183	999	2006-08-31
184	999	2006-08-31
185	999	2006-08-31
186	999	2006-09-01
187	999	2006-09-01
188	999	2006-09-01
189	999	2006-09-01
190	999	2006-09-01
191	999	2006-09-01
192	999	2006-09-01
193	999	2006-09-01
194	999	2006-09-01
195	999	2006-09-01
25	999	2006-08-21
26	999	2006-08-21
27	999	2006-08-21
28	999	2006-08-21
29	999	2006-08-21
30	999	2006-08-21
31	999	2006-08-21
32	999	2006-08-21
33	999	2006-08-21
34	999	2006-08-21
35	999	2006-08-21
36	999	2006-08-22
37	999	2006-08-22
38	999	2006-08-22
39	999	2006-08-22
40	999	2006-08-22
41	999	2006-08-22
42	999	2006-08-22
43	999	2006-08-22
44	999	2006-08-22
45	999	2006-08-22
46	999	2006-08-22
196	999	2006-09-01
197	999	2006-09-01
198	999	2006-09-01
199	999	2006-09-01
200	999	2006-09-01
201	999	2006-09-02
202	999	2006-09-02
203	999	2006-09-02
204	999	2006-09-02
205	999	2006-09-02
206	999	2006-09-02
207	999	2006-09-02
208	999	2006-09-02
209	999	2006-09-02
210	999	2006-09-02
211	999	2006-09-02
212	999	2006-09-02
213	999	2006-09-02
214	999	2006-09-03
215	999	2006-09-03
216	999	2006-09-03
217	999	2006-09-03
218	999	2006-09-03
219	999	2006-09-03
220	999	2006-09-03
221	999	2006-09-03
222	999	2006-09-03
223	999	2006-09-03
224	999	2006-09-03
225	999	2006-09-03
226	999	2006-09-03
229	999	2006-09-03
230	999	2006-09-04
231	999	2006-09-04
232	999	2006-09-04
233	999	2006-09-04
234	999	2006-09-04
235	999	2006-09-04
236	999	2006-09-04
237	999	2006-09-04
238	999	2006-09-04
239	999	2006-09-04
240	999	2006-09-05
241	999	2006-09-05
242	999	2006-09-05
243	999	2006-09-05
244	999	2006-09-05
245	999	2006-09-05
246	999	2006-09-05
247	999	2006-09-05
248	999	2006-09-05
249	999	2006-09-05
250	999	2006-09-05
251	999	2006-09-05
252	999	2006-09-05
253	999	2006-09-05
254	999	2006-09-05
255	999	2006-09-05
256	999	2006-09-06
257	999	2006-09-06
258	999	2006-09-06
259	999	2006-09-06
260	999	2006-09-06
261	999	2006-09-06
262	999	2006-09-06
263	999	2006-09-06
264	999	2006-09-06
265	999	2006-09-06
266	999	2006-09-06
267	999	2006-09-06
268	999	2006-09-06
269	999	2006-09-06
270	999	2006-09-06
271	999	2006-09-06
272	999	2006-09-07
273	999	2006-09-07
274	999	2006-09-07
275	999	2006-09-07
276	999	2006-09-07
279	999	2006-09-07
280	999	2006-09-07
281	999	2006-09-07
282	999	2006-09-07
283	999	2006-09-07
284	999	2006-09-07
285	999	2006-09-07
286	999	2006-09-07
287	999	2006-09-07
288	999	2006-09-08
289	999	2006-09-08
290	999	2006-09-08
291	999	2006-09-08
292	999	2006-09-08
293	999	2006-09-08
294	999	2006-09-08
295	999	2006-09-08
296	999	2006-09-08
297	999	2006-09-08
298	999	2006-09-08
299	999	2006-09-08
300	999	2006-09-08
301	999	2006-09-08
302	999	2006-09-08
303	999	2006-09-08
304	999	2006-09-09
305	999	2006-09-09
306	999	2006-09-09
307	999	2006-09-09
308	999	2006-09-09
309	999	2006-09-09
310	999	2006-09-09
311	999	2006-09-09
312	999	2006-09-09
313	999	2006-09-09
314	999	2006-09-09
315	999	2006-09-09
316	999	2006-09-09
317	999	2006-09-09
318	999	2006-09-09
319	999	2006-09-09
320	999	2006-09-10
321	999	2006-09-10
322	999	2006-09-10
323	999	2006-09-10
324	999	2006-09-10
325	999	2006-09-10
326	999	2006-09-10
329	999	2006-09-10
330	999	2006-09-10
331	999	2006-09-10
332	999	2006-09-10
333	999	2006-09-10
334	999	2006-09-10
335	999	2006-09-10
336	999	2006-09-11
337	999	2006-09-11
338	999	2006-09-11
339	999	2006-09-11
340	999	2006-09-11
341	999	2006-09-11
342	999	2006-09-11
343	999	2006-09-11
344	999	2006-09-11
345	999	2006-09-11
346	999	2006-09-11
347	999	2006-09-11
348	999	2006-09-11
349	999	2006-09-11
350	999	2006-09-11
351	999	2006-09-11
352	999	2006-09-12
353	999	2006-09-12
354	999	2006-09-12
355	999	2006-09-12
356	999	2006-09-12
357	999	2006-09-12
358	999	2006-09-12
359	999	2006-09-12
360	999	2006-09-12
361	999	2006-09-12
362	999	2006-09-12
363	999	2006-09-12
364	999	2006-09-12
365	999	2006-09-13
366	999	2006-09-13
367	999	2006-09-13
368	999	2006-09-13
369	999	2006-09-13
370	999	2006-09-13
371	999	2006-09-13
372	999	2006-09-13
373	999	2006-09-13
374	999	2006-09-13
375	999	2006-09-13
376	999	2006-09-13
379	999	2006-09-13
380	999	2006-09-13
381	999	2006-09-14
382	999	2006-09-14
383	999	2006-09-14
384	999	2006-09-14
385	999	2006-09-14
386	999	2006-09-14
387	999	2006-09-14
388	999	2006-09-14
389	999	2006-09-14
390	999	2006-09-14
391	999	2006-09-14
392	999	2006-09-14
393	999	2006-09-14
394	999	2006-09-14
395	999	2006-09-14
396	999	2006-09-14
397	999	2006-09-15
398	999	2006-09-15
399	999	2006-09-15
400	999	2006-09-15
401	999	2006-09-15
402	999	2006-09-15
403	999	2006-09-15
404	999	2006-09-15
405	999	2006-09-15
406	999	2006-09-15
407	999	2006-09-15
408	999	2006-09-15
409	999	2006-09-15
410	999	2006-09-15
411	999	2006-09-15
412	999	2006-09-15
413	999	2006-09-16
414	999	2006-09-16
415	999	2006-09-16
416	999	2006-09-16
417	999	2006-09-16
418	999	2006-09-16
419	999	2006-09-16
420	999	2006-09-16
421	999	2006-09-16
422	999	2006-09-16
423	999	2006-09-16
424	999	2006-09-16
425	999	2006-09-16
426	999	2006-09-17
429	999	2006-09-17
430	999	2006-09-17
431	999	2006-09-17
432	999	2006-09-17
433	999	2006-09-17
434	999	2006-09-17
435	999	2006-09-17
436	999	2006-09-17
437	999	2006-09-17
438	999	2006-09-17
439	999	2006-09-17
440	999	2006-09-17
441	999	2006-09-17
442	999	2006-09-18
443	999	2006-09-18
444	999	2006-09-18
445	999	2006-09-18
446	999	2006-09-18
447	999	2006-09-18
448	999	2006-09-18
449	999	2006-09-18
450	999	2006-09-18
451	999	2006-09-18
452	999	2006-09-18
453	999	2006-09-18
454	999	2006-09-18
455	999	2006-09-18
456	999	2006-09-18
457	999	2006-09-18
458	999	2006-09-19
459	999	2006-09-19
460	999	2006-09-19
461	999	2006-09-19
462	999	2006-09-19
463	999	2006-09-19
464	999	2006-09-19
465	999	2006-09-19
466	999	2006-09-19
467	999	2006-09-19
468	999	2006-09-19
469	999	2006-09-19
470	999	2006-09-19
471	999	2006-09-19
472	999	2006-09-19
473	999	2006-09-19
474	999	2006-09-20
475	999	2006-09-20
476	999	2006-09-20
479	999	2006-09-20
480	999	2006-09-20
481	999	2006-09-20
482	999	2006-09-20
483	999	2006-09-20
484	999	2006-09-20
485	999	2006-09-20
486	999	2006-09-20
487	999	2006-09-20
488	999	2006-09-20
489	999	2006-09-20
490	999	2006-09-21
491	999	2006-09-21
492	999	2006-09-21
493	999	2006-09-21
494	999	2006-09-21
495	999	2006-09-21
496	999	2006-09-21
497	999	2006-09-21
498	999	2006-09-21
499	999	2006-09-21
500	999	2006-09-21
501	999	2006-09-21
502	999	2006-09-21
503	999	2006-09-22
504	999	2006-09-22
505	999	2006-09-22
506	999	2006-09-22
507	999	2006-09-22
508	999	2006-09-22
509	999	2006-09-22
510	999	2006-09-22
511	999	2006-09-22
512	999	2006-09-22
513	999	2006-09-22
514	999	2006-09-22
515	999	2006-09-22
516	999	2006-09-23
517	999	2006-09-23
518	999	2006-09-23
519	999	2006-09-23
520	999	2006-09-23
521	999	2006-09-23
522	999	2006-09-23
523	999	2006-09-23
524	999	2006-09-24
525	999	2006-09-24
526	999	2006-09-24
529	999	2006-09-24
530	999	2006-09-24
531	999	2006-09-24
532	999	2006-09-24
533	999	2006-09-24
534	999	2006-09-24
535	999	2006-09-24
536	999	2006-09-24
537	999	2006-09-24
538	999	2006-09-24
539	999	2006-09-24
540	999	2006-09-25
541	999	2006-09-25
542	999	2006-09-25
543	999	2006-09-25
544	999	2006-09-25
545	999	2006-09-25
546	999	2006-09-25
547	999	2006-09-25
548	999	2006-09-25
549	999	2006-09-25
550	999	2006-09-25
551	999	2006-09-25
552	999	2006-09-25
553	999	2006-09-25
554	999	2006-09-25
555	999	2006-09-25
556	999	2006-09-26
557	999	2006-09-26
558	999	2006-09-26
559	999	2006-09-26
560	999	2006-09-26
561	999	2006-09-26
562	999	2006-09-26
563	999	2006-09-26
564	999	2006-09-26
565	999	2006-09-26
566	999	2006-09-26
567	999	2006-09-26
568	999	2006-09-26
569	999	2006-09-26
570	999	2006-09-26
571	999	2006-09-26
572	999	2006-09-27
573	999	2006-09-27
574	999	2006-09-27
575	999	2006-09-27
576	999	2006-09-27
579	999	2006-09-27
580	999	2006-09-27
581	999	2006-09-27
582	999	2006-09-27
583	999	2006-09-27
584	999	2006-09-27
585	999	2006-09-27
586	999	2006-09-27
587	999	2006-09-27
588	999	2006-09-28
589	999	2006-09-28
590	999	2006-09-28
591	999	2006-09-28
592	999	2006-09-28
593	999	2006-09-28
594	999	2006-09-28
595	999	2006-09-28
596	999	2006-09-28
597	999	2006-09-28
598	999	2006-09-28
599	999	2006-09-28
600	999	2006-09-28
601	999	2006-09-29
602	999	2006-09-29
603	999	2006-09-29
604	999	2006-09-29
605	999	2006-09-29
606	999	2006-09-29
607	999	2006-09-29
608	999	2006-09-29
609	999	2006-09-29
610	999	2006-09-29
611	999	2006-09-29
612	999	2006-09-29
613	999	2006-09-29
614	999	2006-09-29
615	999	2006-09-29
616	999	2006-09-29
617	999	2006-09-29
618	999	2006-09-30
619	999	2006-09-30
620	999	2006-09-30
621	999	2006-09-30
622	999	2006-09-30
623	999	2006-09-30
624	999	2006-09-30
625	999	2006-09-30
626	999	2006-09-30
629	999	2006-09-30
630	999	2006-09-30
631	999	2006-09-30
632	999	2006-09-30
633	999	2006-09-30
634	999	2006-10-01
635	999	2006-10-01
636	999	2006-10-01
637	999	2006-10-01
638	999	2006-10-01
639	999	2006-10-01
640	999	2006-10-01
641	999	2006-10-01
642	999	2006-10-01
643	999	2006-10-01
644	999	2006-10-01
645	999	2006-10-01
646	999	2006-10-01
647	999	2006-10-02
648	999	2006-10-02
649	999	2006-10-02
650	999	2006-10-02
651	999	2006-10-02
652	999	2006-10-02
653	999	2006-10-02
654	999	2006-10-02
655	999	2006-10-02
656	999	2006-10-02
657	999	2006-10-02
658	999	2006-10-02
659	999	2006-10-02
660	999	2006-10-02
661	999	2006-10-02
662	999	2006-10-02
663	999	2006-10-03
664	999	2006-10-03
665	999	2006-10-03
666	999	2006-10-03
667	999	2006-10-03
668	999	2006-10-03
669	999	2006-10-03
670	999	2006-10-03
671	999	2006-10-03
672	999	2006-10-03
673	999	2006-10-03
674	999	2006-10-03
675	999	2006-10-03
676	999	2006-10-03
679	999	2006-10-04
680	999	2006-10-04
681	999	2006-10-04
682	999	2006-10-04
683	999	2006-10-04
684	999	2006-10-04
685	999	2006-10-04
686	999	2006-10-04
687	999	2006-10-04
688	999	2006-10-04
689	999	2006-10-04
690	999	2006-10-04
691	999	2006-10-04
692	999	2006-10-04
693	999	2006-10-04
694	999	2006-10-04
695	999	2006-10-05
696	999	2006-10-05
697	999	2006-10-05
698	999	2006-10-05
699	999	2006-10-05
700	999	2006-10-05
701	999	2006-10-05
702	999	2006-10-05
703	999	2006-10-05
704	999	2006-10-05
705	999	2006-10-05
706	999	2006-10-05
707	999	2006-10-05
708	999	2006-10-05
709	999	2006-10-05
710	999	2006-10-05
711	999	2006-10-06
712	999	2006-10-06
713	999	2006-10-06
714	999	2006-10-06
715	999	2006-10-06
716	999	2006-10-06
717	999	2006-10-06
718	999	2006-10-06
719	999	2006-10-06
720	999	2006-10-06
721	999	2006-10-06
722	999	2006-10-06
723	999	2006-10-06
724	999	2006-10-06
725	999	2006-10-06
726	999	2006-10-06
729	999	2006-10-07
730	999	2006-10-07
731	999	2006-10-07
732	999	2006-10-07
733	999	2006-10-07
734	999	2006-10-07
735	999	2006-10-07
736	999	2006-10-07
737	999	2006-10-07
738	999	2006-10-07
739	999	2006-10-07
740	999	2006-10-07
741	999	2006-10-07
742	999	2006-10-07
743	999	2006-10-08
744	999	2006-10-08
745	999	2006-10-08
746	999	2006-10-08
747	999	2006-10-08
748	999	2006-10-08
749	999	2006-10-08
750	999	2006-10-08
751	999	2006-10-08
752	999	2006-10-08
753	999	2006-10-08
754	999	2006-10-08
755	999	2006-10-08
756	999	2006-10-08
757	999	2006-10-08
758	999	2006-10-08
759	999	2006-10-09
760	999	2006-10-09
761	999	2006-10-09
762	999	2006-10-09
763	999	2006-10-09
764	999	2006-10-09
765	999	2006-10-09
766	999	2006-10-09
767	999	2006-10-09
768	999	2006-10-09
769	999	2006-10-09
770	999	2006-10-09
771	999	2006-10-09
772	999	2006-10-09
773	999	2006-10-09
774	999	2006-10-09
775	999	2006-10-10
776	999	2006-10-10
779	999	2006-10-10
780	999	2006-10-11
781	999	2006-10-11
782	999	2006-10-11
783	999	2006-10-11
784	999	2006-10-11
785	999	2006-10-11
786	999	2006-10-11
787	999	2006-10-11
788	999	2006-10-11
789	999	2006-10-11
790	999	2006-10-11
791	999	2006-10-11
792	999	2006-10-11
793	999	2006-10-11
794	999	2006-10-11
795	999	2006-10-12
796	999	2006-10-12
797	999	2006-10-12
798	999	2006-10-12
799	999	2006-10-12
800	999	2006-10-12
801	999	2006-10-12
802	999	2006-10-12
803	999	2006-10-12
804	999	2006-10-12
805	999	2006-10-12
806	999	2006-10-12
807	999	2006-10-12
808	999	2006-10-12
809	999	2006-10-12
810	999	2006-10-13
811	999	2006-10-13
812	999	2006-10-13
813	999	2006-10-13
814	999	2006-10-13
815	999	2006-10-13
816	999	2006-10-13
817	999	2006-10-13
818	999	2006-10-13
819	999	2006-10-13
820	999	2006-10-13
821	999	2006-10-13
822	999	2006-10-13
823	999	2006-10-14
824	999	2006-10-14
825	999	2006-10-14
826	999	2006-10-14
829	999	2006-10-14
830	999	2006-10-14
831	999	2006-10-15
832	999	2006-10-15
833	999	2006-10-15
834	999	2006-10-15
835	999	2006-10-15
836	999	2006-10-15
837	999	2006-10-15
838	999	2006-10-15
839	999	2006-10-15
840	999	2006-10-15
841	999	2006-10-15
842	999	2006-10-15
843	999	2006-10-15
844	999	2006-10-15
845	999	2006-10-15
846	999	2006-10-15
847	999	2006-10-16
848	999	2006-10-16
849	999	2006-10-16
850	999	2006-10-16
851	999	2006-10-16
852	999	2006-10-16
853	999	2006-10-16
854	999	2006-10-16
855	999	2006-10-16
856	999	2006-10-16
857	999	2006-10-16
858	999	2006-10-16
859	999	2006-10-16
860	999	2006-10-17
861	999	2006-10-17
862	999	2006-10-17
863	999	2006-10-17
864	999	2006-10-17
865	999	2006-10-17
866	999	2006-10-17
867	999	2006-10-17
868	999	2006-10-17
869	999	2006-10-17
870	999	2006-10-18
871	999	2006-10-18
872	999	2006-10-18
873	999	2006-10-18
874	999	2006-10-18
875	999	2006-10-18
876	999	2006-10-18
879	999	2006-10-18
880	999	2006-10-18
881	999	2006-10-18
882	999	2006-10-18
883	999	2006-10-18
884	999	2006-10-18
885	999	2006-10-18
886	999	2006-10-19
887	999	2006-10-19
888	999	2006-10-19
889	999	2006-10-19
890	999	2006-10-19
891	999	2006-10-19
892	999	2006-10-19
893	999	2006-10-19
894	999	2006-10-19
895	999	2006-10-19
896	999	2006-10-19
897	999	2006-10-19
898	999	2006-10-19
899	999	2006-10-20
900	999	2006-10-20
901	999	2006-10-20
902	999	2006-10-20
903	999	2006-10-20
904	999	2006-10-20
905	999	2006-10-20
906	999	2006-10-20
907	999	2006-10-20
908	999	2006-10-20
909	999	2006-10-20
910	999	2006-10-20
911	999	2006-10-20
912	999	2006-10-20
913	999	2006-10-20
914	999	2006-10-21
915	999	2006-10-21
916	999	2006-10-21
917	999	2006-10-21
918	999	2006-10-21
919	999	2006-10-21
920	999	2006-10-21
921	999	2006-10-21
922	999	2006-10-21
923	999	2006-10-21
924	999	2006-10-21
925	999	2006-10-21
926	999	2006-10-21
929	999	2006-10-22
930	999	2006-10-22
931	999	2006-10-22
932	999	2006-10-22
933	999	2006-10-22
934	999	2006-10-22
935	999	2006-10-22
936	999	2006-10-22
937	999	2006-10-22
938	999	2006-10-22
939	999	2006-10-22
940	999	2006-10-22
941	999	2006-10-22
942	999	2006-10-23
943	999	2006-10-23
944	999	2006-10-23
945	999	2006-10-23
946	999	2006-10-23
947	999	2006-10-23
948	999	2006-10-23
949	999	2006-10-23
950	999	2006-10-23
951	999	2006-10-23
952	999	2006-10-23
953	999	2006-10-23
954	999	2006-10-23
955	999	2006-10-23
956	999	2006-10-23
957	999	2006-10-23
958	999	2006-10-24
959	999	2006-10-24
960	999	2006-10-24
961	999	2006-10-24
962	999	2006-10-24
963	999	2006-10-24
964	999	2006-10-24
965	999	2006-10-24
966	999	2006-10-24
967	999	2006-10-24
968	999	2006-10-24
969	999	2006-10-24
970	999	2006-10-25
971	999	2006-10-25
972	999	2006-10-25
973	999	2006-10-25
974	999	2006-10-25
975	999	2006-10-25
976	999	2006-10-25
979	999	2006-10-25
980	999	2006-10-25
981	999	2006-10-25
982	999	2006-10-25
983	999	2006-10-26
984	999	2006-10-26
985	999	2006-10-26
986	999	2006-10-26
987	999	2006-10-26
988	999	2006-10-26
989	999	2006-10-26
990	999	2006-10-26
991	999	2006-10-27
992	999	2006-10-27
993	999	2006-10-27
994	999	2006-10-27
995	999	2006-10-27
996	999	2006-10-27
997	999	2006-10-27
998	999	2006-10-27
999	999	2006-10-27
1000	999	2006-10-27
1001	999	2006-10-27
1002	999	2006-10-27
1003	999	2006-10-28
1004	999	2006-10-28
1005	999	2006-10-28
1006	999	2006-10-28
1007	999	2006-10-28
1008	999	2006-10-29
1009	999	2006-10-29
1010	999	2006-10-29
1011	999	2006-10-29
1012	999	2006-10-29
1013	999	2006-10-29
1014	999	2006-10-29
1015	999	2006-10-29
1016	999	2006-10-29
1017	999	2006-10-29
1018	999	2006-10-29
1019	999	2006-10-29
1020	999	2006-10-30
1021	999	2006-10-30
1022	999	2006-10-30
1023	999	2006-10-30
1024	999	2006-10-30
1025	999	2006-10-30
1026	999	2006-10-31
1029	999	2006-10-31
1030	999	2006-10-31
1031	999	2006-10-31
1032	999	2006-10-31
1033	999	2006-10-31
1034	999	2006-10-31
1035	999	2006-10-31
1036	999	2006-10-31
1037	999	2006-10-31
1038	999	2006-10-31
1039	999	2006-11-01
1040	999	2006-11-01
1041	999	2006-11-01
1042	999	2006-11-01
1043	999	2006-11-01
1044	999	2006-11-01
1045	999	2006-11-01
1046	999	2006-11-01
1047	999	2006-11-01
1048	999	2006-11-01
1049	999	2006-11-01
1050	999	2006-11-01
1051	999	2006-11-01
1052	999	2006-11-02
1053	999	2006-11-02
1054	999	2006-11-02
1055	999	2006-11-02
1056	999	2006-11-02
1057	999	2006-11-02
1058	999	2006-11-02
1059	999	2006-11-02
1060	999	2006-11-02
1061	999	2006-11-02
1062	999	2006-11-02
1063	999	2006-11-02
1064	999	2006-11-02
1065	999	2006-11-02
1066	999	2006-11-03
1067	999	2006-11-03
1068	999	2006-11-03
1069	999	2006-11-03
1070	999	2006-11-03
1071	999	2006-11-03
1072	999	2006-11-04
1073	999	2006-11-04
1074	999	2006-11-04
1075	999	2006-11-04
1076	999	2006-11-07
1079	999	2006-11-07
1080	999	2006-11-07
1081	999	2006-11-07
1082	999	2006-11-07
1083	999	2006-11-07
1084	999	2006-11-07
1085	999	2006-11-07
1086	999	2006-11-07
1087	999	2006-11-07
1088	999	2006-11-07
1089	999	2006-11-07
1090	999	2006-11-08
1091	999	2006-11-08
1092	999	2006-11-08
1093	999	2006-11-08
1094	999	2006-11-08
1095	999	2006-11-08
1096	999	2006-11-08
1097	999	2006-11-08
1098	999	2006-11-08
1099	999	2006-11-08
1100	999	2006-11-08
1101	999	2006-11-08
1102	999	2006-11-08
1103	999	2006-11-09
1104	999	2006-11-09
1105	999	2006-11-09
1106	999	2006-11-09
1107	999	2006-11-09
1108	999	2006-11-09
1109	999	2006-11-10
1110	999	2006-11-10
1111	999	2006-11-10
1112	999	2006-11-10
1113	999	2006-11-10
1114	999	2006-11-10
1115	999	2006-11-10
1116	999	2006-11-10
1117	999	2006-11-10
1118	999	2006-11-10
1119	999	2006-11-10
1120	999	2006-11-10
1121	999	2006-11-10
1122	999	2006-11-10
1123	999	2006-11-10
1124	999	2006-11-11
1125	999	2006-11-11
1126	999	2006-11-11
1129	999	2006-11-11
1130	999	2006-11-11
1131	999	2006-11-11
1132	999	2006-11-11
1133	999	2006-11-11
1134	999	2006-11-11
1135	999	2006-11-11
1136	999	2006-11-11
1137	999	2006-11-11
1138	999	2006-11-11
1139	999	2006-11-11
1140	999	2006-11-12
1141	999	2006-11-12
1142	999	2006-11-12
1143	999	2006-11-12
1144	999	2006-11-12
1145	999	2006-11-12
1146	999	2006-11-12
1147	999	2006-11-12
1148	999	2006-11-12
1149	999	2006-11-12
1150	999	2006-11-12
1151	999	2006-11-12
1152	999	2006-11-12
1153	999	2006-11-12
1154	999	2006-11-12
1155	999	2006-11-12
1156	999	2006-11-13
1157	999	2006-11-13
1158	999	2006-11-13
1159	999	2006-11-13
1160	999	2006-11-13
1161	999	2006-11-13
1162	999	2006-11-13
1163	999	2006-11-13
1164	999	2006-11-13
1165	999	2006-11-13
1166	999	2006-11-13
1167	999	2006-11-13
1168	999	2006-11-13
1169	999	2006-11-13
1170	999	2006-11-13
1171	999	2006-11-14
1172	999	2006-11-14
1173	999	2006-11-14
1174	999	2006-11-14
1175	999	2006-11-14
1176	999	2006-11-14
1179	999	2006-11-14
1180	999	2006-11-14
1181	999	2006-11-14
1182	999	2006-11-14
1183	999	2006-11-14
1184	999	2006-11-14
1185	999	2006-11-14
1186	999	2006-11-14
1187	999	2006-11-15
1188	999	2006-11-15
1189	999	2006-11-15
1190	999	2006-11-15
1191	999	2006-11-15
1192	999	2006-11-15
1193	999	2006-11-15
1194	999	2006-11-15
1195	999	2006-11-15
1196	999	2006-11-15
1197	999	2006-11-15
1198	999	2006-11-15
1199	999	2006-11-15
1200	999	2006-11-16
1201	999	2006-11-16
1202	999	2006-11-16
1203	999	2006-11-16
1204	999	2006-11-16
1205	999	2006-11-16
1206	999	2006-11-16
1207	999	2006-11-16
1208	999	2006-11-16
1209	999	2006-11-16
1210	999	2006-11-16
1211	999	2006-11-16
1212	999	2006-11-16
1213	999	2006-11-16
1214	999	2006-11-16
1215	999	2006-11-16
1216	999	2006-11-17
1217	999	2006-11-17
1218	999	2006-11-17
1219	999	2006-11-17
1220	999	2006-11-17
1221	999	2006-11-17
1222	999	2006-11-17
1223	999	2006-11-17
1224	999	2006-11-17
1225	999	2006-11-17
1226	999	2006-11-17
1229	999	2006-11-17
1230	999	2006-11-17
1231	999	2006-11-17
1232	999	2006-11-18
1233	999	2006-11-18
1234	999	2006-11-18
1235	999	2006-11-18
1236	999	2006-11-18
1237	999	2006-11-18
1238	999	2006-11-18
1239	999	2006-11-18
1240	999	2006-11-19
1241	999	2006-11-19
1242	999	2006-11-19
1243	999	2006-11-19
1244	999	2006-11-19
1245	999	2006-11-19
1246	999	2006-11-19
1247	999	2006-11-19
1248	999	2006-11-19
1249	999	2006-11-20
1250	999	2006-11-20
1251	999	2006-11-20
1252	999	2006-11-20
1253	999	2006-11-20
1254	999	2006-11-20
1255	999	2006-11-20
1256	999	2006-11-20
1257	999	2006-11-20
1258	999	2006-11-20
1259	999	2006-11-20
1260	999	2006-11-20
1261	999	2006-11-20
1262	999	2006-11-20
1263	999	2006-11-20
1264	999	2006-11-20
1265	999	2006-11-21
1266	999	2006-11-21
1267	999	2006-11-21
1268	999	2006-11-21
1269	999	2006-11-21
1270	999	2006-11-21
1271	999	2006-11-21
1272	999	2006-11-21
1273	999	2006-11-21
1274	999	2006-11-21
1275	999	2006-11-21
1276	999	2006-11-21
1279	999	2006-11-21
1280	999	2006-11-21
1281	999	2006-11-22
1282	999	2006-11-22
1283	999	2006-11-22
1284	999	2006-11-22
1285	999	2006-11-22
1286	999	2006-11-22
1287	999	2006-11-22
1288	999	2006-11-22
1289	999	2006-11-22
1290	999	2006-11-22
1291	999	2006-11-22
1292	999	2006-11-22
1293	999	2006-11-22
1294	999	2006-11-22
1295	999	2006-11-22
1296	999	2006-11-22
1297	999	2006-11-23
1298	999	2006-11-23
1299	999	2006-11-23
1300	999	2006-11-23
1301	999	2006-11-23
1302	999	2006-11-23
1303	999	2006-11-23
1304	999	2006-11-23
1305	999	2006-11-23
1306	999	2006-11-23
1307	999	2006-11-23
1308	999	2006-11-23
1309	999	2006-11-23
1310	999	2006-11-23
1311	999	2006-11-23
1312	999	2006-11-24
1313	999	2006-11-24
1314	999	2006-11-24
1315	999	2006-11-24
1316	999	2006-11-24
1317	999	2006-11-24
1318	999	2006-11-24
1319	999	2006-11-24
1320	999	2006-11-24
1321	999	2006-11-24
1322	999	2006-11-24
1323	999	2006-11-24
1324	999	2006-11-24
1325	999	2006-11-24
1326	999	2006-11-24
1329	999	2006-11-25
1330	999	2006-11-25
1331	999	2006-11-25
1332	999	2006-11-25
1333	999	2006-11-25
1334	999	2006-11-25
1335	999	2006-11-25
1336	999	2006-11-25
1337	999	2006-11-25
1338	999	2006-11-25
1339	999	2006-11-25
1340	999	2006-11-25
1341	999	2006-11-25
1342	999	2006-11-25
1343	999	2006-11-25
1344	999	2006-11-26
1345	999	2006-11-26
1346	999	2006-11-26
1347	999	2006-11-26
1348	999	2006-11-26
1349	999	2006-11-26
1350	999	2006-11-26
1351	999	2006-11-26
1352	999	2006-11-26
1353	999	2006-11-26
1354	999	2006-11-26
1355	999	2006-11-26
1356	999	2006-11-26
1357	999	2006-11-26
1358	999	2006-11-26
1359	999	2006-11-27
1360	999	2006-11-27
1361	999	2006-11-27
1362	999	2006-11-27
1363	999	2006-11-27
1364	999	2006-11-27
1365	999	2006-11-27
1366	999	2006-11-27
1367	999	2006-11-27
1368	999	2006-11-27
1369	999	2006-11-27
1370	999	2006-11-27
1371	999	2006-11-27
1372	999	2006-11-27
1373	999	2006-11-27
1374	999	2006-11-27
1375	999	2013-07-11
1376	999	2013-07-11
1379	999	2013-07-11
1380	999	2013-07-11
1381	999	2013-07-11
1382	999	2013-07-11
1383	999	2013-07-11
1384	999	2013-07-11
1385	999	2013-07-11
1386	999	2013-07-11
1387	999	2013-07-11
1388	999	2013-07-11
1389	999	2013-07-12
1390	999	2013-07-12
1391	999	2013-07-12
1392	999	2013-07-12
1393	999	2013-07-12
1394	999	2013-07-12
1395	999	2013-07-12
1396	999	2013-07-12
1397	999	2013-07-12
1398	999	2013-07-12
1399	999	2013-07-12
1400	999	2013-07-12
1401	999	2013-07-12
1402	999	2013-07-12
1403	999	2013-07-12
1404	999	2013-07-12
1405	999	2013-07-12
1406	999	2013-07-13
1407	999	2013-07-13
1408	999	2013-07-13
1409	999	2013-07-13
1410	999	2013-07-13
1411	999	2013-07-13
1412	999	2013-07-13
1413	999	2013-07-13
1414	999	2013-07-13
1415	999	2013-07-13
1416	999	2013-07-13
1417	999	2013-07-14
1418	999	2013-07-14
1419	999	2013-07-15
1420	999	2013-07-15
1421	999	2013-07-15
1422	999	2013-07-15
1423	999	2013-07-15
1424	999	2013-07-15
1425	999	2013-07-15
1426	999	2013-07-16
1429	999	2013-07-16
1430	999	2013-07-16
1431	999	2013-07-17
1432	999	2013-07-17
1433	999	2013-07-17
1434	999	2013-07-18
1435	999	2013-07-18
1436	999	2013-07-18
1437	999	2013-07-19
1438	999	2013-07-19
1439	999	2013-07-19
1440	999	2013-07-19
1441	999	2013-07-19
1442	999	2013-07-19
1443	999	2013-07-19
1444	999	2013-07-19
1445	999	2013-07-19
1446	999	2013-07-19
1447	999	2013-07-19
1448	999	2013-07-19
1449	999	2013-07-19
1450	999	2013-07-19
1451	999	2013-07-19
1452	999	2013-07-20
1453	999	2013-07-20
1454	999	2013-07-20
1455	999	2013-07-20
1456	999	2013-07-20
1457	999	2013-07-20
1458	999	2013-07-20
1459	999	2013-07-20
1460	999	2013-07-20
1461	999	2013-07-20
1462	999	2013-07-20
1463	999	2013-07-21
1464	999	2013-07-21
1465	999	2013-07-21
1466	999	2013-07-21
1467	999	2013-07-21
1468	999	2013-07-21
1469	999	2013-07-21
1470	999	2013-07-22
1471	999	2013-07-22
1472	999	2013-07-22
1473	999	2013-07-22
1474	999	2013-07-22
1475	999	2013-07-22
1476	999	2013-07-22
1479	999	2013-07-22
1480	999	2013-07-22
1481	999	2013-07-23
1482	999	2013-07-23
1483	999	2013-07-23
1484	999	2013-07-23
1485	999	2013-07-23
1486	999	2013-07-23
1487	999	2013-07-23
1488	999	2013-07-23
1489	999	2013-07-23
1490	999	2013-07-23
1491	999	2013-07-23
1492	999	2013-07-24
1493	999	2013-07-24
1494	999	2013-07-24
1495	999	2013-07-24
1496	999	2013-07-24
1497	999	2013-07-24
1498	999	2013-07-24
1499	999	2013-07-24
1500	999	2013-07-24
1501	999	2013-07-24
1502	999	2013-07-25
1503	999	2013-07-25
1504	999	2013-07-25
1505	999	2013-07-25
1506	999	2013-07-25
1507	999	2013-07-25
1508	999	2013-07-25
1509	999	2013-07-25
1510	999	2013-07-25
1511	999	2013-07-25
1512	999	2013-07-25
1513	999	2013-07-26
1514	999	2013-07-26
1515	999	2013-07-26
1516	999	2013-07-26
1517	999	2013-07-26
1518	999	2013-07-26
1519	999	2013-07-26
1520	999	2013-07-26
1521	999	2013-07-26
1522	999	2013-07-26
1523	999	2013-07-26
1524	999	2013-07-26
1525	999	2013-07-26
1526	999	2013-07-27
1529	999	2013-07-27
1530	999	2013-07-27
1531	999	2013-07-27
1532	999	2013-07-27
1533	999	2013-07-27
1534	999	2013-07-27
1535	999	2013-07-27
1536	999	2013-07-27
1537	999	2013-07-27
1538	999	2013-07-27
1539	999	2013-07-27
1540	999	2013-07-27
1541	999	2013-07-28
1542	999	2013-07-28
1543	999	2013-07-28
1544	999	2013-07-28
1545	999	2013-07-28
1546	999	2013-07-28
1547	999	2013-07-28
1548	999	2013-07-28
1549	999	2013-07-28
1550	999	2013-07-28
1551	999	2013-07-28
1552	999	2013-07-28
1553	999	2013-07-28
1554	999	2013-07-28
1555	999	2013-07-28
1556	999	2013-07-28
1557	999	2013-07-28
1558	999	2013-07-29
1559	999	2013-07-29
1560	999	2013-07-29
1561	999	2013-07-29
1562	999	2013-07-29
1563	999	2013-07-29
1564	999	2013-07-29
1565	999	2013-07-29
1566	999	2013-07-29
1567	999	2013-07-29
1568	999	2013-07-29
1569	999	2013-07-29
1570	999	2013-07-29
1571	999	2013-07-29
1572	999	2013-07-30
1573	999	2013-07-30
1574	999	2013-07-30
1575	999	2013-07-30
1576	999	2013-07-30
1579	999	2013-07-30
1580	999	2013-07-30
1581	999	2013-07-30
1582	999	2013-07-30
1583	999	2013-07-31
1584	999	2013-07-31
1585	999	2013-07-31
1586	999	2013-07-31
1587	999	2013-07-31
1588	999	2013-07-31
1589	999	2013-07-31
1590	999	2013-07-31
1591	999	2013-07-31
1592	999	2013-07-31
1593	999	2013-08-01
1594	999	2013-08-01
1595	999	2013-08-01
1596	999	2013-08-01
1597	999	2013-08-01
1598	999	2013-08-01
1599	999	2013-08-01
1600	999	2013-08-01
1601	999	2013-08-01
1602	999	2013-08-01
1603	999	2013-08-01
1604	999	2013-08-01
1605	999	2013-08-01
1606	999	2013-08-02
1607	999	2013-08-02
1608	999	2013-08-02
1609	999	2013-08-02
1610	999	2013-08-02
1611	999	2013-08-02
1612	999	2013-08-02
1613	999	2013-08-02
1614	999	2013-08-02
1615	999	2013-08-02
1616	999	2013-08-02
1617	999	2013-08-02
1618	999	2013-08-02
1619	999	2013-08-03
1620	999	2013-08-03
1621	999	2013-08-03
1622	999	2013-08-03
1623	999	2013-08-03
1624	999	2013-08-03
1625	999	2013-08-03
1626	999	2013-08-03
1628	999	2013-08-03
1629	999	2013-08-04
1630	999	2013-08-04
1631	999	2013-08-04
1632	999	2013-08-04
1633	999	2013-08-04
1634	999	2013-08-04
1635	999	2013-08-04
1636	999	2013-08-05
1637	999	2013-08-05
1638	999	2013-08-05
1639	999	2013-08-05
1640	999	2013-08-05
1641	999	2013-08-05
1642	999	2013-08-05
1643	999	2013-08-05
1644	999	2013-08-05
1645	999	2013-08-05
1646	999	2013-08-05
1647	999	2013-08-05
1648	999	2013-08-05
1649	999	2013-08-05
1650	999	2013-08-06
1651	999	2013-08-06
1652	999	2013-08-06
1675	999	2013-08-07
1676	999	2013-08-07
1677	999	2013-08-07
1678	999	2013-08-07
1679	999	2013-08-07
1680	999	2013-08-08
1696	999	2013-08-09
1697	999	2013-08-09
1698	999	2013-08-09
1699	999	2013-08-09
1700	999	2013-08-09
1701	999	2013-08-09
1702	999	2013-08-09
1703	999	2013-08-09
1704	999	2013-08-09
1705	999	2013-08-09
1706	999	2013-08-10
1707	999	2013-08-10
1708	999	2013-08-10
1709	999	2013-08-10
1710	999	2013-08-10
1711	999	2013-08-10
1712	999	2013-08-10
1713	999	2013-08-10
1714	999	2013-08-10
1715	999	2013-08-10
1716	999	2013-08-10
1725	999	2013-08-11
1726	999	2013-08-11
1727	999	2013-08-11
1728	999	2013-08-11
1729	999	2013-08-12
1730	999	2013-08-12
1731	999	2013-08-12
1732	999	2013-08-12
1733	999	2013-08-12
1734	999	2013-08-12
1735	999	2013-08-12
1736	999	2013-08-12
1737	999	2013-08-13
1738	999	2013-08-13
1739	999	2013-08-13
1740	999	2013-08-13
1741	999	2013-08-13
1742	999	2013-08-13
1743	999	2013-08-13
1744	999	2013-08-13
1745	999	2013-08-13
1746	999	2013-08-13
1747	999	2013-08-13
1748	999	2013-08-13
1749	999	2013-08-14
1750	999	2013-08-14
1751	999	2013-08-14
1752	999	2013-08-14
1753	999	2013-08-14
1754	999	2013-08-14
1755	999	2013-08-15
1756	999	2013-08-15
1757	999	2013-08-15
1758	999	2013-08-15
1759	999	2013-08-15
1760	999	2013-08-15
1761	999	2013-08-16
1762	999	2013-08-16
1763	999	2013-08-16
1764	999	2013-08-16
1765	999	2013-08-16
1766	999	2013-08-16
1767	999	2013-08-16
1768	999	2013-08-16
1769	999	2013-08-16
1770	999	2013-08-16
1771	999	2013-08-17
1772	999	2013-08-17
1773	999	2013-08-17
1774	999	2013-08-17
1777	999	2013-08-17
1778	999	2013-08-17
1779	999	2013-08-17
1780	999	2013-08-17
1781	999	2013-08-17
1782	999	2013-08-17
1783	999	2013-08-18
1784	999	2013-08-18
1785	999	2013-08-18
1786	999	2013-08-18
1787	999	2013-08-18
1788	999	2013-08-19
1789	999	2013-08-19
1790	999	2013-08-19
1791	999	2013-08-19
1792	999	2013-08-19
1793	999	2013-08-19
1794	999	2013-08-19
1795	999	2013-08-19
1796	999	2013-08-19
1797	999	2013-08-19
1798	999	2013-08-19
1799	999	2013-08-20
1800	999	2013-08-20
1801	999	2013-08-20
1802	999	2013-08-20
1803	999	2013-08-20
1804	999	2013-08-20
1805	999	2013-08-20
1806	999	2013-08-20
1807	999	2013-08-20
1808	999	2013-08-20
1809	999	2013-08-20
1810	999	2013-08-20
1811	999	2013-08-20
1812	999	2013-08-20
1813	999	2013-08-20
1814	999	2013-08-21
1815	999	2013-08-21
1816	999	2013-08-21
1817	999	2013-08-21
1818	999	2013-08-21
1819	999	2013-08-21
1820	999	2013-08-21
1821	999	2013-08-21
1822	999	2013-08-21
1823	999	2013-08-21
1824	999	2013-08-21
1827	999	2013-08-22
1828	999	2013-08-22
1829	999	2013-08-22
1830	999	2013-08-22
1831	999	2013-08-22
1832	999	2013-08-22
1833	999	2013-08-22
1834	999	2013-08-22
1835	999	2013-08-23
1836	999	2013-08-23
1837	999	2013-08-23
1838	999	2013-08-23
1839	999	2013-08-23
1840	999	2013-08-23
1841	999	2013-08-23
1842	999	2013-08-23
1843	999	2013-08-23
1844	999	2013-08-23
1845	999	2013-08-23
1846	999	2013-08-23
1847	999	2013-08-23
1848	999	2013-08-23
1849	999	2013-08-23
1850	999	2013-08-23
1851	999	2013-08-23
1852	999	2013-08-23
1853	999	2013-08-24
1854	999	2013-08-24
1855	999	2013-08-24
1856	999	2013-08-24
1857	999	2013-08-24
1858	999	2013-08-24
1859	999	2013-08-24
1860	999	2013-08-24
1861	999	2013-08-24
1862	999	2013-08-24
1863	999	2013-08-24
1864	999	2013-08-24
1865	999	2013-08-24
1866	999	2013-08-24
1867	999	2013-08-24
1868	999	2013-08-24
1869	999	2013-08-24
1870	999	2013-08-24
1871	999	2013-08-24
1872	999	2013-08-25
1873	999	2013-08-25
1874	999	2013-08-25
18	999	2006-08-19
19	999	2006-08-20
20	999	2006-08-20
21	999	2006-08-20
22	999	2006-08-21
23	999	2006-08-21
24	999	2006-08-21
1875	999	2013-08-25
1876	999	2013-08-25
1877	999	2013-08-25
1878	999	2013-08-25
1879	999	2013-08-25
1880	999	2013-08-25
1881	999	2013-08-25
1882	999	2013-08-25
1883	999	2013-08-25
1884	999	2013-08-26
1885	999	2013-08-26
1894	999	2013-08-26
1895	999	2013-08-26
1896	999	2013-08-26
1897	999	2013-08-26
1898	999	2013-08-26
1899	999	2013-08-27
1900	999	2013-08-27
1901	999	2013-08-27
1902	999	2013-08-27
1903	999	2013-08-27
1904	999	2013-08-27
1905	999	2013-08-27
1906	999	2013-08-27
1907	999	2013-08-27
1908	999	2013-08-27
1909	999	2013-08-27
1910	999	2013-08-28
1911	999	2013-08-28
1912	999	2013-08-28
1913	999	2013-08-28
1914	999	2013-08-28
1915	999	2013-08-28
1916	999	2013-08-28
1917	999	2013-08-28
1918	999	2013-08-28
1919	999	2013-08-28
1920	999	2013-08-28
1921	999	2013-08-28
1922	999	2013-08-28
1923	999	2013-08-29
1924	999	2013-08-29
1925	999	2013-08-29
1926	999	2013-08-29
1927	999	2013-08-29
1928	999	2013-08-29
1929	999	2013-08-29
1930	999	2013-08-29
1931	999	2013-08-29
1932	999	2013-08-29
1933	999	2013-08-29
1934	999	2013-08-29
1935	999	2013-08-29
1936	999	2013-08-29
1937	999	2013-08-29
1938	999	2013-08-29
1939	999	2013-08-29
1940	999	2013-08-30
1653	999	2013-08-06
1654	999	2013-08-06
1655	999	2013-08-06
1656	999	2013-08-06
1657	999	2013-08-06
1658	999	2013-08-06
1659	999	2013-08-06
1660	999	2013-08-06
1661	999	2013-08-06
1662	999	2013-08-06
1663	999	2013-08-06
1664	999	2013-08-07
1665	999	2013-08-07
1666	999	2013-08-07
1667	999	2013-08-07
1668	999	2013-08-07
1669	999	2013-08-07
1670	999	2013-08-07
1671	999	2013-08-07
1672	999	2013-08-07
1673	999	2013-08-07
1674	999	2013-08-07
1941	999	2013-08-30
1942	999	2013-08-30
1943	999	2013-08-30
1944	999	2013-08-30
1945	999	2013-08-30
1946	999	2013-08-30
1947	999	2013-08-30
1948	999	2013-08-30
1949	999	2013-08-30
1950	999	2013-08-30
1951	999	2013-08-30
1952	999	2013-08-31
1953	999	2013-08-31
1954	999	2013-08-31
1955	999	2013-08-31
1956	999	2013-08-31
1957	999	2013-08-31
1958	999	2013-08-31
1959	999	2013-08-31
1960	999	2013-08-31
1961	999	2013-08-31
1962	999	2013-08-31
1963	999	2013-08-31
1964	999	2013-08-31
1965	999	2013-09-01
1966	999	2013-09-01
1967	999	2013-09-01
1968	999	2013-09-01
1969	999	2013-09-01
1970	999	2013-09-01
1971	999	2013-09-01
1972	999	2013-09-01
1973	999	2013-09-01
1974	999	2013-09-02
1975	999	2013-09-02
1976	999	2013-09-02
1977	999	2013-09-02
1978	999	2013-09-02
1979	999	2013-09-02
1980	999	2013-09-02
1981	999	2013-09-02
1982	999	2013-09-02
1983	999	2013-09-02
1984	999	2013-09-02
1985	999	2013-09-02
1986	999	2013-09-03
1987	999	2013-09-03
1988	999	2013-09-03
1989	999	2013-09-03
1990	999	2013-09-03
1991	999	2013-09-03
1992	999	2013-09-03
1993	999	2013-09-03
1994	999	2013-09-03
1995	999	2013-09-03
1996	999	2013-09-03
1997	999	2013-09-03
1998	999	2013-09-03
1999	999	2013-09-04
2000	999	2013-09-04
2001	999	2013-09-04
2002	999	2013-09-04
2003	999	2013-09-04
2004	999	2013-09-04
2005	999	2013-09-04
2006	999	2013-09-04
2007	999	2013-09-04
2008	999	2013-09-04
2009	999	2013-09-04
2010	999	2013-09-04
2011	999	2013-09-04
2012	999	2013-09-04
2013	999	2013-09-04
2014	999	2013-09-05
2015	999	2013-09-05
2016	999	2013-09-05
2017	999	2013-09-05
2018	999	2013-09-05
2019	999	2013-09-05
2020	999	2013-09-05
2021	999	2013-09-05
2022	999	2013-09-05
2023	999	2013-09-05
2024	999	2013-09-05
2025	999	2013-09-05
2026	999	2013-09-05
2027	999	2013-09-05
2028	999	2013-09-05
2029	999	2013-09-05
2030	999	2013-09-06
2031	999	2013-09-06
2032	999	2013-09-06
2033	999	2013-09-06
2034	999	2013-09-06
2035	999	2013-09-06
2036	999	2013-09-06
2037	999	2013-09-06
2038	999	2013-09-06
2039	999	2013-09-07
2040	999	2013-09-07
2041	999	2013-09-07
2042	999	2013-09-07
2043	999	2013-09-07
2044	999	2013-09-07
2045	999	2013-09-07
2046	999	2013-09-07
2047	999	2013-09-08
2048	999	2013-09-08
2049	999	2013-09-08
2050	999	2013-09-08
2051	999	2013-09-08
2052	999	2013-09-08
2053	999	2013-09-08
2054	999	2013-09-08
2055	999	2013-09-09
2056	999	2013-09-09
2057	999	2013-09-09
2058	999	2013-09-09
2059	999	2013-09-09
2060	999	2013-09-09
2061	999	2013-09-09
2062	999	2013-09-09
2063	999	2013-09-09
2064	999	2013-09-09
2065	999	2013-09-09
2066	999	2013-09-10
2067	999	2013-09-10
2068	999	2013-09-10
2069	999	2013-09-10
2070	999	2013-09-11
2071	999	2013-09-11
2072	999	2013-09-11
2073	999	2013-09-11
2074	999	2013-09-11
2075	999	2013-09-11
2076	999	2013-09-11
2077	999	2013-09-12
2078	999	2013-09-12
2079	999	2013-09-12
2080	999	2013-09-12
2081	999	2013-09-12
2082	999	2013-09-13
2083	999	2013-09-13
2084	999	2013-09-14
2085	999	2013-09-14
2086	999	2013-09-15
2087	999	2013-09-15
2088	999	2013-09-17
2089	999	2013-09-17
2090	999	2013-09-17
2091	999	2013-09-18
2092	999	2013-09-18
2093	999	2013-09-18
2094	999	2013-09-18
2095	999	2013-09-18
2096	999	2013-09-19
2097	999	2013-09-19
2098	999	2013-09-19
2099	999	2013-09-19
2100	999	2013-09-20
2101	999	2013-09-20
2102	999	2013-09-20
2103	999	2013-09-20
2104	999	2013-09-20
2105	999	2013-09-20
2106	999	2013-09-20
2107	999	2013-09-20
2108	999	2013-09-21
2109	999	2013-09-21
2110	999	2013-09-21
2111	999	2013-09-21
2112	999	2013-09-22
2113	999	2013-09-22
2114	999	2013-09-22
2115	999	2013-09-23
2116	999	2013-09-23
2117	999	2013-09-23
2118	999	2013-09-23
2119	999	2013-09-23
2120	999	2013-09-24
2121	999	2013-09-24
2122	999	2013-09-24
2123	999	2013-09-24
2124	999	2013-09-24
2125	999	2013-09-24
2126	999	2013-09-24
2127	999	2013-09-24
2128	999	2013-09-25
2129	999	2013-09-25
2130	999	2013-09-25
2131	999	2013-09-25
2132	999	2013-09-25
2133	999	2013-09-25
2134	999	2013-09-25
2135	999	2013-09-25
2136	999	2013-09-25
2137	999	2013-09-25
2138	999	2013-09-25
2139	999	2013-09-26
2140	999	2013-09-26
2141	999	2013-09-26
2142	999	2013-09-26
2143	999	2013-09-26
2144	999	2013-09-26
2145	999	2013-09-26
2146	999	2013-09-26
2147	999	2013-09-26
2148	999	2013-09-26
2149	999	2013-09-26
2150	999	2013-09-26
2151	999	2013-09-26
2152	999	2013-09-27
2153	999	2013-09-27
2154	999	2013-09-27
2155	999	2013-09-27
2156	999	2013-09-27
2157	999	2013-09-27
2158	999	2013-09-27
2159	999	2013-09-27
2160	999	2013-09-27
2161	999	2013-09-27
2162	999	2013-09-27
2163	999	2013-09-27
2164	999	2013-09-27
2165	999	2013-09-27
2166	999	2013-09-27
2167	999	2013-09-27
2168	999	2013-09-28
2169	999	2013-09-28
2170	999	2013-09-28
2171	999	2013-09-28
2172	999	2013-09-28
2173	999	2013-09-28
2174	999	2013-09-28
2175	999	2013-09-28
2176	999	2013-09-28
2177	999	2013-09-28
2178	999	2013-09-28
2179	999	2013-09-28
2180	999	2013-09-28
2181	999	2013-09-28
2182	999	2013-09-29
2183	999	2013-09-29
2184	999	2013-09-29
2185	999	2013-09-29
2186	999	2013-09-29
2187	999	2013-09-29
2188	999	2013-09-29
2189	999	2013-09-29
2190	999	2013-09-29
2191	999	2013-09-29
2192	999	2013-09-30
2193	999	2013-09-30
2194	999	2013-09-30
2195	999	2013-09-30
2196	999	2013-09-30
2197	999	2013-09-30
2198	999	2013-09-30
2199	999	2013-10-01
2200	999	2013-10-01
2201	999	2013-10-01
2202	999	2013-10-01
2203	999	2013-10-01
2204	999	2013-10-01
2205	999	2013-10-01
2206	999	2013-10-01
2207	999	2013-10-01
2208	999	2013-10-01
2209	999	2013-10-02
2210	999	2013-10-02
2211	999	2013-10-02
2212	999	2013-10-03
2213	999	2013-10-03
2214	999	2013-10-03
2215	999	2013-10-03
2216	999	2013-10-03
2217	999	2013-10-03
2218	999	2013-10-04
2219	999	2013-10-04
2220	999	2013-10-04
2221	999	2013-10-04
2222	999	2013-10-04
2223	999	2013-10-04
2224	999	2013-10-05
2225	999	2013-10-05
2226	999	2013-10-05
2227	999	2013-10-05
2228	999	2013-10-05
2229	999	2013-10-05
2230	999	2013-10-05
2231	999	2013-10-05
2232	999	2013-10-05
2233	999	2013-10-05
2234	999	2013-10-05
2235	999	2013-10-05
2236	999	2013-10-06
2237	999	2013-10-06
2238	999	2013-10-06
2239	999	2013-10-06
2240	999	2013-10-06
2241	999	2013-10-06
2242	999	2013-10-06
2243	999	2013-10-06
2244	999	2013-10-06
2245	999	2013-10-06
2246	999	2013-10-06
2247	999	2013-10-06
2248	999	2013-10-07
2249	999	2013-10-07
2250	999	2013-10-07
2251	999	2013-10-07
2252	999	2013-10-07
2253	999	2013-10-07
2254	999	2013-10-07
2255	999	2013-10-07
2256	999	2013-10-07
2257	999	2013-10-07
2258	999	2013-10-08
2259	999	2013-10-08
2260	999	2013-10-08
2261	999	2013-10-08
2262	999	2013-10-08
2263	999	2013-10-08
2264	999	2013-10-08
2265	999	2013-10-08
2266	999	2013-10-08
2267	999	2013-10-08
2268	999	2013-10-08
2269	999	2013-10-08
2270	999	2013-10-09
2271	999	2013-10-09
2272	999	2013-10-09
2273	999	2013-10-09
2274	999	2013-10-09
2275	999	2013-10-09
2276	999	2013-10-10
2277	999	2013-10-10
2278	999	2013-10-10
2279	999	2013-10-10
2280	999	2013-10-10
2281	999	2013-10-10
2282	999	2013-10-10
2283	999	2013-10-10
2284	999	2013-10-10
2285	999	2013-10-10
2286	999	2013-10-10
2287	999	2013-10-11
2288	999	2013-10-11
2289	999	2013-10-11
2290	999	2013-10-11
2291	999	2013-10-11
2292	999	2013-10-11
2293	999	2013-10-11
2294	999	2013-10-11
2295	999	2013-10-11
2296	999	2013-10-12
2297	999	2013-10-12
2298	999	2013-10-12
2299	999	2013-10-12
2300	999	2013-10-12
2301	999	2013-10-12
2302	999	2013-10-12
2303	999	2013-10-12
2304	999	2013-10-12
2305	999	2013-10-12
2306	999	2013-10-12
2307	999	2013-10-12
2308	999	2013-10-12
2309	999	2013-10-12
2310	999	2013-10-12
2311	999	2013-10-13
2312	999	2013-10-13
2313	999	2013-10-13
2314	999	2013-10-13
2315	999	2013-10-13
2316	999	2013-10-13
2317	999	2013-10-13
2318	999	2013-10-13
2319	999	2013-10-13
2320	999	2013-10-13
2321	999	2013-10-13
2322	999	2013-10-13
2323	999	2013-10-13
2324	999	2013-10-14
2325	999	2013-10-14
2326	999	2013-10-14
2327	999	2013-10-14
2328	999	2013-10-14
2329	999	2013-10-14
2330	999	2013-10-14
2331	999	2013-10-14
2332	999	2013-10-14
2333	999	2013-10-14
2334	999	2013-10-14
2335	999	2013-10-15
2336	999	2013-10-15
2337	999	2013-10-15
2338	999	2013-10-15
2339	999	2013-10-15
2340	999	2013-10-15
2341	999	2013-10-15
2342	999	2013-10-15
2343	999	2013-10-15
2344	999	2013-10-15
2345	999	2013-10-16
2346	999	2013-10-16
2347	999	2013-10-16
2348	999	2013-10-16
2349	999	2013-10-16
2350	999	2013-10-16
2351	999	2013-10-16
2352	999	2013-10-16
2353	999	2013-10-16
2354	999	2013-10-16
2355	999	2013-10-16
2356	999	2013-10-16
2357	999	2013-10-16
2358	999	2013-10-16
2359	999	2013-10-16
2360	999	2013-10-17
2361	999	2013-10-17
2362	999	2013-10-17
2363	999	2013-10-17
2364	999	2013-10-17
2365	999	2013-10-17
2366	999	2013-10-17
2367	999	2013-10-17
2368	999	2013-10-17
2369	999	2013-10-17
2370	999	2013-10-18
2371	999	2013-10-18
2372	999	2013-10-18
2373	999	2013-10-18
2374	999	2013-10-18
2375	999	2013-10-18
2376	999	2013-10-18
2377	999	2013-10-18
2378	999	2013-10-18
2379	999	2013-10-18
2380	999	2013-10-19
2381	999	2013-10-19
2382	999	2013-10-19
2383	999	2013-10-19
2384	999	2013-10-19
2385	999	2013-10-19
2386	999	2013-10-19
2387	999	2013-10-19
2388	999	2013-10-19
2389	999	2013-10-19
2390	999	2013-10-19
2391	999	2013-10-19
2392	999	2013-10-19
2393	999	2013-10-19
2394	999	2013-10-19
2395	999	2013-10-20
2396	999	2013-10-20
2397	999	2013-10-20
2398	999	2013-10-20
2399	999	2013-10-20
2400	999	2013-10-20
2401	999	2013-10-20
2402	999	2013-10-20
2403	999	2013-10-20
2404	999	2013-10-20
2405	999	2013-10-20
2406	999	2013-10-20
2407	999	2013-10-20
2408	999	2013-10-20
2409	999	2013-10-20
2410	999	2013-10-20
2411	999	2013-10-21
2412	999	2013-10-21
2413	999	2013-10-21
2414	999	2013-10-21
2415	999	2013-10-21
2416	999	2013-10-21
2417	999	2013-10-21
2418	999	2013-10-21
2419	999	2013-10-21
2420	999	2013-10-21
2421	999	2013-10-21
2422	999	2013-10-21
2423	999	2013-10-21
2424	999	2013-10-21
2425	999	2013-10-21
2426	999	2013-10-21
2427	999	2013-10-22
2428	999	2013-10-22
2429	999	2013-10-22
2430	999	2013-10-22
2431	999	2013-10-22
2432	999	2013-10-22
2433	999	2013-10-22
2434	999	2013-10-22
2435	999	2013-10-23
2436	999	2013-10-23
2437	999	2013-10-23
2438	999	2013-10-23
2439	999	2013-10-23
2440	999	2013-10-23
2441	999	2013-10-23
2442	999	2013-10-23
2443	999	2013-10-23
2444	999	2013-10-23
2445	999	2013-10-23
2446	999	2013-10-23
2447	999	2013-10-23
2448	999	2013-10-23
2449	999	2013-10-23
2450	999	2013-10-24
2451	999	2013-10-24
2452	999	2013-10-24
2453	999	2013-10-24
2454	999	2013-10-24
2455	999	2013-10-25
2456	999	2013-10-25
2457	999	2013-10-25
2458	999	2013-10-25
2459	999	2013-10-25
2460	999	2013-10-25
2461	999	2013-10-25
2462	999	2013-10-25
2463	999	2013-10-25
2464	999	2013-10-25
2465	999	2013-10-26
2466	999	2013-10-26
2467	999	2013-10-26
2468	999	2013-10-26
2469	999	2013-10-26
2470	999	2013-10-26
2471	999	2013-10-26
2472	999	2013-10-26
2473	999	2013-10-26
2474	999	2013-10-26
2475	999	2013-10-26
2476	999	2013-10-26
2477	999	2013-10-26
2478	999	2013-10-26
2479	999	2013-10-26
2480	999	2013-10-26
2481	999	2013-10-27
2482	999	2013-10-28
2483	999	2013-10-29
2484	999	2013-10-29
2485	999	2013-10-30
2486	999	2013-10-30
2487	999	2013-10-31
2488	999	2013-10-31
2489	999	2013-10-31
2490	999	2013-10-31
2491	999	2013-10-31
2492	999	2013-10-31
2493	999	2013-10-31
2494	999	2013-11-01
2495	999	2013-11-01
2496	999	2013-11-03
2497	999	2013-11-03
2498	999	2013-11-03
2499	999	2013-11-03
2500	999	2013-11-04
2501	999	2013-11-04
2502	999	2013-11-04
2503	999	2013-11-04
2504	999	2013-11-06
2505	999	2013-11-06
2506	999	2013-11-07
2507	999	2013-11-07
2508	999	2013-11-07
2509	999	2013-11-07
2510	999	2013-11-09
2511	999	2013-11-09
2512	999	2013-08-08
2513	999	2013-08-11
2514	999	2013-08-11
2515	999	2013-08-11
2516	999	2013-08-12
2517	999	2013-08-12
2518	999	2013-08-12
2519	999	2013-08-16
2520	999	2013-08-16
2521	999	2013-08-16
2522	999	2013-08-16
2523	999	2013-08-16
2524	999	2013-08-16
2525	999	2013-09-30
2526	999	2013-09-30
2527	999	2013-09-30
2528	999	2013-09-30
2529	999	2013-09-30
2530	999	2013-09-30
2531	999	2013-09-30
2532	999	2013-09-30
2533	999	2013-09-30
2534	999	2013-09-30
2535	999	2013-10-01
2536	999	2013-10-27
2537	999	2013-10-27
2538	999	2013-10-27
2539	999	2013-10-27
2540	999	2013-10-27
2541	999	2013-10-27
2542	999	2013-10-28
2543	999	2013-10-28
2544	999	2013-10-28
2545	999	2013-07-30
2546	999	2013-06-06
2547	999	2013-06-06
2548	999	2013-06-06
2549	999	2013-06-06
2550	999	2013-06-06
2551	999	2013-06-07
2552	999	2013-06-07
2553	999	2013-06-07
2554	999	2013-06-07
2555	999	2013-06-07
2556	999	2013-06-07
2557	999	2013-06-07
2558	999	2013-06-07
2559	999	2013-06-07
2560	999	2013-06-07
2561	999	2013-06-07
2562	999	2013-06-07
2563	999	2013-06-07
2564	999	2013-06-08
2565	999	2013-06-08
2566	999	2013-06-08
2567	999	2013-06-08
2568	999	2013-06-08
2569	999	2013-06-09
2570	999	2013-06-09
2571	999	2013-06-09
2572	999	2013-06-09
2573	999	2013-06-09
2574	999	2013-06-09
2575	999	2013-06-09
2576	999	2013-06-09
2577	999	2013-06-09
2578	999	2013-06-09
2579	999	2013-06-10
2580	999	2013-06-10
2581	999	2013-06-10
2582	999	2013-06-10
2583	999	2013-06-10
2584	999	2013-06-10
2585	999	2013-06-10
2586	999	2013-06-10
2587	999	2013-06-10
2588	999	2013-06-10
2589	999	2013-06-11
2590	999	2013-06-11
2591	999	2013-06-11
2592	999	2013-06-12
2593	999	2013-06-12
2594	999	2013-06-12
2595	999	2013-06-12
2596	999	2013-06-12
2597	999	2013-06-12
2598	999	2013-06-12
2599	999	2013-06-13
2600	999	2013-06-13
2601	999	2013-06-13
2602	999	2013-06-13
2603	999	2013-06-13
2604	999	2013-06-13
2605	999	2013-06-13
2606	999	2013-06-13
2607	999	2013-06-14
2608	999	2013-06-14
2609	999	2013-06-14
2610	999	2013-06-14
2611	999	2013-06-14
2612	999	2013-06-14
2613	999	2013-06-14
2614	999	2013-06-14
2615	999	2013-06-14
2616	999	2013-06-14
2617	999	2013-06-14
2618	999	2013-06-15
2619	999	2013-06-15
2620	999	2013-06-15
2621	999	2013-06-15
2622	999	2013-06-15
2623	999	2013-06-15
2624	999	2013-06-15
2625	999	2013-06-15
2626	999	2013-06-15
2627	999	2013-06-16
2628	999	2013-06-16
2629	999	2013-06-16
2630	999	2013-06-16
2631	999	2013-06-16
2632	999	2013-06-16
2633	999	2013-06-16
2634	999	2013-06-17
2635	999	2013-06-17
2636	999	2013-06-17
2637	999	2013-06-17
2638	999	2013-06-17
2639	999	2013-06-17
2640	999	2013-06-17
2641	999	2013-06-17
2642	999	2013-06-17
2643	999	2013-06-17
2644	999	2013-06-17
2645	999	2013-06-18
2646	999	2013-06-18
2647	999	2013-06-18
2648	999	2013-06-18
2649	999	2013-06-18
2650	999	2013-06-18
2651	999	2013-06-18
2652	999	2013-06-18
2653	999	2013-06-18
2654	999	2013-06-18
2655	999	2013-06-18
2656	999	2013-06-19
2657	999	2013-06-19
2658	999	2013-06-19
2659	999	2013-06-19
2660	999	2013-06-19
2661	999	2013-06-19
2662	999	2013-06-19
2663	999	2013-06-19
2664	999	2013-06-19
2665	999	2013-06-20
2666	999	2013-06-20
2667	999	2013-06-20
2668	999	2013-06-20
2669	999	2013-06-20
2670	999	2013-06-20
2671	999	2013-06-20
2672	999	2013-06-20
2673	999	2013-06-20
2674	999	2013-06-21
2675	999	2013-06-21
2676	999	2013-06-21
2677	999	2013-06-21
2678	999	2013-06-21
2679	999	2013-06-21
2680	999	2013-06-21
2681	999	2013-06-21
2682	999	2013-06-21
2683	999	2013-06-21
2684	999	2013-06-22
2685	999	2013-06-22
2686	999	2013-06-22
2687	999	2013-06-22
2688	999	2013-06-22
2689	999	2013-06-22
2690	999	2013-06-22
2691	999	2013-06-22
2692	999	2013-06-22
2693	999	2013-06-23
2694	999	2013-06-23
2695	999	2013-06-23
2696	999	2013-06-23
2697	999	2013-06-23
2698	999	2013-06-23
2699	999	2013-06-23
2700	999	2013-06-23
2701	999	2013-06-23
2702	999	2013-06-24
2703	999	2013-06-24
2704	999	2013-06-24
2705	999	2013-06-24
2706	999	2013-06-24
2707	999	2013-06-24
2708	999	2013-06-24
2709	999	2013-06-25
2710	999	2013-06-25
2711	999	2013-06-25
2712	999	2013-06-25
2713	999	2013-06-25
2714	999	2013-06-25
2715	999	2013-06-26
2716	999	2013-06-26
2717	999	2013-06-26
2718	999	2013-06-26
2719	999	2013-07-11
2720	999	2013-07-11
2721	999	2013-07-11
2722	999	2013-07-11
2723	999	2013-07-11
2724	999	2013-07-11
2725	999	2013-07-12
2726	999	2013-07-12
2727	999	2013-07-12
2728	999	2013-07-12
2729	999	2013-07-12
2730	999	2013-07-12
2731	999	2013-07-12
2732	999	2013-07-12
2733	999	2013-07-12
2734	999	2013-07-12
2735	999	2013-07-12
2736	999	2013-07-12
2737	999	2013-07-13
2738	999	2013-07-13
2739	999	2013-07-13
2740	999	2013-07-13
2741	999	2013-07-13
2742	999	2013-07-13
2743	999	2013-07-13
2744	999	2013-07-13
2745	999	2013-07-14
2746	999	2013-07-14
2747	999	2013-07-14
2748	999	2013-07-14
2749	999	2013-07-14
2750	999	2013-07-15
2751	999	2013-07-15
2752	999	2013-07-15
2753	999	2013-07-15
2754	999	2013-07-15
2755	999	2013-07-15
2756	999	2013-07-16
2757	999	2013-07-16
2758	999	2013-07-16
2759	999	2013-07-16
2760	999	2013-07-16
2761	999	2013-07-16
2762	999	2013-07-17
2763	999	2013-07-17
2764	999	2013-07-17
2765	999	2013-07-17
2766	999	2013-07-17
2767	999	2013-07-17
2768	999	2013-07-17
2769	999	2013-07-18
2770	999	2013-07-18
2771	999	2013-07-18
2772	999	2013-07-18
2773	999	2013-07-18
2774	999	2013-07-18
2775	999	2013-07-18
2776	999	2013-07-18
2777	999	2013-07-19
2778	999	2013-07-19
2779	999	2013-07-19
2780	999	2013-07-19
2781	999	2013-07-19
2782	999	2013-07-19
2783	999	2013-07-19
2784	999	2013-07-19
2785	999	2013-07-19
2786	999	2013-07-20
2787	999	2013-07-20
2788	999	2013-07-20
2789	999	2013-07-20
2790	999	2013-07-20
2791	999	2013-07-20
2792	999	2013-07-20
2793	999	2013-07-20
2794	999	2013-07-20
2795	999	2013-07-20
2796	999	2013-07-21
2797	999	2013-07-21
2798	999	2013-07-21
2799	999	2013-07-21
2800	999	2013-07-21
2801	999	2013-07-21
2802	999	2013-07-21
2803	999	2013-07-21
2804	999	2013-07-21
2805	999	2013-07-21
2806	999	2013-07-21
2807	999	2013-07-21
2808	999	2013-07-21
2809	999	2013-07-21
2810	999	2013-07-21
2811	999	2013-07-22
2812	999	2013-07-22
2813	999	2013-07-22
2814	999	2013-07-22
2815	999	2013-07-22
2816	999	2013-07-22
2817	999	2013-07-23
2818	999	2013-07-23
2819	999	2013-07-23
2820	999	2013-07-23
2821	999	2013-07-23
2822	999	2013-07-23
2823	999	2013-07-23
2824	999	2013-07-24
2825	999	2013-07-24
2826	999	2013-07-24
2827	999	2013-07-24
2828	999	2013-07-24
2829	999	2013-07-24
2830	999	2013-07-24
2831	999	2013-07-24
2832	999	2013-07-24
2833	999	2013-07-25
2834	999	2013-07-25
2835	999	2013-07-25
2836	999	2013-07-25
2837	999	2013-07-25
2838	999	2013-07-25
2839	999	2013-07-25
2840	999	2013-07-25
2841	999	2013-07-25
2842	999	2013-07-26
2843	999	2013-07-26
2844	999	2013-07-26
2845	999	2013-07-26
2846	999	2013-07-26
2847	999	2013-07-26
2848	999	2013-07-26
2849	999	2013-07-26
2850	999	2013-07-27
2851	999	2013-07-27
2852	999	2013-07-27
2853	999	2013-07-27
2854	999	2013-07-27
2855	999	2013-07-27
2856	999	2013-07-27
2857	999	2013-07-27
2858	999	2013-07-27
2859	999	2013-07-27
2860	999	2013-07-27
2861	999	2013-07-27
2862	999	2013-07-27
2863	999	2013-07-27
2864	999	2013-07-27
2865	999	2013-07-28
2866	999	2013-07-28
2867	999	2013-07-28
2868	999	2013-07-28
2869	999	2013-07-28
2870	999	2013-07-28
2871	999	2013-07-28
2872	999	2013-07-28
2873	999	2013-07-28
2874	999	2013-07-28
2875	999	2013-07-29
2876	999	2013-07-29
2877	999	2013-07-29
2878	999	2013-07-29
2879	999	2013-07-30
2880	999	2013-07-30
2881	999	2013-07-30
2882	999	2013-07-30
2883	999	2013-07-30
2884	999	2013-07-30
2885	999	2013-07-30
2886	999	2013-07-30
2887	999	2013-07-30
2888	999	2013-07-31
2889	999	2013-07-31
2890	999	2013-08-01
2891	999	2013-08-01
2892	999	2013-08-01
2893	999	2013-08-01
2894	999	2013-08-01
2895	999	2013-08-01
2896	999	2013-08-01
2897	999	2013-08-02
2898	999	2013-08-02
2899	999	2013-08-02
2900	999	2013-08-02
2901	999	2013-08-02
2902	999	2013-08-02
2903	999	2013-08-02
2904	999	2013-08-03
2905	999	2013-08-03
2906	999	2013-08-03
2907	999	2013-08-03
2908	999	2013-08-03
2909	999	2013-08-03
2910	999	2013-08-03
2911	999	2013-08-03
2912	999	2013-08-03
2913	999	2013-08-03
2914	999	2013-08-03
2915	999	2013-08-03
2916	999	2013-08-04
2917	999	2013-08-04
2918	999	2013-08-04
2919	999	2013-08-04
2920	999	2013-08-04
2921	999	2013-08-04
2922	999	2013-08-04
2923	999	2013-08-04
2924	999	2013-08-04
2925	999	2013-08-04
2926	999	2013-08-04
2927	999	2013-08-04
2928	999	2013-08-05
2929	999	2013-08-05
2930	999	2013-08-05
2931	999	2013-08-05
2932	999	2013-08-05
2933	999	2013-08-05
2934	999	2013-08-05
2935	999	2013-08-05
2936	999	2013-08-05
2937	999	2013-08-05
2938	999	2013-08-05
2939	999	2013-08-06
2940	999	2013-08-06
2941	999	2013-08-06
2942	999	2013-08-06
2943	999	2013-08-06
2944	999	2013-08-06
2945	999	2013-08-06
2946	999	2013-08-06
2947	999	2013-08-06
2948	999	2013-08-06
2949	999	2013-08-06
2950	999	2013-08-06
2951	999	2013-08-06
2952	999	2013-08-06
2953	999	2013-08-06
2954	999	2013-08-07
2955	999	2013-08-07
2956	999	2013-08-07
2957	999	2013-08-07
2958	999	2013-08-07
2959	999	2013-08-07
2960	999	2013-08-07
2961	999	2013-08-07
2962	999	2013-08-07
2963	999	2013-08-07
2964	999	2013-08-07
2965	999	2013-08-07
2966	999	2013-08-07
2967	999	2013-08-07
2968	999	2013-08-07
2969	999	2013-08-07
2970	999	2013-08-07
2971	999	2013-08-07
2972	999	2013-08-08
2973	999	2013-08-08
2974	999	2013-08-08
2975	999	2013-08-08
2976	999	2013-08-08
2977	999	2013-08-08
2978	999	2013-08-08
2979	999	2013-08-08
2980	999	2013-08-08
2981	999	2013-08-08
2982	999	2013-08-08
2983	999	2013-08-08
2984	999	2013-08-08
2985	999	2013-06-06
2986	999	2013-06-07
2987	999	2013-06-08
2988	999	2013-06-08
2989	999	2013-06-09
2990	999	2013-06-09
2991	999	2013-06-10
2992	999	2013-06-14
2993	999	2013-06-14
2994	999	2013-06-15
2995	999	2013-06-16
2996	999	2013-06-16
2997	999	2013-06-16
2998	999	2013-06-16
2999	999	2013-06-16
3000	999	2013-06-16
3001	999	2013-06-16
3002	999	2013-06-17
3003	999	2013-06-17
3004	999	2013-06-20
3005	999	2013-06-20
3006	999	2013-06-21
3007	999	2013-07-12
3008	999	2013-07-13
3009	999	2013-07-15
3010	999	2013-07-17
3011	999	2013-07-20
3012	999	2013-07-21
3013	999	2013-07-21
3014	999	2013-07-22
3015	999	2013-07-23
3016	999	2013-07-23
3017	999	2013-07-23
3018	999	2013-07-24
3019	999	2013-07-24
3020	999	2013-07-24
3021	999	2013-07-25
3022	999	2013-07-25
3023	999	2013-07-26
3024	999	2013-07-26
3025	999	2013-07-27
3026	999	2013-07-27
3027	999	2013-07-28
3028	999	2013-07-28
3029	999	2013-07-31
3030	999	2013-08-01
3031	999	2013-08-01
3032	999	2013-08-02
3033	999	2013-08-02
3034	999	2013-08-02
3035	999	2013-08-03
3036	999	2013-08-04
3037	999	2013-08-04
3038	999	2013-08-04
3039	999	2013-08-05
3040	999	2013-08-05
3041	999	2013-08-05
3042	999	2013-08-06
3043	999	2013-08-08
3044	999	2013-08-08
3045	999	2013-08-08
3046	999	2013-08-08
3047	999	2013-06-08
3048	999	2013-06-08
3049	999	2013-06-14
3050	999	2013-06-15
3051	999	2013-06-16
3052	999	2013-06-16
3053	999	2013-06-17
3054	999	2013-07-13
3055	999	2013-08-01
3056	999	2013-08-04
3057	999	2013-08-08
3058	999	2013-06-08
3059	999	2013-06-15
3060	999	2013-06-15
3061	999	2013-06-15
3062	999	2013-05-19
3063	999	2013-05-20
3064	999	2013-05-19
3065	999	2013-05-19
3066	999	2013-05-19
3067	999	2013-05-19
3068	999	2013-05-19
3069	999	2013-05-19
3070	999	2013-05-19
3071	999	2013-05-19
3072	999	2013-05-19
3073	999	2013-05-19
3074	999	2013-05-19
3075	999	2013-05-19
3076	999	2013-05-19
3077	999	2013-05-20
3078	999	2013-05-20
3079	999	2013-05-20
3080	999	2013-05-20
3081	999	2013-05-20
3082	999	2013-05-20
3083	999	2013-05-20
3084	999	2013-05-20
3085	999	2013-05-20
3086	999	2013-05-20
3087	999	2013-05-21
3088	999	2013-05-21
3089	999	2013-05-21
3090	999	2013-05-21
3091	999	2013-05-21
3092	999	2013-05-21
3093	999	2013-05-21
3094	999	2013-05-22
3095	999	2013-05-22
3096	999	2013-05-22
3097	999	2013-05-22
3098	999	2013-05-22
3099	999	2013-05-22
3100	999	2013-05-22
3101	999	2013-05-22
3102	999	2013-05-22
3103	999	2013-05-22
3104	999	2013-05-22
3105	999	2013-05-22
3106	999	2013-05-23
3107	999	2013-05-23
3108	999	2013-05-23
3109	999	2013-05-23
3110	999	2013-05-23
3111	999	2013-05-23
3112	999	2013-05-23
3113	999	2013-05-23
3114	999	2013-05-23
3115	999	2013-05-23
3116	999	2013-05-23
3117	999	2013-05-23
3118	999	2013-05-24
3119	999	2013-05-24
3120	999	2013-05-24
3121	999	2013-05-24
3122	999	2013-05-24
3123	999	2013-05-24
3124	999	2013-05-24
3125	999	2013-05-24
3126	999	2013-05-24
3127	999	2013-05-24
3128	999	2013-05-24
3129	999	2013-05-24
3130	999	2013-05-24
3131	999	2013-05-24
3132	999	2013-05-24
3133	999	2013-05-25
3134	999	2013-05-25
3135	999	2013-05-25
3136	999	2013-05-25
3137	999	2013-05-25
3138	999	2013-05-25
3139	999	2013-05-25
3140	999	2013-05-25
3141	999	2013-05-25
3142	999	2013-05-26
3143	999	2013-05-26
3144	999	2013-05-26
3145	999	2013-05-26
3146	999	2013-05-26
3147	999	2013-05-26
3148	999	2013-05-27
3149	999	2013-05-27
3150	999	2013-05-27
3151	999	2013-05-27
3152	999	2013-05-27
3153	999	2013-05-27
3154	999	2013-05-27
3155	999	2013-05-28
3156	999	2013-05-28
3157	999	2013-05-28
3158	999	2013-05-28
3159	999	2013-05-28
3160	999	2013-05-28
3161	999	2013-05-29
3162	999	2013-05-29
3163	999	2013-05-29
3164	999	2013-05-29
3165	999	2013-05-29
3166	999	2013-05-30
3167	999	2013-05-30
3168	999	2013-05-30
3169	999	2013-05-30
3170	999	2013-05-30
3171	999	2013-05-30
3172	999	2013-05-31
3173	999	2013-05-31
3174	999	2013-05-31
3175	999	2013-05-31
3176	999	2013-06-01
3177	999	2013-06-01
3178	999	2013-06-01
3179	999	2013-06-01
3180	999	2013-06-01
3181	999	2013-06-01
3182	999	2013-06-01
3183	999	2013-06-01
3184	999	2013-06-01
3185	999	2013-06-01
3186	999	2013-06-01
3187	999	2013-06-01
3188	999	2013-06-02
3189	999	2013-06-02
3190	999	2013-06-02
3191	999	2013-06-02
3192	999	2013-06-02
3193	999	2013-06-02
3194	999	2013-06-02
3195	999	2013-06-02
3196	999	2013-06-02
3197	999	2013-06-02
3198	999	2013-06-02
3199	999	2013-06-02
3200	999	2013-06-02
3201	999	2013-06-02
3202	999	2013-06-02
3203	999	2013-06-03
3204	999	2013-06-03
3205	999	2013-06-03
3206	999	2013-06-04
3207	999	2013-06-04
3208	999	2013-06-04
3209	999	2013-06-04
3210	999	2013-06-04
3211	999	2013-06-04
3212	999	2013-06-04
3213	999	2013-06-05
3214	999	2013-06-05
3215	999	2013-06-05
3216	999	2013-06-05
3217	999	2013-06-05
3218	999	2013-06-05
3219	999	2013-06-05
3220	999	2013-06-06
3221	999	2013-06-06
3222	999	2013-06-06
3223	999	2013-06-06
3224	999	2013-06-06
3225	999	2013-06-06
3226	999	2013-06-06
3227	999	2013-06-06
3228	999	2013-06-07
3229	999	2013-06-07
3230	999	2013-06-07
3231	999	2013-06-07
3232	999	2013-06-07
3233	999	2013-06-08
3234	999	2013-06-08
3235	999	2013-06-08
3236	999	2013-06-08
3237	999	2013-06-08
3238	999	2013-06-08
3239	999	2013-06-08
3240	999	2013-06-09
3241	999	2013-06-09
3242	999	2013-06-09
3243	999	2013-06-09
3244	999	2013-06-09
3245	999	2013-06-09
3246	999	2013-06-09
3247	999	2013-06-10
3248	999	2013-06-10
3249	999	2013-06-10
3250	999	2013-06-10
3251	999	2013-06-10
3252	999	2013-06-10
3253	999	2013-06-10
3254	999	2013-06-10
3255	999	2013-06-11
3256	999	2013-06-11
3257	999	2013-06-11
3258	999	2013-06-11
3259	999	2013-06-11
3260	999	2013-06-11
3261	999	2013-06-11
3262	999	2013-06-11
3263	999	2013-06-12
3264	999	2013-06-12
3265	999	2013-06-12
3266	999	2013-06-12
3267	999	2013-06-12
3268	999	2013-06-12
3269	999	2013-06-12
3270	999	2013-06-13
3271	999	2013-06-13
3272	999	2013-06-13
3273	999	2013-06-13
3274	999	2013-06-13
3275	999	2013-06-13
3276	999	2013-06-13
3277	999	2013-06-13
3278	999	2013-06-13
3279	999	2013-06-14
3280	999	2013-06-14
3281	999	2013-06-14
3282	999	2013-06-14
3283	999	2013-06-14
3284	999	2013-06-14
3285	999	2013-06-14
3286	999	2013-06-14
3287	999	2013-06-14
3288	999	2013-06-14
3289	999	2013-06-14
3290	999	2013-06-14
3291	999	2013-06-14
3292	999	2013-06-14
3293	999	2013-06-14
3294	999	2013-06-15
3295	999	2013-06-15
3296	999	2013-06-15
3297	999	2013-06-15
3298	999	2013-06-15
3299	999	2013-06-15
3300	999	2013-06-15
3301	999	2013-06-15
3302	999	2013-06-15
3303	999	2013-06-15
3304	999	2013-06-15
3305	999	2013-06-15
3306	999	2013-06-15
3307	999	2013-06-15
3308	999	2013-06-15
3309	999	2013-06-15
3310	999	2013-06-15
3311	999	2013-06-15
3312	999	2013-06-16
3313	999	2013-06-16
3314	999	2013-06-16
3315	999	2013-06-16
3316	999	2013-06-16
3317	999	2013-06-16
3318	999	2013-06-17
3319	999	2013-06-17
3320	999	2013-06-17
3321	999	2013-06-17
3322	999	2013-06-17
3323	999	2013-06-17
3324	999	2013-06-18
3325	999	2013-06-18
3326	999	2013-06-18
3327	999	2013-06-18
3328	999	2013-06-18
3329	999	2013-06-18
3330	999	2013-06-19
3331	999	2013-06-19
3332	999	2013-06-19
3333	999	2013-06-19
3334	999	2013-06-19
3335	999	2013-06-19
3336	999	2013-06-19
3337	999	2013-06-20
3338	999	2013-06-20
3339	999	2013-06-20
3340	999	2013-06-20
3341	999	2013-06-21
3342	999	2013-06-21
3343	999	2013-06-21
3344	999	2013-06-21
3345	999	2013-06-21
3346	999	2013-06-21
3347	999	2013-06-21
3348	999	2013-06-21
3349	999	2013-06-21
3350	999	2013-06-21
3351	999	2013-06-22
3352	999	2013-06-22
3353	999	2013-06-22
3354	999	2013-06-22
3355	999	2013-06-22
3356	999	2013-06-22
3357	999	2013-06-23
3358	999	2013-06-23
3359	999	2013-06-23
3360	999	2013-06-23
3361	999	2013-06-24
3362	999	2013-06-24
3363	999	2013-06-24
3364	999	2013-06-24
3365	999	2013-06-24
3366	999	2013-06-25
3367	999	2013-06-25
3368	999	2013-06-25
3369	999	2013-06-25
3370	999	2013-06-25
3371	999	2013-06-25
3372	999	2013-06-25
3373	999	2013-06-25
3374	999	2013-06-25
3375	999	2013-06-25
3376	999	2013-06-25
3377	999	2013-06-25
3378	999	2013-06-25
3379	999	2013-06-25
3380	999	2013-06-25
3381	999	2013-06-25
3382	999	2013-06-26
3383	999	2013-06-26
3384	999	2013-06-26
3385	999	2013-06-26
3386	999	2013-06-26
3387	999	2013-06-26
3388	999	2013-06-26
3389	999	2013-06-26
3390	999	2013-06-26
3391	999	2013-06-26
3392	999	2013-06-26
3393	999	2013-06-26
3394	999	2013-06-26
3395	999	2013-06-26
3396	999	2013-06-26
3397	999	2013-06-27
3398	999	2013-06-27
3399	999	2013-06-27
3400	999	2013-06-27
3401	999	2013-06-27
3402	999	2013-06-27
3403	999	2013-06-27
3404	999	2013-06-27
3405	999	2013-06-27
3406	999	2013-06-27
3407	999	2013-06-27
3408	999	2013-06-27
3409	999	2013-06-27
3410	999	2013-06-27
3411	999	2013-06-27
3412	999	2013-06-27
3413	999	2013-06-27
3414	999	2013-06-28
3415	999	2013-06-28
3416	999	2013-06-28
3417	999	2013-06-28
3418	999	2013-06-28
3419	999	2013-06-28
3420	999	2013-06-28
3421	999	2013-06-28
3422	999	2013-06-28
3423	999	2013-06-28
3424	999	2013-06-28
3425	999	2013-06-29
3426	999	2013-06-29
3427	999	2013-06-29
3428	999	2013-06-29
3429	999	2013-06-29
3430	999	2013-06-29
3431	999	2013-06-29
3432	999	2013-06-29
3433	999	2013-06-29
3434	999	2013-06-29
3435	999	2013-06-30
3436	999	2013-06-30
3437	999	2013-06-30
3438	999	2013-06-30
3439	999	2013-07-01
3440	999	2013-07-01
3441	999	2013-07-01
3442	999	2013-07-01
3443	999	2013-07-01
3444	999	2013-07-01
3445	999	2013-07-02
3446	999	2013-07-02
3447	999	2013-07-02
3448	999	2013-07-02
3449	999	2013-07-02
3450	999	2013-07-02
3451	999	2013-07-02
3452	999	2013-07-02
3453	999	2013-07-02
3454	999	2013-07-02
3455	999	2013-07-03
3456	999	2013-07-03
3457	999	2013-07-03
3458	999	2013-07-03
3459	999	2013-07-04
3460	999	2013-07-04
3461	999	2013-07-04
3462	999	2013-07-04
3463	999	2013-07-04
3464	999	2013-07-04
3465	999	2013-07-04
3466	999	2013-07-04
3467	999	2013-07-05
3468	999	2013-07-05
3469	999	2013-07-05
3470	999	2013-07-05
3471	999	2013-07-05
3472	999	2013-07-06
3473	999	2013-07-06
3474	999	2013-07-06
3475	999	2013-07-06
3476	999	2013-07-06
3477	999	2013-07-06
3478	999	2013-07-07
3479	999	2013-07-07
3480	999	2013-07-07
3481	999	2013-07-07
3482	999	2013-07-07
3483	999	2013-07-07
3484	999	2013-07-07
3485	999	2013-07-07
3486	999	2013-07-07
3487	999	2013-07-07
3488	999	2013-07-08
3489	999	2013-07-08
3490	999	2013-07-08
3491	999	2013-07-08
3492	999	2013-07-08
3493	999	2013-07-08
3494	999	2013-07-08
3495	999	2013-07-08
3496	999	2013-07-08
3497	999	2013-07-08
3498	999	2013-07-08
3499	999	2013-07-08
3500	999	2013-07-08
3501	999	2013-07-08
3502	999	2013-07-09
3503	999	2013-07-09
3504	999	2013-07-09
3505	999	2013-07-09
3506	999	2013-07-09
3507	999	2013-07-09
3508	999	2013-07-09
3509	999	2013-07-09
3510	999	2013-07-09
3511	999	2013-07-09
3512	999	2013-07-09
3513	999	2013-07-09
3514	999	2013-07-09
3515	999	2013-07-09
3516	999	2013-07-09
3517	999	2013-07-09
3518	999	2013-07-09
3519	999	2013-07-10
3520	999	2013-07-10
3521	999	2013-07-10
3522	999	2013-07-10
3523	999	2013-07-10
3524	999	2013-07-10
3525	999	2013-07-10
3526	999	2013-07-10
3527	999	2013-07-10
3528	999	2013-07-10
3529	999	2013-07-11
3530	999	2013-07-11
3531	999	2013-07-11
3532	999	2013-07-11
3533	999	2013-07-11
3534	999	2013-07-11
3535	999	2013-07-11
3536	999	2013-07-11
3537	999	2013-07-11
3538	999	2013-07-11
3539	999	2013-07-11
3540	999	2013-07-11
3541	999	2013-07-11
3542	999	2013-07-11
3543	999	2013-07-11
3544	999	2013-07-11
3545	999	2013-07-11
3546	999	2013-07-11
3547	999	2013-07-12
3548	999	2013-07-12
3549	999	2013-07-12
3550	999	2013-07-12
3551	999	2013-07-12
3552	999	2013-07-12
3553	999	2013-07-12
3554	999	2013-07-12
3555	999	2013-07-13
3556	999	2013-07-13
3557	999	2013-07-13
3558	999	2013-07-13
3559	999	2013-07-13
3560	999	2013-07-13
3561	999	2013-07-13
3562	999	2013-07-13
3563	999	2013-07-13
3564	999	2013-07-13
3565	999	2013-07-13
3566	999	2013-07-13
3567	999	2013-07-14
3568	999	2013-07-14
3569	999	2013-07-14
3570	999	2013-07-14
12776	999	2006-08-19
12777	999	2006-08-19
12778	999	2006-08-19
12779	999	2006-08-19
12780	999	2006-08-19
12781	999	2006-08-19
3571	999	2013-07-14
3572	999	2013-07-14
3573	999	2013-07-14
3574	999	2013-07-14
3575	999	2013-07-14
3576	999	2013-07-14
3577	999	2013-07-14
3578	999	2013-07-14
3579	999	2013-07-15
3580	999	2013-07-15
3581	999	2013-07-15
3582	999	2013-07-15
3583	999	2013-07-15
3584	999	2013-07-15
3585	999	2013-07-15
3586	999	2013-07-15
3587	999	2013-07-15
3588	999	2013-07-15
3589	999	2013-07-15
3590	999	2013-07-16
3591	999	2013-07-16
3592	999	2013-07-16
3593	999	2013-07-16
3594	999	2013-07-16
3595	999	2013-07-16
3596	999	2013-07-16
3597	999	2013-07-16
3598	999	2013-07-17
3599	999	2013-07-17
3600	999	2013-07-17
3601	999	2013-07-17
3602	999	2013-07-18
3603	999	2013-07-18
3604	999	2013-07-18
3605	999	2013-07-18
3606	999	2013-07-19
3607	999	2013-07-19
3608	999	2013-07-19
3609	999	2013-07-19
3610	999	2013-07-19
3611	999	2013-07-19
3612	999	2013-07-20
3613	999	2013-07-20
3614	999	2013-07-20
3615	999	2013-07-20
3616	999	2013-07-20
3617	999	2013-07-20
3618	999	2013-07-20
3619	999	2013-07-20
3620	999	2013-07-20
3621	999	2013-07-20
3622	999	2013-07-21
3623	999	2013-07-21
3624	999	2013-07-21
3625	999	2013-07-21
3626	999	2013-07-21
3627	999	2013-07-22
3628	999	2013-07-22
3629	999	2013-07-22
3630	999	2013-07-22
3631	999	2013-07-22
3632	999	2013-07-22
3633	999	2013-07-22
3634	999	2013-07-22
3635	999	2013-07-23
3636	999	2013-07-23
3637	999	2013-07-23
3638	999	2013-07-23
3639	999	2013-07-23
3640	999	2013-07-23
3641	999	2013-07-23
3642	999	2013-07-24
3643	999	2013-07-24
3644	999	2013-07-24
3645	999	2013-07-24
3646	999	2013-07-24
3647	999	2013-07-24
3648	999	2013-07-24
3649	999	2013-07-24
3650	999	2013-07-24
3651	999	2013-07-24
3652	999	2013-07-24
3653	999	2013-07-25
3654	999	2013-07-25
3655	999	2013-07-25
3656	999	2013-07-25
3657	999	2013-07-25
3658	999	2013-07-25
3659	999	2013-07-25
3660	999	2013-07-25
3661	999	2013-07-25
3662	999	2013-07-26
3663	999	2013-07-26
3664	999	2013-07-26
3665	999	2013-07-26
3666	999	2013-07-26
3667	999	2013-07-26
3668	999	2013-07-26
3669	999	2013-07-26
3670	999	2013-07-26
3671	999	2013-07-26
3672	999	2013-07-27
3673	999	2013-07-27
3674	999	2013-07-27
3675	999	2013-07-28
3676	999	2013-07-28
3677	999	2013-07-28
3678	999	2013-07-28
3679	999	2013-07-28
3680	999	2013-07-28
3681	999	2013-07-28
3682	999	2013-07-28
3683	999	2013-07-29
3684	999	2013-07-29
3685	999	2013-07-29
3686	999	2013-07-29
3687	999	2013-07-30
3688	999	2013-07-30
3689	999	2013-07-30
3690	999	2013-07-30
3691	999	2013-07-30
3692	999	2013-07-30
3693	999	2013-07-30
3694	999	2013-07-30
3695	999	2013-07-31
3696	999	2013-07-31
3697	999	2013-07-31
3698	999	2013-07-31
3699	999	2013-07-31
3700	999	2013-07-31
3701	999	2013-07-31
3702	999	2013-07-31
3703	999	2013-07-31
3704	999	2013-07-31
3705	999	2013-08-01
3706	999	2013-08-01
3707	999	2013-08-01
3708	999	2013-08-01
3709	999	2013-08-01
3710	999	2013-08-01
3711	999	2013-08-01
3712	999	2013-08-01
3713	999	2013-08-01
3714	999	2013-08-01
3715	999	2013-08-02
3716	999	2013-08-02
3717	999	2013-08-02
3718	999	2013-08-02
3719	999	2013-08-02
3720	999	2013-08-03
3721	999	2013-08-03
3722	999	2013-08-03
3723	999	2013-08-03
3724	999	2013-08-03
3725	999	2013-08-03
3726	999	2013-08-03
3727	999	2013-08-03
3728	999	2013-08-03
3729	999	2013-08-04
3730	999	2013-08-04
3731	999	2013-08-04
3732	999	2013-08-04
3733	999	2013-08-04
3734	999	2013-08-04
3735	999	2013-08-04
3736	999	2013-08-04
3737	999	2013-08-04
3738	999	2013-08-04
3739	999	2013-08-04
3740	999	2013-08-04
3741	999	2013-08-04
3742	999	2013-08-05
3743	999	2013-08-05
3744	999	2013-08-05
3745	999	2013-08-05
3746	999	2013-08-05
3747	999	2013-08-05
3748	999	2013-08-06
3749	999	2013-08-06
3750	999	2013-08-06
3751	999	2013-08-06
3752	999	2013-08-06
3753	999	2013-08-06
3754	999	2013-08-06
3755	999	2013-08-07
3756	999	2013-08-07
3757	999	2013-08-07
3758	999	2013-08-07
3759	999	2013-08-07
3760	999	2013-08-07
3761	999	2013-08-07
3762	999	2013-08-07
3763	999	2013-08-08
3764	999	2013-08-08
3765	999	2013-08-08
3766	999	2013-08-08
3767	999	2013-08-08
3768	999	2013-08-08
3769	999	2013-08-08
3770	999	2013-08-08
3771	999	2013-08-09
3772	999	2013-08-09
3773	999	2013-08-09
3774	999	2013-08-09
3775	999	2013-08-09
3776	999	2013-08-09
3777	999	2013-08-10
3778	999	2013-08-10
3779	999	2013-08-10
3780	999	2013-08-10
3781	999	2013-08-10
3782	999	2013-08-10
3783	999	2013-08-10
3784	999	2013-08-10
3785	999	2013-08-10
3786	999	2013-08-11
3787	999	2013-08-11
3788	999	2013-08-11
3789	999	2013-08-11
3790	999	2013-08-11
3791	999	2013-08-11
3792	999	2013-08-11
3793	999	2013-08-12
3794	999	2013-08-12
3795	999	2013-08-13
3796	999	2013-08-13
3797	999	2013-08-13
3798	999	2013-08-13
3799	999	2013-08-13
3800	999	2013-08-13
3801	999	2013-08-13
3802	999	2013-08-14
3803	999	2013-08-14
3804	999	2013-08-14
3805	999	2013-08-14
3806	999	2013-08-14
3807	999	2013-08-14
3808	999	2013-08-14
3809	999	2013-08-14
3810	999	2013-08-15
3811	999	2013-08-15
3812	999	2013-08-15
3813	999	2013-08-15
3814	999	2013-08-15
3815	999	2013-08-15
3816	999	2013-08-15
3817	999	2013-08-15
3818	999	2013-08-16
3819	999	2013-08-16
3820	999	2013-08-16
3821	999	2013-08-16
3822	999	2013-08-16
3823	999	2013-08-16
3824	999	2013-08-16
3825	999	2013-08-16
3826	999	2013-08-16
3827	999	2013-08-16
3828	999	2013-08-16
3829	999	2013-08-16
3830	999	2013-08-17
3831	999	2013-08-17
3832	999	2013-08-17
3833	999	2013-08-17
3834	999	2013-08-17
3835	999	2013-08-17
3836	999	2013-08-17
3837	999	2013-08-17
3838	999	2013-08-17
3839	999	2013-08-17
3840	999	2013-08-17
3841	999	2013-08-18
3842	999	2013-08-18
3843	999	2013-08-18
3844	999	2013-08-18
3845	999	2013-08-18
3846	999	2013-08-18
3847	999	2013-08-18
12769	999	2006-08-18
12770	999	2006-08-18
12771	999	2006-08-18
12772	999	2006-08-18
12773	999	2006-08-18
12774	999	2006-08-19
12775	999	2006-08-19
3848	999	2013-08-18
3849	999	2013-08-19
3850	999	2013-08-19
3851	999	2013-08-19
3852	999	2013-08-19
3853	999	2013-08-19
3854	999	2013-08-19
3855	999	2013-08-19
3856	999	2013-08-19
3857	999	2013-08-19
3858	999	2013-08-20
3859	999	2013-08-20
3860	999	2013-08-20
3861	999	2013-08-20
3862	999	2013-08-20
3863	999	2013-08-21
3864	999	2013-08-21
3865	999	2013-08-21
3866	999	2013-08-21
3867	999	2013-08-22
3868	999	2013-08-22
3869	999	2013-08-22
3870	999	2013-08-22
3871	999	2013-08-22
3872	999	2013-08-22
3873	999	2013-08-22
3874	999	2013-08-22
3875	999	2013-08-22
3876	999	2013-08-23
3877	999	2013-08-23
3878	999	2013-08-23
3879	999	2013-08-23
3880	999	2013-08-23
3898	999	2013-08-25
3899	999	2013-08-25
3900	999	2013-08-25
3901	999	2013-08-26
3902	999	2013-08-26
3903	999	2013-08-26
3904	999	2013-08-26
3905	999	2013-08-26
3906	999	2013-08-26
3907	999	2013-08-26
3908	999	2013-08-26
3909	999	2013-08-27
3910	999	2013-08-27
3911	999	2013-08-27
3912	999	2013-08-27
3913	999	2013-08-27
3914	999	2013-08-27
3915	999	2013-08-27
3916	999	2013-08-27
3917	999	2013-08-27
3918	999	2013-08-28
3919	999	2013-08-28
3920	999	2013-08-28
3921	999	2013-08-28
3922	999	2013-08-28
3923	999	2013-08-28
3924	999	2013-08-28
3925	999	2013-08-28
3926	999	2013-08-28
3927	999	2013-08-28
3928	999	2013-08-29
3929	999	2013-08-29
3930	999	2013-08-29
3931	999	2013-08-29
3932	999	2013-08-29
3933	999	2013-08-29
3934	999	2013-08-29
3935	999	2013-08-29
3936	999	2013-08-29
3937	999	2013-08-30
3938	999	2013-08-30
3939	999	2013-08-30
3940	999	2013-08-30
3941	999	2013-08-30
3942	999	2013-08-30
3943	999	2013-08-30
3944	999	2013-08-30
3945	999	2013-08-30
3946	999	2013-08-30
3947	999	2013-08-30
3948	999	2013-08-30
3949	999	2013-08-31
3950	999	2013-08-31
3951	999	2013-08-31
3952	999	2013-08-31
3953	999	2013-08-31
3954	999	2013-08-31
3955	999	2013-09-01
3956	999	2013-09-01
3957	999	2013-09-01
3958	999	2013-09-01
3959	999	2013-09-01
3960	999	2013-09-01
3961	999	2013-09-01
3962	999	2013-09-01
3963	999	2013-09-01
3964	999	2013-09-01
3965	999	2013-09-01
3966	999	2013-09-01
3967	999	2013-09-01
3968	999	2013-09-02
3969	999	2013-09-02
3970	999	2013-09-02
3971	999	2013-09-02
3972	999	2013-09-02
3973	999	2013-09-02
3974	999	2013-09-02
3975	999	2013-09-03
3976	999	2013-09-03
3977	999	2013-09-03
3978	999	2013-09-03
3979	999	2013-09-03
3980	999	2013-09-03
3981	999	2013-09-03
3982	999	2013-09-03
3983	999	2013-09-04
3984	999	2013-09-04
3985	999	2013-09-04
3986	999	2013-09-04
3987	999	2013-09-04
3988	999	2013-09-04
3989	999	2013-09-04
3990	999	2013-09-04
3991	999	2013-09-05
3992	999	2013-09-05
3993	999	2013-09-05
3994	999	2013-09-05
3995	999	2013-09-05
3996	999	2013-09-05
3997	999	2013-09-05
3998	999	2013-09-05
3999	999	2013-09-05
4000	999	2013-09-06
4001	999	2013-09-06
4002	999	2013-09-06
4003	999	2013-09-06
4004	999	2013-09-06
4005	999	2013-09-06
4006	999	2013-09-06
4007	999	2013-09-07
4008	999	2013-09-07
4009	999	2013-09-07
4010	999	2013-09-07
4011	999	2013-09-07
4012	999	2013-09-07
4013	999	2013-09-07
4014	999	2013-09-07
4015	999	2013-09-07
4016	999	2013-09-07
4017	999	2013-09-08
4018	999	2013-09-08
4019	999	2013-09-08
4020	999	2013-09-08
4021	999	2013-09-08
4022	999	2013-09-08
4023	999	2013-09-08
4024	999	2013-09-08
4025	999	2013-09-08
4026	999	2013-09-08
4027	999	2013-09-08
4028	999	2013-09-08
4029	999	2013-09-08
4030	999	2013-09-08
4031	999	2013-09-08
4032	999	2013-09-08
4033	999	2013-09-08
4034	999	2013-09-08
4035	999	2013-09-09
4036	999	2013-09-09
4037	999	2013-09-09
4038	999	2013-09-09
4039	999	2013-09-09
4040	999	2013-09-09
4041	999	2013-09-09
4042	999	2013-09-09
4043	999	2013-09-09
4044	999	2013-09-09
4045	999	2013-09-09
4046	999	2013-09-09
4047	999	2013-09-09
4048	999	2013-09-09
4049	999	2013-09-09
4050	999	2013-09-10
4051	999	2013-09-10
4052	999	2013-09-10
4053	999	2013-09-10
4054	999	2013-09-10
4055	999	2013-09-10
4056	999	2013-09-10
4057	999	2013-09-10
4058	999	2013-09-10
4059	999	2013-09-10
4060	999	2013-09-11
4061	999	2013-09-11
4062	999	2013-09-11
4063	999	2013-09-11
4064	999	2013-09-11
4065	999	2013-09-11
4066	999	2013-09-11
4067	999	2013-09-11
4068	999	2013-09-11
4069	999	2013-09-11
4070	999	2013-09-12
4071	999	2013-09-12
4072	999	2013-09-12
4073	999	2013-09-12
4074	999	2013-09-12
4075	999	2013-09-12
4076	999	2013-09-12
4077	999	2013-09-12
4078	999	2013-09-12
4079	999	2013-09-13
4080	999	2013-09-13
4081	999	2013-09-13
4082	999	2013-09-13
4083	999	2013-09-13
4084	999	2013-09-13
4085	999	2013-09-13
4086	999	2013-09-13
4087	999	2013-09-13
4088	999	2013-09-13
4089	999	2013-09-13
4090	999	2013-09-13
4091	999	2013-09-14
4092	999	2013-09-14
4093	999	2013-09-14
4094	999	2013-09-14
4095	999	2013-09-14
4096	999	2013-09-14
4097	999	2013-09-14
4098	999	2013-09-14
4099	999	2013-09-15
4100	999	2013-09-15
4101	999	2013-09-15
4102	999	2013-09-15
4103	999	2013-09-15
4104	999	2013-09-15
4105	999	2013-09-16
4106	999	2013-09-16
4107	999	2013-09-16
4108	999	2013-09-16
4109	999	2013-09-16
4110	999	2013-09-16
4111	999	2013-09-16
4112	999	2013-09-17
4113	999	2013-09-17
4114	999	2013-09-17
4115	999	2013-09-17
4116	999	2013-09-17
4117	999	2013-09-17
4118	999	2013-09-17
4119	999	2013-09-17
4120	999	2013-09-17
4121	999	2013-09-17
4122	999	2013-09-17
4123	999	2013-09-17
4124	999	2013-09-18
4125	999	2013-09-18
4126	999	2013-09-18
4127	999	2013-09-18
4128	999	2013-09-18
4129	999	2013-09-18
4130	999	2013-09-18
4131	999	2013-09-18
4132	999	2013-09-18
4133	999	2013-09-19
4134	999	2013-09-19
4135	999	2013-09-19
4136	999	2013-09-19
4137	999	2013-09-19
4138	999	2013-09-19
4139	999	2013-09-19
4140	999	2013-09-19
4141	999	2013-09-19
4142	999	2013-09-19
4143	999	2013-09-20
4144	999	2013-09-20
4145	999	2013-09-20
4146	999	2013-09-20
4147	999	2013-09-20
4148	999	2013-09-20
4149	999	2013-09-21
4150	999	2013-09-21
4151	999	2013-09-21
4152	999	2013-09-21
4153	999	2013-09-21
4154	999	2013-09-21
4155	999	2013-09-21
4156	999	2013-09-21
4157	999	2013-09-21
4158	999	2013-09-22
4159	999	2013-09-22
4160	999	2013-09-22
4161	999	2013-09-22
4162	999	2013-09-22
4163	999	2013-09-22
4164	999	2013-09-22
4165	999	2013-09-22
4166	999	2013-09-22
4167	999	2013-09-22
4168	999	2013-09-22
4169	999	2013-09-22
4170	999	2013-09-22
4171	999	2013-09-22
4172	999	2013-09-23
4173	999	2013-09-23
4174	999	2013-09-23
4175	999	2013-09-23
4176	999	2013-09-23
4177	999	2013-09-23
4178	999	2013-09-23
4179	999	2013-09-23
4180	999	2013-09-23
4181	999	2013-09-24
4182	999	2013-09-24
4183	999	2013-09-24
4184	999	2013-09-24
4185	999	2013-09-24
4186	999	2013-09-24
4187	999	2013-09-24
4188	999	2013-09-24
4189	999	2013-09-24
4190	999	2013-09-24
4191	999	2013-09-24
4192	999	2013-09-25
4193	999	2013-09-25
4194	999	2013-09-25
4195	999	2013-09-25
4196	999	2013-09-25
4197	999	2013-09-25
4198	999	2013-09-25
4199	999	2013-09-25
4200	999	2013-09-25
4201	999	2013-09-25
4202	999	2013-09-26
4203	999	2013-09-26
4204	999	2013-09-26
4205	999	2013-09-26
4206	999	2013-09-26
4207	999	2013-09-26
4208	999	2013-09-26
4209	999	2013-09-27
4210	999	2013-09-27
4211	999	2013-09-27
4212	999	2013-09-27
4213	999	2013-09-27
4214	999	2013-09-27
4215	999	2013-09-27
4216	999	2013-09-27
4217	999	2013-09-27
4218	999	2013-09-27
4219	999	2013-09-28
4220	999	2013-09-28
4221	999	2013-09-28
4222	999	2013-09-28
4223	999	2013-09-28
4224	999	2013-09-28
3881	999	2013-08-23
3882	999	2013-08-23
3883	999	2013-08-23
3884	999	2013-08-24
3885	999	2013-08-24
3886	999	2013-08-24
3887	999	2013-08-24
3888	999	2013-08-24
3889	999	2013-08-24
3890	999	2013-08-24
3891	999	2013-08-24
3892	999	2013-08-24
3893	999	2013-08-24
3894	999	2013-08-24
3895	999	2013-08-25
3896	999	2013-08-25
3897	999	2013-08-25
4225	999	2013-09-28
4226	999	2013-09-28
4227	999	2013-09-29
4228	999	2013-09-29
4229	999	2013-09-29
4230	999	2013-09-29
4231	999	2013-09-29
4232	999	2013-09-29
4233	999	2013-09-29
4234	999	2013-09-30
4235	999	2013-09-30
4236	999	2013-09-30
4242	999	2013-09-30
4243	999	2013-09-30
4244	999	2013-09-30
4245	999	2013-10-01
4246	999	2013-10-01
4247	999	2013-10-01
4248	999	2013-10-01
4249	999	2013-10-01
4250	999	2013-10-01
4251	999	2013-10-01
4252	999	2013-10-01
4253	999	2013-10-01
4254	999	2013-10-01
4255	999	2013-10-02
4256	999	2013-10-02
4257	999	2013-10-02
4258	999	2013-10-02
4259	999	2013-10-02
4260	999	2013-10-02
4261	999	2013-10-02
4262	999	2013-10-03
4263	999	2013-10-03
4264	999	2013-10-03
4265	999	2013-10-03
4266	999	2013-10-03
4267	999	2013-10-03
4268	999	2013-10-03
4269	999	2013-10-03
4270	999	2013-10-04
4271	999	2013-10-04
4272	999	2013-10-04
4273	999	2013-10-04
4274	999	2013-10-04
4275	999	2013-10-05
4276	999	2013-10-05
4277	999	2013-10-05
4278	999	2013-10-05
4279	999	2013-10-05
4280	999	2013-10-05
4281	999	2013-10-05
4282	999	2013-10-05
4283	999	2013-10-05
4284	999	2013-10-05
4285	999	2013-10-06
4286	999	2013-10-06
4287	999	2013-10-06
4288	999	2013-10-06
4289	999	2013-10-06
4290	999	2013-10-06
4291	999	2013-10-06
4292	999	2013-10-07
4293	999	2013-10-07
4294	999	2013-10-07
4295	999	2013-10-07
4296	999	2013-10-07
4297	999	2013-10-07
4298	999	2013-10-07
4299	999	2013-10-08
4300	999	2013-10-08
4301	999	2013-10-08
4302	999	2013-10-08
4303	999	2013-10-09
4304	999	2013-10-09
4305	999	2013-10-09
4306	999	2013-10-09
4307	999	2013-10-09
4308	999	2013-10-09
4309	999	2013-10-09
4310	999	2013-10-09
4311	999	2013-10-10
4312	999	2013-10-10
4313	999	2013-10-10
4314	999	2013-10-10
4315	999	2013-10-10
4316	999	2013-10-10
4317	999	2013-10-11
4318	999	2013-10-11
4319	999	2013-10-11
4320	999	2013-10-11
4321	999	2013-10-11
4322	999	2013-10-11
4323	999	2013-10-12
4324	999	2013-10-12
4325	999	2013-10-12
4326	999	2013-10-12
4327	999	2013-10-12
4328	999	2013-10-13
4329	999	2013-10-13
4330	999	2013-10-13
4331	999	2013-10-14
4332	999	2013-10-14
4333	999	2013-10-15
4334	999	2013-10-15
4335	999	2013-10-15
4336	999	2013-10-15
4337	999	2013-10-15
4338	999	2013-10-15
4339	999	2013-10-15
4340	999	2013-10-15
4341	999	2013-10-15
4342	999	2013-10-15
4343	999	2013-10-15
4344	999	2013-10-16
4345	999	2013-10-16
4346	999	2013-10-16
4347	999	2013-10-16
4348	999	2013-10-16
4349	999	2013-10-16
4350	999	2013-10-16
4351	999	2013-10-16
4352	999	2013-10-16
4353	999	2013-10-17
4354	999	2013-10-17
4355	999	2013-10-17
4356	999	2013-10-17
4357	999	2013-10-17
4358	999	2013-10-17
4359	999	2013-10-17
4360	999	2013-10-17
4361	999	2013-10-17
4362	999	2013-10-17
4363	999	2013-10-18
4364	999	2013-10-18
4365	999	2013-10-18
4366	999	2013-10-18
4367	999	2013-10-18
4368	999	2013-10-18
4369	999	2013-10-19
4370	999	2013-10-19
4371	999	2013-10-19
4372	999	2013-10-19
4373	999	2013-10-19
4374	999	2013-10-19
4375	999	2013-10-19
4376	999	2013-10-19
4377	999	2013-10-19
4378	999	2013-10-20
4379	999	2013-10-20
4380	999	2013-10-20
4381	999	2013-10-20
4237	999	2013-09-30
4238	999	2013-09-30
4239	999	2013-09-30
4240	999	2013-09-30
4241	999	2013-09-30
4382	999	2013-10-20
4383	999	2013-10-20
4384	999	2013-10-20
4385	999	2013-10-21
4386	999	2013-10-21
4387	999	2013-10-21
4388	999	2013-10-21
4389	999	2013-10-21
4390	999	2013-10-21
4391	999	2013-10-22
4392	999	2013-10-22
4393	999	2013-10-22
4394	999	2013-10-22
4395	999	2013-10-22
4396	999	2013-10-22
4397	999	2013-10-22
4398	999	2013-10-22
4399	999	2013-10-22
4400	999	2013-10-23
4401	999	2013-10-23
4402	999	2013-10-23
4403	999	2013-10-23
4404	999	2013-10-23
4405	999	2013-10-24
4406	999	2013-10-24
4407	999	2013-10-24
4408	999	2013-10-24
4409	999	2013-10-24
4410	999	2013-10-24
4411	999	2013-10-24
4412	999	2013-10-24
4413	999	2013-10-25
4414	999	2013-10-25
4415	999	2013-10-25
4416	999	2013-10-25
4417	999	2013-10-25
4418	999	2013-10-26
4419	999	2013-10-26
4420	999	2013-10-26
4421	999	2013-10-27
4422	999	2013-10-27
4423	999	2013-10-27
4424	999	2013-10-27
4425	999	2013-10-27
4426	999	2013-10-27
4427	999	2013-10-27
4428	999	2013-10-28
4429	999	2013-10-28
4430	999	2013-10-28
4431	999	2013-10-28
4432	999	2013-10-28
4433	999	2013-10-28
4434	999	2013-10-28
4435	999	2013-10-28
4436	999	2013-10-28
4437	999	2013-10-28
4438	999	2013-10-29
4439	999	2013-10-29
4440	999	2013-10-29
4441	999	2013-10-29
4442	999	2013-10-29
4443	999	2013-10-29
4444	999	2013-10-30
4445	999	2013-10-30
4446	999	2013-10-30
4447	999	2013-10-30
4448	999	2013-10-30
4449	999	2013-10-30
4450	999	2013-10-31
4451	999	2013-10-31
4452	999	2013-10-31
4453	999	2013-10-31
4454	999	2013-10-31
4455	999	2013-10-31
4456	999	2013-11-01
4457	999	2013-11-01
4458	999	2013-11-01
4459	999	2013-11-01
4460	999	2013-11-01
4461	999	2013-11-01
4462	999	2013-11-01
4463	999	2013-11-03
4464	999	2013-11-03
4465	999	2013-11-04
4466	999	2013-11-04
4467	999	2013-11-04
4468	999	2013-11-04
4469	999	2013-11-07
4470	999	2013-11-07
4471	999	2013-11-07
4472	999	2013-11-07
4473	999	2013-11-09
4474	999	2013-11-10
4475	999	2013-11-10
4476	999	2013-11-10
4477	999	2013-11-10
4483	999	2013-11-13
4484	999	2013-11-16
4485	999	2013-11-16
4486	999	2013-11-16
4487	999	2013-11-16
4488	999	2013-11-16
4489	999	2013-11-16
4490	999	2013-11-16
4491	999	2013-11-16
4492	999	2013-11-19
4493	999	2013-11-19
4494	999	2013-11-19
4495	999	2013-11-22
4496	999	2013-11-22
4497	999	2013-11-22
4498	999	2013-11-22
4499	999	2013-11-24
4500	999	2013-11-25
4501	999	2013-11-25
4502	999	2013-11-25
4503	999	2013-11-25
4504	999	2013-11-25
4505	999	2013-11-25
4506	999	2013-11-25
4507	999	2013-11-27
4508	999	2013-11-28
4509	999	2013-11-28
4510	999	2013-11-28
4511	999	2013-11-28
4512	999	2013-12-01
4513	999	2013-12-01
4514	999	2013-12-01
4515	999	2013-12-03
4516	999	2013-12-04
4517	999	2013-12-04
4518	999	2013-12-04
4519	999	2013-12-06
4520	999	2013-12-06
4521	999	2013-12-07
4522	999	2013-12-07
4523	999	2013-12-07
4524	999	2013-12-07
1681	999	2013-08-08
1682	999	2013-08-08
1683	999	2013-08-08
1684	999	2013-08-08
1685	999	2013-08-08
1686	999	2013-08-08
1687	999	2013-08-08
1688	999	2013-08-08
1689	999	2013-08-08
1690	999	2013-08-08
1691	999	2013-08-08
1692	999	2013-08-08
1693	999	2013-08-08
1694	999	2013-08-08
1695	999	2013-08-09
47	999	2006-08-22
48	999	2006-08-22
49	999	2006-08-23
50	999	2006-08-23
51	999	2006-08-23
52	999	2006-08-23
53	999	2006-08-23
54	999	2006-08-23
55	999	2006-08-23
56	999	2006-08-23
57	999	2006-08-23
58	999	2006-08-23
59	999	2006-08-23
60	999	2006-08-23
61	999	2006-08-23
62	999	2006-08-24
63	999	2006-08-24
64	999	2006-08-24
65	999	2006-08-24
66	999	2006-08-24
67	999	2006-08-24
68	999	2006-08-24
77	999	2006-08-25
78	999	2006-08-25
127	999	2006-08-28
128	999	2006-08-28
177	999	2006-08-31
178	999	2006-08-31
227	999	2006-09-03
228	999	2006-09-03
277	999	2006-09-07
278	999	2006-09-07
327	999	2006-09-10
328	999	2006-09-10
377	999	2006-09-13
378	999	2006-09-13
427	999	2006-09-17
428	999	2006-09-17
477	999	2006-09-20
478	999	2006-09-20
527	999	2006-09-24
528	999	2006-09-24
577	999	2006-09-27
578	999	2006-09-27
627	999	2006-09-30
628	999	2006-09-30
677	999	2006-10-03
678	999	2006-10-03
727	999	2006-10-07
728	999	2006-10-07
777	999	2006-10-10
778	999	2006-10-10
827	999	2006-10-14
828	999	2006-10-14
877	999	2006-10-18
878	999	2006-10-18
927	999	2006-10-21
928	999	2006-10-21
977	999	2006-10-25
978	999	2006-10-25
1027	999	2006-10-31
1028	999	2006-10-31
1077	999	2006-11-07
1078	999	2006-11-07
1127	999	2006-11-11
1128	999	2006-11-11
1177	999	2006-11-14
1178	999	2006-11-14
1227	999	2006-11-17
1228	999	2006-11-17
1277	999	2006-11-21
1278	999	2006-11-21
1327	999	2006-11-24
1328	999	2006-11-25
1377	999	2013-07-11
1378	999	2013-07-11
1427	999	2013-07-16
1428	999	2013-07-16
1477	999	2013-07-22
1478	999	2013-07-22
1527	999	2013-07-27
1528	999	2013-07-27
1577	999	2013-07-30
1578	999	2013-07-30
1627	999	2013-08-03
1775	999	2013-08-17
1776	999	2013-08-17
1825	999	2013-08-22
1826	999	2013-08-22
1	999	2006-08-18
2	999	2006-08-18
4479	999	2013-11-10
4480	999	2013-11-13
4481	999	2013-11-13
4482	999	2013-11-13
1717	999	2013-08-10
1718	999	2013-08-11
1719	999	2013-08-11
1720	999	2013-08-11
1721	999	2013-08-11
1722	999	2013-08-11
1723	999	2013-08-11
1724	999	2013-08-11
69	999	2006-08-24
70	999	2006-08-24
71	999	2006-08-24
72	999	2006-08-24
73	999	2006-08-24
74	999	2006-08-24
75	999	2006-08-24
76	999	2006-08-24
79	999	2006-08-25
80	999	2006-08-25
81	999	2006-08-25
82	999	2006-08-25
1891	999	2013-08-26
1892	999	2013-08-26
1893	999	2013-08-26
4478	999	2013-11-10
87	999	2006-08-25
88	999	2006-08-25
89	999	2006-08-25
90	999	2006-08-25
91	999	2006-08-25
92	999	2006-08-25
93	999	2006-08-26
94	999	2006-08-26
95	999	2006-08-26
96	999	2006-08-26
97	999	2006-08-26
98	999	2006-08-26
99	999	2006-08-26
100	999	2006-08-26
101	999	2006-08-26
102	999	2006-08-26
103	999	2006-08-26
104	999	2006-08-26
105	999	2006-08-26
106	999	2006-08-26
107	999	2006-08-26
108	999	2006-08-26
109	999	2006-08-27
110	999	2006-08-27
83	999	2006-08-25
84	999	2006-08-25
85	999	2006-08-25
86	999	2006-08-25
3	999	2006-08-18
4	999	2006-08-18
5	999	2006-08-18
6	999	2006-08-19
7	999	2006-08-19
8	999	2006-08-19
9	999	2006-08-19
10	999	2006-08-19
11	999	2006-08-19
12	999	2006-08-19
13	999	2006-08-19
14	999	2006-08-19
15	999	2006-08-19
16	999	2006-08-19
17	999	2006-08-19
1886	999	2013-08-26
1887	999	2013-08-26
1888	999	2013-08-26
1889	999	2013-08-26
1890	999	2013-08-26
\.


--
-- TOC entry 3496 (class 0 OID 597717)
-- Dependencies: 197
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY spatial_ref_sys  FROM stdin;
\.


SET search_path = ibex_traj_materialized_bursts, pg_catalog;

--
-- TOC entry 3507 (class 2606 OID 615755)
-- Name: animal_burst animal_burst_pkey; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY animal_burst
    ADD CONSTRAINT animal_burst_pkey PRIMARY KEY (id);


--
-- TOC entry 3509 (class 2606 OID 615757)
-- Name: animal_burst burst_pgtraj_unique; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY animal_burst
    ADD CONSTRAINT burst_pgtraj_unique UNIQUE (burst_name, pgtraj_id);


--
-- TOC entry 3503 (class 2606 OID 615744)
-- Name: pgtraj pgtraj_pgtraj_name_key; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY pgtraj
    ADD CONSTRAINT pgtraj_pgtraj_name_key UNIQUE (pgtraj_name);


--
-- TOC entry 3505 (class 2606 OID 615742)
-- Name: pgtraj pgtraj_pkey; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY pgtraj
    ADD CONSTRAINT pgtraj_pkey PRIMARY KEY (id);


--
-- TOC entry 3512 (class 2606 OID 615773)
-- Name: relocation relocation_pkey; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY relocation
    ADD CONSTRAINT relocation_pkey PRIMARY KEY (id);


--
-- TOC entry 3517 (class 2606 OID 615799)
-- Name: s_b_rel s_b_rel_pkey; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY s_b_rel
    ADD CONSTRAINT s_b_rel_pkey PRIMARY KEY (step_id, animal_burst_id);


--
-- TOC entry 3515 (class 2606 OID 615784)
-- Name: step step_pkey; Type: CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY step
    ADD CONSTRAINT step_pkey PRIMARY KEY (id);


--
-- TOC entry 3520 (class 1259 OID 615861)
-- Name: all_burst_summary_shiny_burst_name_idx; Type: INDEX; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE INDEX all_burst_summary_shiny_burst_name_idx ON all_burst_summary_shiny USING btree (burst_name);


--
-- TOC entry 3510 (class 1259 OID 615810)
-- Name: relocation_geom_idx; Type: INDEX; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE INDEX relocation_geom_idx ON relocation USING gist (geom);


--
-- TOC entry 3513 (class 1259 OID 615811)
-- Name: relocation_time_idx; Type: INDEX; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE INDEX relocation_time_idx ON relocation USING btree (relocation_time);


--
-- TOC entry 3518 (class 1259 OID 615851)
-- Name: step_geometry_shiny_ibex_date_idx; Type: INDEX; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE INDEX step_geometry_shiny_ibex_date_idx ON step_geometry_shiny_ibex USING btree (date);


--
-- TOC entry 3519 (class 1259 OID 615852)
-- Name: step_geometry_shiny_ibex_step_geom_idx; Type: INDEX; Schema: ibex_traj_materialized_bursts; Owner: -
--

CREATE INDEX step_geometry_shiny_ibex_step_geom_idx ON step_geometry_shiny_ibex USING gist (step_geom);


--
-- TOC entry 3521 (class 2606 OID 615758)
-- Name: animal_burst animal_burst_pgtraj_id_fkey; Type: FK CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY animal_burst
    ADD CONSTRAINT animal_burst_pgtraj_id_fkey FOREIGN KEY (pgtraj_id) REFERENCES pgtraj(id) ON DELETE CASCADE;


--
-- TOC entry 3525 (class 2606 OID 615805)
-- Name: s_b_rel s_b_rel_animal_burst_id_fkey; Type: FK CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY s_b_rel
    ADD CONSTRAINT s_b_rel_animal_burst_id_fkey FOREIGN KEY (animal_burst_id) REFERENCES animal_burst(id) ON DELETE CASCADE;


--
-- TOC entry 3524 (class 2606 OID 615800)
-- Name: s_b_rel s_b_rel_step_id_fkey; Type: FK CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY s_b_rel
    ADD CONSTRAINT s_b_rel_step_id_fkey FOREIGN KEY (step_id) REFERENCES step(id) ON DELETE CASCADE;


--
-- TOC entry 3522 (class 2606 OID 615785)
-- Name: step step_relocation_id_1_fkey; Type: FK CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY step
    ADD CONSTRAINT step_relocation_id_1_fkey FOREIGN KEY (relocation_id_1) REFERENCES relocation(id) ON DELETE CASCADE;


--
-- TOC entry 3523 (class 2606 OID 615790)
-- Name: step step_relocation_id_2_fkey; Type: FK CONSTRAINT; Schema: ibex_traj_materialized_bursts; Owner: -
--

ALTER TABLE ONLY step
    ADD CONSTRAINT step_relocation_id_2_fkey FOREIGN KEY (relocation_id_2) REFERENCES relocation(id) ON DELETE SET NULL;


--
-- TOC entry 3664 (class 0 OID 615853)
-- Dependencies: 233 3666
-- Name: all_burst_summary_shiny; Type: MATERIALIZED VIEW DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

REFRESH MATERIALIZED VIEW all_burst_summary_shiny;


--
-- TOC entry 3663 (class 0 OID 615843)
-- Dependencies: 232 3666
-- Name: step_geometry_shiny_ibex; Type: MATERIALIZED VIEW DATA; Schema: ibex_traj_materialized_bursts; Owner: -
--

REFRESH MATERIALIZED VIEW step_geometry_shiny_ibex;


-- Completed on 2017-08-16 13:06:18 CEST

--
-- PostgreSQL database dump complete
--

