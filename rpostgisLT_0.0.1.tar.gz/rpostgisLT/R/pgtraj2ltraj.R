#' Import a pgtraj into an ltraj.
#' 
#' @description 
#' \code{pgtraj2ltraj} imports a single pgtraj from a database into an ltraj object.
#' 
#' @author Balázs Dukai \email{balazs.dukai@@gmail.com}
#' 
#' @param conn Connection object created with RPostgreSQL
#' @param schema String. Name of the schema that stores or will store the pgtraj data model.
#' @param pgtraj String. Name of the pgtraj.
#' 
#' @return an ltraj object
#' 
#' @examples 
#' \dontrun{pgtraj2ltraj(conn, "traj_t2", "ibex")}
#' 
#' @import RPostgreSQL, rpostgis, testthat
#' 
#' @export 
#' 
################################################################################
pgtraj2ltraj <- function(conn, schema = "traj", pgtraj) {
    # Begin transaction block
    invisible(dbGetQuery(conn, "BEGIN TRANSACTION;"))
    query <- paste0("SET search_path TO ", schema, ",public;")
    invisible(dbGetQuery(conn, query))
    
    # Get parameters
    query <- paste0("SELECT * FROM ", pgtraj, "_params;")
    DF <- invisible(dbGetQuery(conn, query))
    DF$dt <- toSeconds(DF[["dt"]])
    DF2 <- data.frame(
            x = DF[["x"]],
            y = DF[["y"]],
            date = DF[["date"]],
            dx = DF[["dx"]],
            dy = DF[["dy"]],
            dist = DF[["dist"]],
            dt = DF[["dt"]],
            R2n = DF[["r2n"]],
            abs.angle = DF[["abs_angle"]],
            rel.angle = DF[["rel_angle"]],
            id = DF[["id"]],
            burst = DF[["burst"]],
            rowname = DF[["r_rowname"]])
    
    # Cast into ltraj
    ltraj <- dl_opt(DF2)
    
    # Commit transaction and reset search path in the database
    query <- "SET search_path TO \"$user\",public;"
    invisible(dbGetQuery(conn, query))
    dbCommit(conn)
    message(paste0("Ltraj successfully created from ", pgtraj, "."))
    
    return(ltraj)
}

