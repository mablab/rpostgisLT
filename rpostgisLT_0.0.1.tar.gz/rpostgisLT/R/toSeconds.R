#' Converts hours to seconds
#' @param x Character string of the form H:M:S
#' @references http://stackoverflow.com/a/10836412/3717824
###############################################################################
toSeconds <- function(x){
    if (!is.character(x)) stop("x must be a character string of the form H:M:S")
    if (length(x)<=0)return(x)
    
    unlist(
            lapply(x,
                    function(i){
                        i <- as.numeric(strsplit(i,':',fixed=TRUE)[[1]])
                        if (length(i) == 3) 
                            i[1]*3600 + i[2]*60 + i[3]
                        else if (length(i) == 2) 
                            i[1]*60 + i[2]
                        else if (length(i) == 1) 
                            i[1]
                    }  
            )  
    )  
}

