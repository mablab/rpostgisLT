#' These functions meant to streamline the package development.
#' 
#' @author Balázs Dukai
#' 
###############################################################################

# Load packages
library(R.utils)
library(RPostgreSQL)
library(testthat)
library(adehabitatLT)

# package development
library(devtools)
library(tools)

sourceDirectory("/home/bdukai/Development/rpostgisLT/R") # rpostgisLT package repo
sourceDirectory("/home/bdukai/Development/rpostgis/R") # rpostgis package repo

setwd("./rpostgisLT")
setwd("/home/bdukai/Rlibs")

# Connect server
cs <- function() {
    drv <<- dbDriver("PostgreSQL")
    conn <<- dbConnect(drv, user="rpostgis", password="gsoc", dbname="rpostgis",
            host="basille-flrec.ad.ufl.edu")
    message("Connection established successfully")
}
# Reconnect server
rcs <- function() {
    dbDisconnect(conn)
    postgresqlCloseDriver(drv)
    dbUnloadDriver(drv)
    drv <<- dbDriver("PostgreSQL")
    conn <<- dbConnect(drv, user="rpostgis", password="gsoc", dbname="rpostgis",
            host="basille-flrec.ad.ufl.edu")
    message("Reconnected successfully")
}

# drv <- dbDriver("PostgreSQL")
# conn <- dbConnect(drv, user="rpostgisLT", password="rpostgisLT", dbname="rpostgisLT",
#         host="localhost")
