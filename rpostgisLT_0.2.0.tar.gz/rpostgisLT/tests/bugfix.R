library(adehabitatLT)
data(ibex)
data(ibexraw)
rpostgisLT:::ld_opt(ibex) # check
rpostgisLT:::ld_opt(ibexraw) # ibexraw HAS duplicate rownames

ibexraw[[1]]

# 
srs <- CRS("+init=epsg:3395")
ib_rec <- dl(ld(ibexraw[3])[1:10, ], proj4string = srs)

ltraj2pgtraj(conn, schema = "traj_test5", ltraj = ib_rec, pgtraj = "ib_rec[4]_3395")
ib_rec_re <- pgtraj2ltraj(conn, schema = "traj_test5", pgtraj = "ib_rec_3395")

ltraj2pgtraj(conn, schema = "traj_test6", ltraj = ib_rec, pgtraj = "ib_rec[3]_3395")

rpostgisLT:::pgTrajTempT(conn, "traj_t3")
rpostgisLT:::pgTrajDB2TempT(conn, schema = "traj_t3",
        relocations_table = "example_data.reloc_t1", 
        pgtrajs = "small",
        animals = "small animal",
        relocations = "geom",
        timestamps = NULL,
        rid = "gid", srid = 0)

### Basic testing
library(adehabitatLT)
library(rpostgisLT)
data(ibexraw)
data(ibex)
data(puechcirc)
data(albatross)
data(porpoise)

srs <- CRS("+init=epsg:3395")
srs2 <- CRS("+init=epsg:4326")
attr(ibexraw, 'proj4string') <- srs
attr(puechcirc, 'proj4string') <- srs2
attr(albatross, 'proj4string') <- srs
attr(porpoise, 'proj4string') <- srs2

ltraj2pgtraj(conn, ltraj = ibexraw, comment = "test CRS on ibexraw")
ltraj2pgtraj(conn, ltraj = puechcirc, comment = "test CRS on puechcirc")
ltraj2pgtraj(conn, ltraj = albatross, comment = "test CRS on albatross")
ltraj2pgtraj(conn, ltraj = porpoise, comment = "test CRS on porpoise")

ibexraw_re <- pgtraj2ltraj(conn, schema = 'traj', pgtraj = 'ibexraw')
puechcirc_re <- pgtraj2ltraj(conn, schema = 'traj', pgtraj = 'puechcirc')
albatross_re <- pgtraj2ltraj(conn, schema = 'traj', pgtraj = 'albatross')
#Error in `row.names<-.data.frame`(`*tmp*`, value = value) : 
#        duplicate 'row.names' are not allowed
#In addition: Warning message:
#        non-unique value when setting 'row.names': ‘65’ 
porpoise_re <- pgtraj2ltraj(conn, schema = 'traj', pgtraj = 'porpoise')

all.equal(ibexraw, ibexraw_re)
all.equal(puechcirc, puechcirc_re)
#all.equal(albatross, albatross_re)
all.equal(porpoise, porpoise_re)


data(ibexraw)
srs <- CRS("+init=epsg:3395")
ib_rec <- dl(ld(ibexraw[1])[1:10, ], proj4string = srs)

ltraj2pgtraj(conn, schema = "traj_test5", ltraj = ib_rec, pgtraj = "ib_rec_3395")
ib_rec_re <- pgtraj2ltraj(conn, schema = "traj_test5", pgtraj = "ib_rec_3395")
all.equal(ib_rec, ib_rec_re)

