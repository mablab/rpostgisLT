library(rgdal)
library(adehabitatLT)

# Let's say I have my data in a common projection WGS84/World Mercator 
# EPSG:3395, because I want world wide coverage and metric units. 
# I want to store the projection in the ltraj, therefore I search for 
# the PROJ.4 string, for example:
# PROJ.4 for EPSG:3395 from http://spatialreference.org/ref/epsg/3395/proj4/
srs <- CRS("+proj=merc +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs")
showEPSG("+proj=merc +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs")
showEPSG("+init=epsg:3395 +proj=merc +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs")
# Note that '+ellps=WGS84 +towgs84=0,0,0' is appended when using CRS()
# > srs@projargs
# [1] "+proj=merc +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0"
#
# But in PostGIS the original string is stored:
# SELECT proj4text FROM public.spatial_ref_sys WHERE auth_srid = 3395;
# proj4text                                                              |
# -----------------------------------------------------------------------|
# +proj=merc +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs  |
#
# Now the function ltraj2pgtraj() would do:
s <- dbGetQuery(conn, "SELECT schemaname FROM pg_catalog.pg_tables WHERE tablename LIKE 'spatial_ref_sys';")
query <- paste0("SELECT srid FROM ", s$schemaname,".spatial_ref_sys 
                WHERE proj4text ILIKE '%",srs,"%';")
query <- gsub(pattern = '\\s', replacement = " ", x = query)
# Which results in a query as:
# SELECT srid FROM public.spatial_ref_sys WHERE proj4text ILIKE '%+proj=merc +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0%';
# and because of the appended '+ellps=WGS84 +towgs84=0,0,0' string it returns nothing.
#
# Then, if we would use the OGC WKT representation of the EPSG:3395 projection 
# instead of Proj4 and compare the WKT in:
#
#http://spatialreference.org/
#PROJCS["WGS 84 / World Mercator",GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563,AUTHORITY["EPSG","7030"]],AUTHORITY["EPSG","6326"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.01745329251994328,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4326"]],UNIT["metre",1,AUTHORITY["EPSG","9001"]],PROJECTION["Mercator_1SP"],PARAMETER["central_meridian",0],PARAMETER["scale_factor",1],PARAMETER["false_easting",0],PARAMETER["false_northing",0],AUTHORITY["EPSG","3395"],AXIS["Easting",EAST],AXIS["Northing",NORTH]]
#
#PostGIS (srtext field in spatial_ref_sys)
#PROJCS["WGS 84 / World Mercator",GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563,AUTHORITY["EPSG","7030"]],AUTHORITY["EPSG","6326"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4326"]],PROJECTION["Mercator_1SP"],PARAMETER["central_meridian",0],PARAMETER["scale_factor",1],PARAMETER["false_easting",0],PARAMETER["false_northing",0],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AXIS["Easting",EAST],AXIS["Northing",NORTH],AUTHORITY["EPSG","3395"]]
#
#showWKT() from rgdal
#PROJCS["Mercator",GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["Degree",0.017453292519943295]],PROJECTION["Mercator"],PARAMETER["central_meridian",0],PARAMETER["false_easting",0],PARAMETER["false_northing",0],UNIT["Meter",1],PARAMETER["standard_parallel_1",0.0]]
#
# we see, that they don't match either, and again, rgdal manages projection strings rather freely.
#
# Although all projection representations are sufficient to actually define a 
# projection, they do not match exactly accross softwares/systems which is rather
# problematic if we want to use them interoperably.

showEPSG("+init=epsg:3395") 
# [1] "3395"

# Take Proj4 for the same EPSG from PostGIS:
showEPSG("+proj=merc +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs") 
# [1] "OGRERR_UNSUPPORTED_SRS" 

# Use CRS()
srs2 <- CRS("+init=epsg:3395")
srs2@projargs # note that this is the same as calling CRSargs(srs2)
# [1] "+init=epsg:3395 +proj=merc +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0"
showEPSG(srs2@projargs)
# [1] "3395"

showEPSG("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs ") 
# [1] "4326"

showEPSG("+proj=merc +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs")

pgSRID(srs, conn2, create = TRUE)

# Use pgSRID() from rpostgis
data(ibexraw)
srs <- CRS("+init=epsg:3395")
ib_rec <- dl(ld(ibexraw[1])[1:10, ], proj4string = srs)

ltraj2pgtraj(conn, schema = "traj_test5", ltraj = ib_rec, pgtraj = "ib_rec_3395")
ib_rec_re <- pgtraj2ltraj(conn, schema = "traj_test5", pgtraj = "ib_rec_3395")

all.equal(ib_rec, ib_rec_re)
